# 客製 FLUX vault 接板指引（給 Claude 照做）

> 本包對應 FLUX-standard **v2.0**（build 2026-08-09.2），板子模組內容與其同步。
> **適用對象：客製版 FLUX vault**（作者 1:1 客製、CLAUDE.md 開頭**沒有**「FLUX-standard **v2.0**」版號行）。
> 標準版使用者不要用本包 — 改走 `flux-v2-upgrade.zip`（https://yu-wenhao.com/zh-TW/flux-upgrade/）。
> 使用者把 `flux-board-addon.zip` 解壓（得到 `flux-board-addon/` 資料夾）後，
> 貼一句「請讀 flux-board-addon/add-board.md 照著做」觸發本流程。
> 本包做的事：把「任務看板（Tracking Board）」選配模組接進客製 vault。
> **接完不啟用 = 行為完全不變**（看板網址未填 = 檔案模式 = 原本的用法）——這是設計保證，請照此驗收。
> 中途中斷過？重貼同一句 prompt 重跑 — Step 0 會偵測半套狀態、從缺的補齊，不會重複破壞。

## 原則（先讀）

- **使用者的資料一個字都不動**：本流程只做兩件事 — 新增 `Cockpit/Tracking-Board/` 資料夾、
  在 CLAUDE.md 插入**一個**區塊。其他檔案全部不碰。
- 動 CLAUDE.md 前，**把要插入的內容原文展示給使用者、說明插在哪**，使用者 OK 才動手。
- 每一步做完跟使用者說一聲做了什麼；卡住就停下回報，不硬做。

## 步驟

### Step 0：定位 + 驗明正身

1. 找到使用者的 vault 根目錄（`CLAUDE.md` + `Home.md` 所在），跟使用者確認路徑。
   請使用者**先關掉 Obsidian**（開著的話，編輯器可能把舊內容存回被改的檔）。
2. **解壓位置檢查**：本檔（add-board.md）應該在獨立的 `flux-board-addon/` 資料夾裡。
   如果本檔跟使用者的 `Home.md` 在**同一層**＝解壓進 vault 根目錄了——停下回報，
   先跟使用者確認 vault 檔案沒被覆蓋才繼續。
3. **驗明正身**：
   - CLAUDE.md 開頭**有**「FLUX-standard **v2.0**」版號行 → 這是標準版，**停** —
     請使用者改走 `flux-v2-upgrade.zip`，本包不適用。
   - CLAUDE.md 裡**沒有** FLUX 字樣、或 vault 沒有 `Cockpit/` → 可能不是 FLUX vault，停下問使用者。
   - vault **已有** `Cockpit/Tracking-Board/` → 之前接過（或中斷過）：對照本包
     `Cockpit/Tracking-Board/` 的 9 檔逐檔補缺；CLAUDE.md 已有「板子設定」區塊就不重插；
     然後直接跳 Step 4 驗證。
   - 以上都不是 → 客製 vault、第一次接，往下走。

### Step 1：git 備份（必做——這是唯一的真安全網）

- vault 不是 git repo → `git init && git add -A && git commit -m "backup before board addon"`
- 是 git repo → 有未 commit 改動就先 `git add -A && git commit -m "backup before board addon"`
- 然後打 tag：`git tag pre-board`（已存在 = 上次留下的，沿用不重打）
- `git commit` 因為沒設 user.name/email 失敗 → 問使用者名字和 email、
  用 `git config user.name/user.email`（只設這個 repo）再 commit，不要跳過備份。
- **機器沒裝 git** → 請使用者先把整個 vault 複製一份（或壓成 zip）當手動備份，
  確認備份存在才繼續。沒有任何備份不進 Step 2。

> 之後任何一步出錯，`git checkout pre-board -- .` 都能整包回來。跟使用者說一聲這件事。

### Step 2：複製板子模組（純新增、零衝突）

把本包的 `flux-board-addon/Cockpit/Tracking-Board/`（整夾 **9 檔**）複製到 vault 的 `Cockpit/` 底下：

- 標準 8 檔：README.md、BOARD-MODE.md、DEPLOY.md、CUSTOMIZE.md、wrangler.toml、
  src/worker.js、public/index.html、.gitignore
- ＋1 檔客製 vault 專用：**CUSTOM-MAPPING.md**（BOARD-MODE.md 是照 FLUX-standard 流程寫的，
  這檔告訴板子模式的 Claude 怎麼對照到客製流程 — 標準包沒有這檔）

### Step 3：CLAUDE.md 插入「板子設定」區塊（只插這一塊）

要插入的內容**原文如下**（先展示給使用者、OK 才動手）：

```markdown
## 板子設定（Tracking Board — 選配模組）

- **看板網址**：（未填）
- **啟用日期**：（未填）

> 每次開新對話，順看本區決定模式：
> 網址**未填** = 檔案模式：整份檔照原文執行，不要讀板子相關檔案。
> 網址**已填** = 板子模式：**進任何流程前先讀 `Cockpit/Tracking-Board/BOARD-MODE.md`**，
> 並搭配同資料夾 `CUSTOM-MAPPING.md`（本 vault 是客製版，流程差異的對照原則在那）。
> 這是什麼？見 `Cockpit/Tracking-Board/README.md`（不啟用完全不影響使用）。
```

插入位置：CLAUDE.md **開頭區之後**（自我介紹／基本行為之類的段落後面）、
第一個主要流程章節之前。插入點不明顯就列兩個候選位置問使用者選。
除了插入這個區塊，**CLAUDE.md 其他內容一個字都不改**。

### Step 4：驗證

逐項檢查、列結果給使用者：

- [ ] `Cockpit/Tracking-Board/` 9 檔齊（含 CUSTOM-MAPPING.md）
- [ ] CLAUDE.md 有「板子設定」區塊、看板網址是（未填）
- [ ] `git diff pre-board -- CLAUDE.md` 只有插入的區塊、沒有其他變動
- [ ] 使用者資料抽查：最近一篇 daily note、隨機一張知識卡片 — 內容未被動過
- [ ] 跟使用者測一句日常指令（例如「今天做什麼」）→ 行為跟平常一樣（檔案模式 = 原本的用法）

### Step 5：收尾

1. 列「改動總表」（新增了哪個資料夾、CLAUDE.md 插了什麼）給使用者過目。
2. 使用者說 OK → `git add -A && git commit -m "add: Tracking Board 板子模組（未啟用）"`。
3. 刪掉解壓的 `flux-board-addon/` 資料夾（問過使用者）。
4. 跟使用者說：「接好了、日常用法完全不變。啟用 = 照 `Cockpit/Tracking-Board/DEPLOY.md`
   部署看板（一步指令）、把網址填進 CLAUDE.md 的『板子設定』— 工作坊課堂上會帶著做。」
