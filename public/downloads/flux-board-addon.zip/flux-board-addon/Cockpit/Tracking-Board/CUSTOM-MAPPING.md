# 客製 vault 對照指引（板子模式必讀）

> 本檔只出現在**客製版** FLUX vault（FLUX-standard 直系版本沒有、也不需要本檔）。
> 板子模式下本檔跟 `BOARD-MODE.md` 一起讀：BOARD-MODE.md 的差異段是照 **FLUX-standard**
> 的流程步驟編號寫的，你所在的客製 vault 結構跟它不完全一樣 — 落差用下面三條原則接。

## 對照三原則

1. **按概念對照、不按步驟編號**。BOARD-MODE.md 的「開工差異」對應本 vault CLAUDE.md 的
   每日規劃流程、「收工差異」對應晚間回顧／收工流程、「WAM 差異」對應每週回顧。
   在本 vault 的流程裡找到同一件事（掃任務、報進度、計分、carry-over、清理…），
   把差異套在那一步；BOARD-MODE.md 說「其餘照原文」時，「原文」指本 vault 自己的 CLAUDE.md。
2. **概念缺席就跳過**。BOARD-MODE.md 提到本 vault 沒有的機制（例：12-WEEK-PLAN、
   北極星／Lag 指標、Lead Indicators、bonus tag…）→ 該條不適用、直接跳過，
   **不要硬造出對應物**。不變的核心只有三件：任務池以板子為唯一帳本、每日從板上挑卡、
   每週以板上分數結算（本 vault 沒有每週計分流程的話，第三件也跳過）。
3. **拿不準就問**。對照有歧義時，把你打算怎麼套列出來問使用者一句，不要猜。

## 任務池退役（啟用板子時一次性處理）

啟用板子後，本 vault 裡原本扮演「任務池」的檔案（`BACKLOG.md` 或等價物）退役 —
跟使用者確認是哪個檔，在檔頭加一行「⚰️ 已由 Tracking Board 取代（YYYY-MM-DD）」，
**不刪檔**（歷史內容保留）。之後任務一律開卡上板，不再寫進該檔。

## 硬規則不打折

BOARD-MODE.md 的「硬規則」段（讀寫用 curl、寫入帶 expectedRev、一次一件不平行、
WAM 先抄後封、砍卡填 resolution 不刪卡）與「fail-soft」原則**原樣適用**、不在對照範圍內 —
那些是保資料的，跟 vault 結構無關。
