# Tracking Board — 你的任務看板（選配模組）

> 一頁式個人任務看板：Backlog → Todo → In Progress → Done，附本週 Score 與結算封存。
> 跑在**你自己的 Cloudflare 帳號**上（免費方案就夠）、手機電腦都能開。

## 預設是沉睡的

**不啟用完全不影響 FLUX** — 開工、收工、WAM 照常用檔案流程跑，這個資料夾可以整個無視。
哪天想要「任務有一塊隨時打開就看到的板子」再回來。

## 啟用三步

1. **部署**：跟 Claude 說「照 `Cockpit/Tracking-Board/DEPLOY.md` 幫我把看板部署上線」
   （需要一個免費 Cloudflare 帳號；過程 5-10 分鐘）
2. **啟用**：貼 `CUSTOMIZE.md`「啟用板子模式」段落的那段話給 Claude —
   它會把你現有的待辦搬上板、打開板子模式
3. **驗收**：重新整理網頁看到你的卡 → 隔天說「開工」，Claude 讀的就是看板了

想改欄名、換色、加功能 → `CUSTOMIZE.md` 有菜單。板子模式下流程哪裡不一樣 → `BOARD-MODE.md`（給 Claude 讀的）。

## 兩件要知道的事

- ⚠ **網址＝鑰匙**：看板沒有登入機制，拿到網址的人就能看能改。自己用沒問題，
  **別把網址公開貼出去**；真的洩漏了 → 叫 Claude 換個名字重新 deploy、再更新 CLAUDE.md 板子設定。
- ⚠ **卡片資料存在 Cloudflare KV、不在這個 vault 裡** — vault 的存檔（git）備份不到卡片。
  程式砍掉重練卡片都還在；但清掉 KV 卡片就真的沒了。

## 資料夾裡有什麼

| 檔案 | 用途 |
|---|---|
| `DEPLOY.md` | 部署步驟 + API 說明（給 Claude 照做） |
| `CUSTOMIZE.md` | 客製菜單 + 啟用板子模式流程 |
| `BOARD-MODE.md` | 板子模式的流程差異（給 Claude 讀） |
| `wrangler.toml` / `src/` / `public/` | 看板程式本體 |

> Obsidian 只顯示 .md 檔 — 這個資料夾裡的程式檔（.js / .html / .toml）在 Obsidian 看不到是正常的，
> 用 VS Code 開 vault 就看得到全部。
