> 逐週追蹤 Lead Indicators 完成率。每週 WAM 時計分。
> Lead Indicators 從 [[12-WEEK-PLAN]] 複製，每週重複追蹤同一組（不換）。
> 🟦 板子模式：本檔降級為**分數簿** — 任務在看板、這裡只記每週分數＋三問＋歷史。

---

## 本週

- **Week**：W{N}
- **本週起訖**：YYYY-MM-DD ~ YYYY-MM-DD
- **WAM 日期**：YYYY-MM-DD

### Lead Indicators（從 12-WEEK-PLAN）

> 🟦 板子模式：本段退役（啟用時 Claude 會標記）、本週任務以看板為準。

對應目標 1（____）：
- [ ] Lead Indicator A
- [ ] Lead Indicator B

對應目標 2（____）：
- [ ] Lead Indicator C
- [ ] Lead Indicator D

對應目標 3（____）：
- [ ] Lead Indicator E

### 本週分數

- **完成數**：X / Y
- **完成率**：Z%
- **解讀**：85%+ On Track / 70-84% Below Target / 65-69% 黃燈 / <65% 紅燈
- **有效**：（WAM 三問①）
- **沒做到**：（WAM 三問②）
- **下週調整**：（WAM 三問③）

### Lag Indicators 觀察（不計分，只看趨勢）

> WAM Step 2 用、每週填一次目前實際值。Lag 沒達標不要緊張、專注 Lead、Lag 會跟上。

| Lag Indicator | 起點值 | 目前值 | 12 週目標 |
|---|---|---|---|
| | | | |

---

## 歷史紀錄

> WAM 後把本週搬到下方，新建上方為下週。

### W{N-1}（YYYY-MM-DD ~ YYYY-MM-DD）— XX%

對應目標 1：
- [x] Lead Indicator A
- [ ] Lead Indicator B → carry-over / 砍 / 拆

對應目標 2：
- [x] Lead Indicator C
- [x] Lead Indicator D

> 🟦 板子模式的歷史長這樣（卡號＋標題、資料來自看板）：
>
> ### W{N-1}（YYYY-MM-DD ~ YYYY-MM-DD）— XX%
> - [x] ISS-012 週報彙整
> - [ ] ISS-015 讀書筆記整理 → 做 ⟲1
> - Bonus：ISS-021 臨時支援簡報
