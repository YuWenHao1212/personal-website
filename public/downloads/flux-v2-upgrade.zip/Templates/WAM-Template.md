> 每週問責會議（Weekly Accountability Meeting）
> 每週一次 20-30 分鐘，對自己誠實。對齊 [[12-WEEK-PLAN]] 的 Lead Indicators。

---

## 1. 本週計分（Lead Indicators）

打開 [[Weekly-Commitment]]，數本週 **Lead Indicators** 完成幾項。
🟦 板子模式：分數直接跟看板拿（本週 done／total），不用手數。

- **完成數**：___ / ___
- **完成率**：___%
- **解讀**：85%+ On Track / 70-84% Below Target / 65-69% 黃燈 / <65% 紅燈

> Lag Indicator 不計分，只觀察趨勢。Lag 沒達標不用緊張 — 專注 Lead，Lag 會跟上。

---

## 2. 本週 Lag Indicators 觀察

| Lag Indicator | 起點值 | 目前值 | 12 週目標 |
|---|---|---|---|
| | | | |

---

## 3. 回顧三問

- **什麼做法有效？**（是什麼條件讓你做到的？）
  -
- **什麼沒做到？**
  -
- **下週要調整什麼？**
  -

> ⚠️ 同一個 Lead Indicator **連續 2 週未完成** → 主動檢討：「目標太高？方法不對？還是其實不重要？」

---

## 4. Carry-over 決定

每項未完成 Lead Indicator 強制四選一（**做 / 拆 / 延 / 砍**）。連續 2 週 carry → 不准再 carry。
🟦 板子模式：對象＝本週未完成的卡；做＝week 改下週＋⟲N、延＝退回 Backlog、砍＝標 dropped。

| 項目（Lead Indicator／卡號） | 決定 | 備註 |
|---|---|---|
| | | |

---

## 5. Bonus 升級

本週計畫外但完成的事（不在當週 Lead Indicators 裡）：

-

> 同主題連續 2 週出現 → 下週 lock 為正式 Lead Indicator。

---

## 6. BACKLOG／看板 Backlog ≥4 週清理

檔案模式：掃 `Cockpit/BACKLOG.md`，看 `(YYYY-MM-DD added)` 後綴 ≥ 28 天的項目。
🟦 板子模式：掃看板 Backlog 欄的卡，看 created ≥ 28 天（搬家卡以 body 內原日期為準）：

| 項目 | 在 BACKLOG 多久 | 決定（拉進下週 / 拆小 / 砍） |
|---|---|---|
| | | |

---

## 6.5. Effort 對齊檢查 ⭐

掃 `Efforts/Areas/` + `Efforts/Projects/Active/`，每個 README 對照 [[12-WEEK-PLAN]]：

| Effort | 對應 Goal？ | 決定 |
|---|---|---|
| | ✅ / ⚠️ 漂離 / ❌ 不對應 | 留 / 搬 Idle / 搬 Sleeping / 完成歸檔 |

**判定原則**：
- **✅ 對應**：README「對應 Goal」欄填了當前 12-WEEK 目標 → 留
- **⚠️ 漂離**：README 沒填、或對應的是舊輪 12-WEEK 目標 → 問「下週要分配時間嗎？不要就搬 Idle」
- **❌ 不對應 + 不再投入**：搬 `Projects/Sleeping/` 或 `Projects/Idle/`
- 🟦 板子模式加查：Active 專案板上一張未封存卡都沒有 → 問「開一張卡？還是該歸檔／搬 Idle？」

> 為什麼：Active 目錄是「本季戰略執行位」、不是「我曾經想做的事大集合」。Effort 沒對齊就漂離戰略、佔據心智頻寬而沒產出。

---

## 7. 下週 Lead Indicators（lock）

整合 carry-over 決定 + Bonus 升級 + BACKLOG 拉進來的 + 全新項目。對齊 12 週目標。

對應目標 1（____）：
1.
2.

對應目標 2（____）：
1.
2.

對應目標 3（____）：
1.
2.

---

## 8. Vision Reconnect（選填）

> 每 4 週做一次（W4 / W8 / W12）。

讀 [[VISION]]，問自己：

- 目前的 12 週目標還在服務這個願景嗎？
- 有沒有哪個目標其實已經偏離方向？

筆記：

-

---

## 9. Phase Review（W4 / W8 / W12 限定）

| Week | 應做的事 |
|---|---|
| **W4** | 回顧第一個 month。Lead Indicator 設計合理嗎？ |
| **W8** | 中期檢視。最後 4 週還要不要硬推？或承認某目標收手？ |
| **W12** | 完整循環回顧 → 用 [[Review-Template]] 寫到 `Cockpit/Goals/archive/` → 觸發新一輪 setup-goals |

筆記：

-
