# FLUX-standard v1 → v2 升級步驟（給 Claude 照做）

> 學員把 `flux-v2-upgrade.zip` 解壓後，貼一句「請讀 UPGRADE.md 照著做」觸發本流程。
> v2 新內容：Tracking Board 任務看板沉睡模組（`Cockpit/Tracking-Board/`）+ 雙模式 CLAUDE.md。
> **升級完成後行為完全不變**（板子未啟用 = 檔案模式 = v1 行為）——這是設計保證，請照此驗收。

## 原則（先讀）

- **使用者的資料一個字都不動**：`Cockpit/`（Tracking-Board 以外）、`Efforts/`、`Atlas/`、`Calendar/`、
  `Inbox/`、`_assets/`、`.obsidian/` 全部不碰。
- **動到使用者自己寫過的內容之前先問**——寧可多問一句。
- 每一步做完跟使用者說一聲做了什麼；卡住就停下回報，不硬做。

## 步驟

### Step 0：定位 + 驗明正身

1. 找到使用者的 vault 根目錄（`CLAUDE.md` + `Home.md` 所在），跟使用者確認路徑。
2. 確認是 v1：CLAUDE.md 開頭**沒有**「FLUX-standard v2.0」版號行、且**沒有** `Cockpit/Tracking-Board/` 資料夾。
   - 已經有版號或資料夾 → 停下回報「看起來已是 v2、不用升級」。
3. 確認升級包位置（本檔所在資料夾），列出包內容給使用者看一眼。

### Step 1：git 備份（必做——這是唯一的真安全網）

- vault 不是 git repo → `git init && git add -A && git commit -m "backup before v2 upgrade"`
- 是 git repo → 有未 commit 改動就先 `git add -A && git commit -m "backup before v2 upgrade"`
- 然後打 tag：`git tag pre-v2`
- `git commit` 因為沒設 user.name/email 失敗 → 問使用者名字和 email、
  用 `git config user.name/user.email`（只設這個 repo）再 commit，不要跳過備份。

> 之後任何一步出錯，`git checkout pre-v2 -- .` 都能整包回來。跟使用者說一聲這件事。

### Step 2：CLAUDE.md 換版（保留使用者內容）

1. 讀舊 CLAUDE.md，抄出「你是誰」3 欄的值。
2. **自訂內容檢查**：列出舊檔所有 `## ` 標題，對照 v1 出廠標題清單：
   `你是誰｜互動前必做｜時間處理規則｜執行力規則｜Vault 安全規則｜基本行為｜溝通風格（預設行為，使用者可隨時調整）｜系統結構｜重要檔案｜觸發語對應｜反向 sync 規則（索引）｜流程：Daily｜流程：WAM｜更新我的資訊｜Effort 管理（Areas / Projects）｜Inbox 批次處理｜個人日記｜求助｜路徑規則｜模板對應`
   - 多出來的段落 = 使用者自己加的 → 逐段問「這段要搬進 v2 嗎？」要搬就原文搬到 v2 檔尾。
   - 標題都一樣但使用者說有改過內文 → 請使用者指出哪段，該段以使用者版本為準。
3. 用升級包的 `CLAUDE.md` 覆蓋，回填「你是誰」3 欄（+ 使用者要保留的自訂段）。

### Step 3：搬入板子模組

把升級包的 `Cockpit/Tracking-Board/`（整夾 7 檔）複製到 vault 的 `Cockpit/` 下。

### Step 4：Guides / Templates / Home.md（用基線判斷、不用猜）

升級包附 `v1-checksums.txt` = v1 出廠時每個 Guides/Templates 檔＋Home.md 的 SHA-256。
對 vault 裡的每一個對應檔算 hash（`shasum -a 256`）比對基線：

- **等於 v1 出廠值** = 使用者沒改過 → 直接用升級包版本覆蓋（不用問）。
- **不等於** = 使用者改過 → **不覆蓋**，列出檔名＋差異摘要問使用者：
  「這幾個檔你改過，要 (a) 保留你的版本（我再把 v2 新增的板子註記補進去）還是 (b) 換成 v2 出廠版（你的改動會不見、但 git tag pre-v2 找得回來）？」逐檔尊重使用者選擇。
- vault 裡沒有、包裡有的檔（新增檔）→ 直接複製。

### Step 5：merge `_claude/` → `.claude/`

升級包的 `_claude/` 底下每個檔，逐檔覆蓋到 vault 的 `.claude/` 對應路徑
（onboarding.md、agents/archivist.md、skills/knowledge-keeper/SKILL.md、skills/knowledge-keeper/folder-map.md）。
`.claude/` 其他檔案（使用者自加的 skill/agent）**不動**。

### Step 6：驗證

逐項檢查、列結果給使用者：

- [ ] CLAUDE.md 開頭有「FLUX-standard **v2.0**」版號行
- [ ] 「你是誰」3 欄的值還在（跟 Step 2 抄的一致）
- [ ] `Cockpit/Tracking-Board/` 7 檔齊：README.md、BOARD-MODE.md、DEPLOY.md、CUSTOMIZE.md、
      wrangler.toml、src/worker.js、public/index.html
- [ ] `Guides/` 10 篇、`Templates/` 10 檔
- [ ] 「板子設定」網址是（未填）——升級不啟用板子
- [ ] 使用者資料抽查：`Cockpit/Goals/` 三檔、最近的 Daily note、`Atlas/` 隨機一卡 — 內容未被動過

### Step 7：收尾

1. 列「改動總表」（哪些檔換新、哪些新增、哪些沒碰）給使用者過目。
2. 使用者說 OK → `git add -A && git commit -m "upgrade: FLUX-standard v2.0"`。
3. 刪掉解壓的升級包資料夾（問過使用者）。
4. 跟使用者說：「升級完成，日常用法完全不變。哪天想要任務看板 →
   讀 `Cockpit/Tracking-Board/README.md`，三步啟用。」
