---
order: 1
---

30-40 分鐘後，你會設定好 10 年願景 + 12 週目標 + 第一週 Lead Indicators，知道每個資料夾放什麼，並準備好開始你的第一個 12 週循環。

---

## Vault 結構

打開左側邊欄，你會看到這些資料夾：

| 資料夾 | 用途 | 你會多常用 |
|--------|------|-----------|
| **Inbox** | 快速捕捉，想到什麼先丟這裡 | 每天 |
| **Cockpit** | 目標、計畫、每日規劃（內含選配的 Tracking-Board 任務看板模組） | 每天 |
| **Efforts** | 你的領域和專案 | 每週 |
| **Calendar** | 日記和回顧 | 每天 |
| **Atlas** | 知識卡片和索引（MOC） | 持續累積 |
| **Guides** | 你正在讀的教學（唯讀） | 需要時 |
| **Templates** | 筆記模板 | 需要時 |

---

## 現在就做這三件事

### 1. 跑第一次設定（30-40 分鐘）

跟 Claude Code 說「**幫我開始**」，AI 會帶你完成：

1. **寫 [[VISION]]**（10 年願景 + 3 年願景 + 核心價值觀）— 你想成為什麼樣的人
2. **設定 [[12-WEEK-PLAN]]**（接下來 12 週要追的 2-3 個目標 + Lag/Lead Indicators）— 你能 100% 控制的行動是什麼
3. **建第一週 [[Weekly-Commitment]]**（把 Lead Indicators 列成 checkbox）— 本週要追蹤的清單

> 沒有 AI CLI？打開 `Templates/` 對應模板，手動照著填也行。完整流程見 [[03-12-Week-Year-Setup]]。

**好的 Lead Indicator 長這樣**：
- ✅ 每週重訓 3 次（你 100% 能控制）
- ✅ 每週讀完 1 個章節
- ✅ 每週寫 1 篇 500 字練習文

**不好的 Lead Indicator**：
- ❌ 體脂降到 20%（取決於身體反應，是 Lag）
- ❌ 想要更健康（太抽象）
- ❌ 多寫東西（沒驗收標準）

### 2. 設定 WAM 日

選週二 / 週五 / 週日其中一天當 WAM 日，固定就好。WAM 是每週檢討儀式，15-25 分鐘。詳見 [[05-Weekly-Review-WAM]]。

### 3. 規劃你的第一天

打開 `Cockpit/Daily/`，從本週 Lead Indicators 挑 1-3 件今天要做的事。

> 也可以直接複製 `Templates/Daily-Template.md`。完整的每日規劃流程 → [[04-Daily-Planning]]

---

## 用 AI 加速

如果你有 Claude Code 或其他 AI CLI 工具，可以用一句話完成：

- **「幫我開始」** — AI 帶你跑完 12 Week Year setup（30-40 分鐘建 VISION + 12-WEEK-PLAN + 第一週 Weekly-Commitment）
- **「規劃今天」** — AI 從本週 Lead Indicators 自動生成每日任務
- **「WAM」** — AI 帶你跑完整 8-step 週問責會議

詳見 [[08-Upgrade-with-AI]]。

---

## 接下來讀什麼

依你的需求選擇：

- 想了解知識管理框架？→ [[02-LYT-Framework]]
- 想深入 12 Week Year？→ [[03-12-Week-Year-Setup]]
- 想知道每日規劃怎麼做？→ [[04-Daily-Planning]]
- 想了解 WAM 問責會議？→ [[05-Weekly-Review-WAM]]
- 想學怎麼捕捉知識？→ [[06-Knowledge-Capture]]
- 想寫好知識卡片？→ [[07-Writing-Good-Cards]]
- 想用 AI 加速一切？→ [[08-Upgrade-with-AI]]
