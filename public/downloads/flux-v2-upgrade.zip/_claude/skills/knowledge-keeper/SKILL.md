---
name: knowledge-keeper
description: 知識庫助手。兩個暗號：[研究] 收集網路資料、[歸檔] 把文章/影片/會議內容拆成可複用的知識卡片。當使用者說「[研究] XXX」「[歸檔] XXX」「幫我存起來」「拆成知識卡片」「歸檔這篇」「建知識庫」「查以前有沒有類似的」時使用。產出固定放 Atlas/Sources、Atlas/Dots、Atlas/Maps、Atlas/log.md、Inbox。注意：使用者說「記錄一個想法」時走 FLUX CLAUDE.md 的互動式流程，不觸發本 Skill。
---

# 知識庫助手

## 為什麼需要 Atlas

你的 FLUX vault 已經有很多地方，但**大部分都是暫時的**：

- `Efforts/Projects/` → 會結案（專案結束，內容被歸檔）
- `Efforts/Areas/` → 會累積變雜（領域越大，越難找特定知識）
- `Cockpit/Daily/` → 會過期歸檔（每月搬到 archive）
- `Inbox/` → 會清空（暫存區不留東西）

**只有 Atlas 是永久的**。

如果你希望一個**原則 / 洞察 / 判斷規則** 半年後、一年後、三年後還找得到 —
它必須最終流到 `Atlas/Dots/`（從 `Atlas/Sources/` 拆出的原子卡）。

**不流到 Atlas 的原則 = 你默認接受它會消失。**

### Atlas vs 其他系統（互補，不取代）

| 系統 | 存什麼 | 格式 |
|---|---|---|
| **Atlas/Sources** | 完整原始來源（書 / 文章 / 影片 / Podcast / ...） | 一個來源一個檔、含完整 metadata |
| **Atlas/Dots** | 從 Source 拆出的**原子化原則/洞察** | 一卡一概念、結論式檔名 |
| `Cockpit/Daily/` | 每天的**工作日誌** | 任務 + 進度 + 一日回顧 |
| `.claude/skills/` | 可執行的**成功流程** | SOP 手冊 |

**Daily Note 和 Skill 本身不搬進 Atlas**（它們不是原子化的）。
但**從它們提煉的洞察 Dot** 會進 Atlas — 讓事件/流程和可複用原則互補。

例子：
- Daily Note 記了「2026-05-19 跟客戶談合作、學到 Y」整段對話
- 從中提煉 Dot：`報價時要先問用途不是問張數.md`（進 Atlas/Dots/Statements/）
- Dot 的 `## References` 段寫「個人想法」或連回那則 Daily（需要完整事件時可以回去看）

知識的流動方向：
```
研究 / 閱讀 / 會議 / 實作 / 反思
    ↓
Inbox / Cockpit/Daily/ / Skill 設計
    ↓
有完整來源？→ Atlas/Sources/（先建 Source 檔）
    ↓
⭐ 從來源拆出原子化原則 → Atlas/Dots（永久家）
    ↓
事件和流程會過期、結案、變動
    ↓
但原子化的 Dot 留下了，可被任何主題引用
```

---

## 這個 skill 幫你做什麼

把你看過的東西、開過的會、學到的經驗，**分類存進知識庫**。
下次遇到類似問題，不用從頭 Google — 翻自己的知識庫就有。

兩個暗號：

| 說什麼 | 做什麼 | 產出在哪 |
|---|---|---|
| `[研究] 主題` | 先查內部知識庫 → 再上網補強 → 整合報告 | 報告好後問你：存 `Inbox/`（之後再整理）還是直接歸檔進 `Atlas/`（二選一） |
| `[歸檔] 內容/URL` | 拆成知識卡片、分類歸檔 | 完整來源存 `Atlas/Sources/`、拆出的卡存 `Atlas/Dots/` 永久保存 |

> **⚠️ 觸發詞要含方括號** — `[研究]` / `[歸檔]` 才會觸發本 Skill。
> ✅ 「接下來 [研究] 個人品牌相關」、「[歸檔] 我剛讀完 Atomic Habits」
> ❌ 「研究一下個人品牌」、「歸檔這篇」（少了方括號、會走 CLAUDE.md 互動式流程、不是本 Skill）

**`[歸檔]` 是全自動模式** — Claude 跑五步法（建 Source → 拆 Dots → 建連結 → 矛盾偵測 → 寫 log），跑完給驗收清單。

如果使用者說「記錄一個想法」、走的是 FLUX CLAUDE.md 內建的互動式流程（一問一答、人工介入多）— 不在本 Skill 範圍內。

---

## 你的知識庫長什麼樣

```
Atlas/
├── Sources/             ← 完整原始來源（7 類）
│   ├── Articles/          網路文章、Blog、Newsletter
│   ├── Books/             書
│   ├── Videos/            YouTube、影片、線上課
│   ├── Podcasts/          Podcast 節目
│   ├── Courses/           課程
│   ├── Talks/             演講、研討會
│   └── Papers/            論文
├── Dots/                ← 知識卡片：一卡一概念，五種類型
│   ├── Things/            概念、工具、方法（預設選項，最常用）
│   ├── Statements/        觀點、主張、原則（你相信什麼）
│   ├── People/            人物（客戶、講師、同事、思考者）
│   ├── Questions/         思考種子（值得反覆探索、沒有最終答案的問題）
│   └── Quotes/            引言（誰說了什麼）
├── Maps/                ← 主題目錄頁：某主題的所有卡片清單
│   └── 教學培訓 MOC.md     （MOC = Map of Content）
└── log.md               ← 歸檔記帳本（誰在什麼時候歸了什麼）

Inbox/                   ← 桌面亂堆區：還沒分類的東西先丟這
```

**比喻**：
- **Sources** = 書櫃（一本書、一篇文章、一支影片各自一個檔，含完整出處）
- **Dots** = 你在書上畫的重點筆記（一張卡一個重點，五種顏色螢光筆）
- **Maps** = 你自己整理的書單/索引
- **Inbox** = 桌面亂堆區（等你決定要不要收進書櫃）
- **log.md** = 你的歸檔行為的記帳本（追蹤書櫃的成長）

**Sources 和 Dots 的分工**：Sources 存完整的原始出處（一本書、一篇文章、一支影片各自一個檔），Dots 存從 Source 拆出的原子知識卡。Dots 用 `## References` wikilink 連回 Source 檔；Source 用 `## Dots` 列出衍生卡。這樣半年後想看「這本書拆出了哪些卡」可以直接從 Source 翻。

**個人想法（沒有外部來源）** = 跳過 Source、直接建 Dot；Dot 的 `## References` 段寫「個人想法」。

---

## 該呼叫哪個 agent

完整 SOP 在 agent 檔，本 skill 不重複寫一遍 — 避免規範變動時兩處 drift。

| 暗號 | 怎麼跑 | SOP 在哪 |
|---|---|---|
| `[研究]` | 兩個 agent 協作：先呼叫 `archivist`（查詢模式、搜內部已有內容） → 再呼叫 `researcher`（外部 WebSearch 補缺口） → 整合 bullet 報告（🆕 / 🔄 / ⚠️ 標記）→ 問使用者要不要歸檔 | `.claude/agents/archivist.md`「查詢模式」+ `.claude/agents/researcher.md` |
| `[歸檔]` | 呼叫 `archivist`（歸檔模式）跑完整五步法：Step 0 Inbox 原檔處理 → Step 0.5 建 Source → Step 1 判斷類型 + 拆 Dot → Step 2 建連結 → Step 3 矛盾偵測 → Step 4 寫 log | `.claude/agents/archivist.md`「歸檔模式」 |

---

## ⚠️ Atlas 不收什麼（給你看的判斷規則）

**Atlas 是「原則庫」、不是「事件庫」**。以下內容**不要**直接 `[歸檔]`：

| 不該歸檔 | 為什麼 | 該怎麼做 |
|---|---|---|
| 會議記錄 | 是事件、不是原則 | 放 `Cockpit/Daily/` 或 `Efforts/Projects/{project}/`、todo 進 BACKLOG（板子模式：開看板 Backlog 卡） |
| Daily Note 整段 | 是時間軸日誌 | 從 Daily 提煉**單一原則**、再 `[歸檔]` 那條原則 |
| Todo 清單 | 是任務、不是知識 | 進 `Cockpit/BACKLOG.md`（板子模式：開看板 Backlog 卡） |
| 完整郵件對話 | 是通訊紀錄 | 從中提煉判斷規則或客戶偏好、再歸檔提煉物 |

**正確流程**（針對事件型內容）：
```
會議 / Daily / 客戶郵件
    ↓ 你讀完、想清楚
從中提煉「我學到的原則」
    ↓ 一句結論
[歸檔] 那條原則  ← 進 Atlas/Dots/
```

如果不確定能不能歸檔、想想這個 test：**「半年後、這個內容還能被別的主題引用嗎？」**
- 能 → 它是原則、可以歸檔
- 不能（只有當下情境的意義） → 它是事件、不要歸檔

---

## YouTube / Podcast 影片

⚠️ WebFetch 只能抓 metadata（標題、描述）、抓不到逐字稿。要歸檔影片內容、請先取得逐字稿後再 `[歸檔]` 貼上純文字。

**推薦**：用 `yt-dlp`（開源 CLI 工具）抓字幕、貼純文字進 Claude。安裝和指令自行 Google、或直接問 Claude「怎麼用 yt-dlp 抓 YT 字幕」。

**備用**（不想裝 CLI 時）：
- YouTube 影片下方「...更多」→「顯示腳本」→ 右側字幕面板全選複製
- 第三方 web 工具如 NoteGPT、downsub.com、tactiq.io，貼 URL 取得逐字稿

> 取到的逐字稿可能含時間戳記（如 `00:01:23 文字內容`）— 直接貼沒關係，Claude 會自動跳過時間戳專注內容。

---

## 範例輸入

```
[歸檔] https://example.com/article 這篇在講個人品牌的三個錯誤
[歸檔] 我發現催辦時超過 72 小時不回就該換策略
[歸檔] Inbox/2026-05-10-讀書筆記.md
```

---

## Frontmatter 範本

完整範本看 `frontmatter-cheat.md`。

---

## 驗收清單

跑完一次 `[歸檔]` 後，你的 vault 應該多出：
- ✅（如輸入是 URL/書/影片/...）`Atlas/Sources/{類型}/` 多 1 個檔
- ✅ `Atlas/Dots/{類型}/` 多 ≥ 1 個檔（依輸入分量、1-5 張）
- ✅ `Atlas/log.md` 多 1 行紀錄
- ✅（有新主題、且累積 ≥ 3 張同主題卡）`Atlas/Maps/` 多 1 個 MOC 檔
- ✅（如有更新舊 MOC）對應 MOC 多 N 個 wikilinks
- ✅（如有 Source 檔）Source 的 `## Dots` 段多 N 個 wikilinks

可以對 Claude 說「檢查我剛歸檔的產出」— 它會照這清單檢查。

---

## 卡住怎麼辦

如果 Claude 歸錯類、拆錯卡、寫錯連結：

1. **先停**：不要繼續讓它跑。
2. **切 Plan mode**（`Shift+Tab`）：讓它先說要怎麼修，你確認再做。
3. **叫第二個 Claude 來審**：開新對話，把產出貼過去問「你覺得有哪裡怪嗎」。

---

## 禁止事項（給你看的提醒）

完整禁止事項在 `archivist.md`、archivist 會自己遵守。對你來說最容易踩雷的三條：

- ❌ **不要**把 Daily Note 整段或會議記錄整段丟給 `[歸檔]` — 先提煉原則再歸檔（見上方 § Atlas 不收什麼）
- ❌ **不要**把 YouTube / Podcast URL 直接丟給 `[歸檔]` — WebFetch 抓不到逐字稿，要先取得逐字稿（見上方 § YouTube / Podcast 影片）
- ❌ **不要**手動改 archivist 寫的 frontmatter — 卡到時用「叫第二個 Claude 來審」（見上方 § 卡住怎麼辦）
