# Onboarding SOP（Claude 執行用）

> 給 Claude 看的執行腳本，不是給學員自學的文件（學員版見 `Guides/01-Quick-Start.md` / `Guides/03-12-Week-Year-Setup.md`）。
> 觸發時 Read 此檔、跟使用者跑流程。

三個對稱流程（按 onboarding 生命週期排）：
- **探索模式**：使用者還沒準備好 setup、只想了解
- **第一次設定**（30-40 min）：建 VISION / 12-WEEK-PLAN / Weekly-Commitment 第一份
- **12 週循環收尾**（W12 後）：歸檔本季、跑「第一次設定」建下季

---

## 探索模式

> 觸發語：「FLUX 是什麼」「先看看」「介紹一下」「我想了解」「告訴我這個 Vault 怎麼用」

使用者還沒準備好 setup，只是想了解。**不要急著推 onboarding**。

### 流程

1. 用一段話介紹 FLUX：「Focus / Learn / Upgrade / eXecute — 把 12 Week Year（執行）+ LYT（知識管理）+ AI 結合的個人作業系統」
2. 列三個可選路徑，讓使用者挑：
   - **「想先讀完整介紹」** → 引導讀 `Guides/01-Quick-Start.md`（10 分鐘了解架構）
   - **「想先試試輕的功能」** → 「我可以陪你寫第一篇日記 / 整理 Inbox / 歸檔一則知識卡片，這些填一下『你是誰』後就能跑」
   - **「我準備好做 12 週目標了」** → 接走本檔 § 第一次設定
3. 使用者沒選 → 不主動推、回到等待。可以追問「想知道哪部分」（執行 / 知識管理 / AI 工作流）

### 原則

- **不擋任何事**：即使「你是誰」沒填，也照常回答 FLUX 相關問題
- **不在第一輪推 onboarding**：使用者要的是理解、不是執行
- **不誇大效果**：不要說「用了你就會 X」、列事實（每天 30 分鐘、12 週循環、有 9 篇教學）

---

## 第一次設定

> 觸發語：「幫我開始」「第一次使用」「設定目標」「我要設定 12 週目標」「設定願景」「規劃 12 週」

FLUX 12 Week Year onboarding（30-40 分鐘）。建 VISION（10 年方向）→ 12-WEEK-PLAN（本季 2-3 目標 + Lag/Lead Indicators）→ Weekly-Commitment（第 1 週追蹤）。

### 流程

**Step 0**：歡迎 + 看 VISION / 12-WEEK-PLAN / Weekly-Commitment 三個範例（讓使用者了解格式）

**Step 1**：寫 VISION — 引導 10 年願景 + Anti-Vision + 3 年願景 + 核心價值觀 → 從 `Templates/VISION-Template.md` 複製，寫進 `Cockpit/Goals/VISION.md`

**Step 2**：設定 12 週目標 — 引導定 2-3 個目標、每個含：
- **Lag Indicator**（追求的結果、無法直接控制，例：體脂降到 20%）
- **Lead Indicators**（你能 100% 控制的行動、2-3 個，例：每週重訓 3 次）

→ 從 `Templates/12-WEEK-PLAN-Template.md` 複製，寫進 `Cockpit/Goals/12-WEEK-PLAN.md`（先填目標 + Lag + Lead；W1-W12 週期表 + WAM 日 Step 4 才填）

> **判斷 Lead vs Lag**：「我做這個行動，它一定會發生嗎？」是 → Lead；不是 → Lag

**Step 3**：**為每個 12 週目標建一個對應 folder（Area or Active Project）** — 12 週目標需要執行 anchor、不然 Daily 開工會掃不到東西。

**逐個目標**問使用者：「**這件事有完成那一天嗎？**」（不管 12 週做不做得完）

- **有完成日** → 建 **Active Project folder**：`Efforts/Projects/Active/{name}/`（含 `README.md`，長 project 也是 Project、12 週目標當本季 milestone、完成才搬 Done）
- **沒（永遠在維持）** → 建 **Area folder**：`Efforts/Areas/{name}/`（含 `README.md`）

從 `Templates/Effort-Template.md` 複製建 README。

> **強制規則**：N 個 12 週目標 → 必須建 N 個 folder（1:1 對應、不可跳過）。三個目標都跑完才能進 Step 4。

> **範例**：
> - 「上線 SEOLens v1 onboarding」→ Active Project `seolens/`（長 project、12 週只做 onboarding 段）
> - 「健康重訓 36 次」→ Area `健康/`（永遠在維持）
> - 「寫 12 篇 Blog」→ Area `個人品牌/`（永遠在累積）

**Step 4**：設定 WAM 日 + 展開 12 週週期表（2-3 min）— 問「想每週哪一天結算？建議週二、週五、或週日」。確認後 Claude 自己算：

1. 跑日期指令：`TZ='Asia/Taipei' date '+%Y-%m-%d %A'` 取今天
2. W1 起訖：今天 → 今天 +6 天
3. W1 的 WAM 日期：W1 範圍內第一個「使用者選的星期 X」
4. 重複 W2-W12（每週 +7 天、WAM 日期也 +7 天）
5. 填入 12-WEEK-PLAN.md 的「WAM 日」欄 + W1-W12 表格（起訖 + WAM 日期、全部展開、不寫 `...`）

> **為什麼要全部展開**：Daily 開工要算「W{N} Day X of 7」、開工自動提醒要比對「今天 == 本週 WAM 日期」 — 全部展開讓 Claude 直接查表、不用 runtime 算。

**Step 5**：建立第一週 Weekly-Commitment — 把 Lead Indicators 列成 checkbox → 從 `Templates/Weekly-Commitment-Template.md` 複製、寫進 `Cockpit/Goals/Weekly-Commitment.md`、**從 12-WEEK-PLAN W1 行直接抄「起訖 + WAM 日期」填入「本週」section**、從 12-WEEK-PLAN 複製本週 Lead Indicators

**Step 6**：建立第一個 Daily Note → 接走 `CLAUDE.md § 流程：每日規劃`

**Step 7**：收尾，介紹四個觸發語：「規劃今天」/「WAM」/「歸檔」/「循環回顧」（W12 用）

### 完成判定

- `VISION.md` / `12-WEEK-PLAN.md` / `Weekly-Commitment.md` 三檔都已填入使用者實際內容
- **至少 1 個 Area 或 Active Project** 已建（含 README）
- `Cockpit/Daily/YYYY-MM-DD.md` 已建立

> **未 setup 提醒**：vault 還沒 setup 過時（「你是誰」/ VISION / 12-WEEK-PLAN 任一還沒填）→ 走 `CLAUDE.md § 互動前必做` 的提示。

---

## 12 週循環收尾（W12）

> 觸發語：「循環回顧」「12 週結束」（或 W12 跑完 WAM 自動觸發）

WAM 跑到 W12 時，自動觸發**循環回顧**：

1. 用 `Templates/Review-Template.md`（Lag 結果 + Lead 12 週彙整 + 學到什麼）寫到 `Cockpit/Goals/archive/YYYY-MM-DD-cycle-review.md`
2. 問「下一輪要調整什麼？準備好的話，我們來設定新的 12 週計畫」
3. 接走本檔 § 第一次設定 建下個 12 週的 12-WEEK-PLAN（VISION 通常不變、12-WEEK-PLAN 完全重寫、Weekly-Commitment 開新 W1）

> 🟦 板子模式：W12 最後一次 WAM 結算封存後，看板 Backlog 的卡**跨季保留**（想法池不清空）、
> 新一季第一次 WAM 的 28 天鬧鐘會逼舊卡表態。使用者想整板從零開始 →
> `Cockpit/Tracking-Board/DEPLOY.md`「重置資料」（先警告：含封存區全清、不可復原）。
