# FLUX-standard v1 → v2 升級步驟（給 Claude 照做）

> **本包 build：2026-08-09.2**（升級完成後 CLAUDE.md 版號行應與此一致）。
> 學員把 `flux-v2-upgrade.zip` 解壓（得到 `flux-v2-upgrade/` 資料夾）後，
> 貼一句「請讀 flux-v2-upgrade/UPGRADE.md 照著做」觸發本流程。
> v2 新內容：Tracking Board 任務看板沉睡模組（`Cockpit/Tracking-Board/`）+ 雙模式 CLAUDE.md。
> **升級完成後行為完全不變**（板子未啟用 = 檔案模式 = v1 行為）——這是設計保證，請照此驗收。
> 中途中斷過？直接重貼同一句 prompt 重跑——Step 0 會偵測半套狀態、從缺的部分繼續，不會重複破壞。

## 原則（先讀）

- **使用者的資料一個字都不動**：`Cockpit/`（Tracking-Board 以外）、`Efforts/`、`Atlas/`、`Calendar/`、
  `Inbox/`、`_assets/`、`.obsidian/` 全部不碰。
- **動到使用者自己寫過的內容之前先問**——寧可多問一句。
- 每一步做完跟使用者說一聲做了什麼；卡住就停下回報，不硬做。

## 步驟

### Step 0：定位 + 環境檢查 + 驗明正身

1. 找到使用者的 vault 根目錄（`CLAUDE.md` + `Home.md` 所在），跟使用者確認路徑。
   請使用者**先關掉 Obsidian**（開著的話，編輯器可能把舊內容存回被換新的檔）。
2. **解壓位置檢查**：本檔（UPGRADE.md）應該在獨立的 `flux-v2-upgrade/` 資料夾裡。
   如果本檔跟使用者的 `Home.md` 在**同一層**＝升級包被解壓進 vault 根目錄了——停下回報，
   先跟使用者確認 vault 檔案是否被覆蓋（有 git 的話 `git status` 看），處理完才繼續。
3. **Windows 半套安裝檢查**：vault 根目錄若有 `_claude/`／`_obsidian/`（Windows 解壓後沒 rename）→
   先 `mv _claude .claude`、`mv _obsidian .obsidian`（PowerShell 用 `Rename-Item`）再繼續，
   否則 Step 5 會做出殘缺的 `.claude/`。
4. **驗明正身（三分支）**——看 CLAUDE.md 開頭有無「FLUX-standard **v2.0**」版號行、
   vault 有無 `Cockpit/Tracking-Board/` 資料夾：
   - **兩者都沒有** → 是 v1，走完整升級（Step 1 起）。
   - **有其一或兩者** → 已經（部分）是 v2，**不要直接說不用升級**，先跑「v2 完整性核對」：
     對照升級包內容逐檔比對——`Cockpit/Tracking-Board/` 8 檔、`.claude/` 對應 4 檔、
     `Guides/`＋`Templates/`＋`Home.md`、CLAUDE.md 版號行的 build 標記是否等於本包 build。
     - **全部一致** → 回報「已是本 build（2026-08-09.2），不用升級」，結束。
     - **有缺或不一致** → 上次升級沒跑完、或裝到早期 v2 build → 走**繼續升級**：
       跳過 Step 2 的換版（只驗證「你是誰」3 欄的值還在；空白就問使用者補填），
       Step 1 照做（tag 已存在就沿用），Step 3–6 照跑把缺的補齊。
5. 列出升級包內容給使用者看一眼。

### Step 1：git 備份（必做——這是唯一的真安全網）

- vault 不是 git repo → `git init && git add -A && git commit -m "backup before v2 upgrade"`
- 是 git repo → 有未 commit 改動就先 `git add -A && git commit -m "backup before v2 upgrade"`
- 然後打 tag：`git tag pre-v2`
  - tag 已存在（上次升級留下的）→ 沿用即可，不用重打。
- `git commit` 因為沒設 user.name/email 失敗 → 問使用者名字和 email、
  用 `git config user.name/user.email`（只設這個 repo）再 commit，不要跳過備份。
- **機器沒裝 git**（指令找不到）→ 請使用者先把整個 vault 資料夾複製一份（或壓縮成 zip）當手動備份，
  確認備份存在才繼續。沒有任何備份不進 Step 2。

> 之後任何一步出錯，`git checkout pre-v2 -- .` 都能整包回來。跟使用者說一聲這件事。

### Step 2：CLAUDE.md 換版（保留使用者內容）

1. 讀舊 CLAUDE.md，抄出「你是誰」3 欄的值。
2. **改動偵測（用出廠檔 diff、不用猜）**：升級包附 `v1-CLAUDE-factory.md`＝v1 出廠原檔
   （「你是誰」空白版）。把舊 CLAUDE.md 跟它 diff，**忽略「你是誰」3 欄的值**，把其餘差異分類：
   - **沒有其他差異** → 使用者沒改過出廠內容，直接進第 3 步換版。
   - **多出整段**（出廠檔沒有的 `##` 段落）＝使用者自己加的 → 逐段問「這段要搬進 v2 嗎？」
     要搬就原文搬到 v2 檔尾。
   - **出廠段落內文有差** → 把該段差異**列給使用者看**，逐段問以哪版為準；
     要保留的，把使用者的版本改寫進 v2 檔的對應段落。
3. 用升級包的 `CLAUDE.md` 覆蓋，回填「你是誰」3 欄（＋使用者要保留的自訂段）。

### Step 3：搬入板子模組

**覆蓋前檢查（vault 已有 `Cockpit/Tracking-Board/` 時才需要）**：看兩個訊號 —
CLAUDE.md「板子設定」的看板網址**已填**、或現有 `wrangler.toml` 的 KV id **不是佔位符**（`把這行換成你的-namespace-id`）。
任一成立＝這台已經部署過舊版（KV）看板、線上有卡片資料 → **先照新 `DEPLOY.md` 附錄
「v2（KV 版）看板搬家到 v3」把資料 export 下來**（至少完成 export 那步），才繼續覆蓋。
兩個訊號都沒有（板子從未部署、或 vault 根本沒這個資料夾）→ 直接覆蓋，零風險。

把升級包的 `Cockpit/Tracking-Board/`（整夾 8 檔，含 `.gitignore`）複製到 vault 的 `Cockpit/` 下。

> 本 build 的板子後端已從 KV 升級為 Durable Object：部署從三步變一步（不用建 namespace、不用貼 id）。
> 對「下載過舊版但還沒部署」的使用者，這次覆蓋就是無感升級；已部署過的照上面檢查走搬家。

### Step 4：Guides / Templates / Home.md（用基線判斷、不用猜）

先記住：**v2 真正有更新的只有這 9 檔**——
`Guides/01-Quick-Start.md`、`Guides/03-12-Week-Year-Setup.md`、`Guides/04-Daily-Planning.md`、
`Guides/05-Weekly-Review-WAM.md`、`Guides/10-FAQ.md`、`Home.md`、
`Templates/Daily-Template.md`、`Templates/WAM-Template.md`、`Templates/Weekly-Commitment-Template.md`。
其餘檔案包裡雖附（完整集），內容與 v1 出廠相同。

升級包附 `v1-checksums.txt`＝v1 出廠時每個 Guides/Templates 檔＋Home.md 的 SHA-256。
對 vault 裡的每一個對應檔算 hash（`shasum -a 256`）比對基線：

- **等於 v1 出廠值**＝使用者沒改過 → 直接用升級包版本覆蓋（不用問）。
- **不等於**＝使用者改過（或早期 v2 版本）：
  - 該檔**不在上面 9 檔清單**（v2 沒更新它）→ **保留使用者版本、不覆蓋、不用問**，
    收尾時跟使用者說一聲「這幾檔你有自訂、v2 沒更新它們，原樣保留」。
  - 該檔**在 9 檔清單** → 列出檔名問使用者：
    「這檔你改過（或是早期 v2 版），要 (a) 保留你的版本——我把 v2 這檔改了哪些地方列給你看，
    你挑要補的我幫你補進去；還是 (b) 換成 v2 出廠版（你的改動會不見、但 git tag pre-v2 找得回來）？」
    逐檔尊重使用者選擇。
- vault 裡沒有、包裡有的檔（新增檔）→ 直接複製。

### Step 5：merge `_claude/` → `.claude/`

升級包的 `_claude/` 底下每個檔，逐檔覆蓋到 vault 的 `.claude/` 對應路徑
（onboarding.md、agents/archivist.md、skills/knowledge-keeper/SKILL.md、skills/knowledge-keeper/folder-map.md）。
`.claude/` 其他檔案（使用者自加的 skill/agent）**不動**。

**殘留清理**：vault 的 `Inbox/SETUP-CLAUDE.md` 若還在（v1 安裝包的一次性安裝腳本，升級後用不到，
留著會被每日 Inbox 整理誤觸）→ 跟使用者說一聲後刪掉。

### Step 6：驗證

逐項檢查、列結果給使用者：

- [ ] CLAUDE.md 開頭有「FLUX-standard **v2.0**（build 2026-08-09.2）」版號行
- [ ] 「你是誰」3 欄的值還在（跟 Step 2 抄的一致）
- [ ] `Cockpit/Tracking-Board/` 8 檔齊：README.md、BOARD-MODE.md、DEPLOY.md、CUSTOMIZE.md、
      wrangler.toml、src/worker.js、public/index.html、.gitignore
- [ ] `Guides/` 10 篇、`Templates/` 10 檔
- [ ] 「板子設定」網址是（未填）——升級不啟用板子
- [ ] `Inbox/SETUP-CLAUDE.md` 已不存在
- [ ] 使用者資料抽查：`Cockpit/Goals/` 三檔、最近的 Daily note、`Atlas/` 隨機一卡 — 內容未被動過

### Step 7：收尾

1. 列「改動總表」（哪些檔換新、哪些新增、哪些沒碰、哪些保留使用者版）給使用者過目。
2. 使用者說 OK → `git add -A && git commit -m "upgrade: FLUX-standard v2.0"`。
3. 刪掉解壓的升級包資料夾（問過使用者）。
4. 跟使用者說：「升級完成，日常用法完全不變。哪天想要任務看板 →
   讀 `Cockpit/Tracking-Board/README.md`，三步啟用。」
