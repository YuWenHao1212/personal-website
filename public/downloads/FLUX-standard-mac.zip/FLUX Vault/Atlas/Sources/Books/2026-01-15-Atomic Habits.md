---
up:
  - "[[Productivity MOC]]"
type: book
url: ""
author: "James Clear"
created: 2026-01-15
status: reading
---

> 這是範例 Source — 展示歸檔後 Atlas/Sources/ 長什麼樣。

## Key Takeaways

- 習慣不是靠意志力，而是靠**系統設計**。設計環境讓對的行為變容易、錯的行為變難
- 任何習慣都會走過「提示 → 渴望 → 反應 → 獎賞」四個階段，要改習慣就改其中一環
- 每天進步 1% 看似很少，但複利一年後是 37 倍。**身分認同 > 行為**：先成為「我是會運動的人」，行為才會跟上

## Dots

- [[習慣的四個階段]]

## References

書名：*Atomic Habits* — James Clear（2018）
讀到第 1-3 章
