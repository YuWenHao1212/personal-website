---
up: "[[PKM MOC]]"
collection: Things
related:
  - "[[LYT 框架]]"
  - "[[Claude Code]]"
created: 2026-02-25
says: "本地優先的 Markdown 筆記工具，用雙向連結組織知識"
---

一款本地優先（local-first）的筆記工具。所有筆記都是純 Markdown 檔案，存在你自己的電腦裡，不鎖在任何雲端服務。

核心特色是**雙向連結**——用 `[[wikilinks]]` 把筆記串在一起，不靠資料夾分類。筆記越多，連結越密，知識的複利越大。

## 參考資料

- [Obsidian 官方網站](https://obsidian.md/)
- [用了 5 年 Roam Research，為什麼在 AI 時代我選擇 Obsidian？](https://yu-wenhao.com/zh-TW/blog/roam-research-to-obsidian/) — 從 Roam 轉 Obsidian 的決策過程
