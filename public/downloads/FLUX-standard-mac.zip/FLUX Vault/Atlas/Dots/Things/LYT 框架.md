---
up: "[[PKM MOC]]"
collection: Things
related:
  - "[[Nick Milo]]"
  - "[[卡片盒筆記法]]"
created: 2026-01-07
says: "一個透過連結而非分類來組織想法的知識管理框架"
---

**Linking Your Thinking (LYT)** 是 [[Nick Milo]] 設計的知識管理框架，適用於 Obsidian 等工具。

## 核心原則

> 不要把筆記歸檔到分類裡。**用連結把它們串起來。**

分類是僵硬的，連結是靈活的。一篇「AI 在教育的應用」的筆記可以同時連到你的 AI 筆記和教育筆記，不需要選一個資料夾。

## ACE 結構

| 資料夾          | 用途  | 可以想成... |
| ------------ | --- | ------- |
| **Atlas**    | 知識  | 你的圖書館   |
| **Calendar** | 時間  | 你的時間軸   |
| **Efforts**  | 行動  | 你的工作台   |

## 筆記（Notes）

知識的最小單位。五種類型：

| 類型 | 記錄什麼 | 範例 |
|------|----------|------|
| **概念 Things** | 概念、工具、框架 | 「12 Week Year」、「Obsidian」|
| **觀點 Statements** | 你的意見、主張 | 「執行力贏過完美計畫」|
| **問題 Questions** | 開放性探索 | 「習慣是怎麼形成的？」|
| **語錄 Quotes** | 別人說的話 | 「媒介即是訊息」|
| **人物 People** | 思考者、創作者 | 「Nick Milo」、「Brian Moran」|

## Maps of Content (MOC)

索引頁，策展連結到相關筆記。不是資料夾——是會成長、會分裂的活文件。

範例：[[Productivity MOC]] 連結到所有生產力相關的筆記。

## 在這套系統中的運作

```
Inbox/           -- 快速捕捉原始想法
    |
    v
Atlas/Sources/   -- 完整原始來源
    |
    v
Atlas/Dots/      -- 從 Source 拆出的原子卡片（5 類）
    |
    v
Atlas/Maps/      -- 透過 MOC 串連相關卡片
```

## 參考資料

- [linkingyourthinking.com](https://www.linkingyourthinking.com/)
