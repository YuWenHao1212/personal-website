---
up: "[[Productivity MOC]]"
collection: Things
related:
  - "[[LYT 框架]]"
  - "[[12 Week Year]]"
created: 2026-02-25
says: "Anthropic 的 AI 命令列工具——讓 AI 不只對話，還能讀寫檔案、執行指令、開發產品"
---

Anthropic 推出的命令列工具（CLI），讓 AI 直接在你的電腦裡工作。

和網頁版 Claude 最大的差別：**網頁版只能「說」，Claude Code 可以「做」。** 你告訴它目標，它會自己讀取檔案、執行指令、寫程式。你是指揮官，不是打字員。

## 參考資料

- [Claude Code 教學：5 分鐘完成安裝與第一個任務](https://yu-wenhao.com/zh-TW/blog/claude-code-tutorial/) — 安裝、產品線比較、使用心得
- [Claude Code 官方文件](https://docs.anthropic.com/en/docs/claude-code)
