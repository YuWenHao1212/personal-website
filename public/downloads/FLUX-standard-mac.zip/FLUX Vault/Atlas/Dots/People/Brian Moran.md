---
up: "[[Productivity MOC]]"
collection: People
related:
  - "[[12 Week Year]]"
created: 2026-01-07
says: "《12 Week Year》共同作者——用短週期框架加速目標執行"
---

*The 12 Week Year* 的共同作者，與 Michael Lennington 合著。

## 核心理念

年度計畫創造了一種虛假的時間充裕感。把規劃視野壓縮到 12 週，你會消除拖延，創造緊迫感。

## 連結

- [12weekyear.com](https://12weekyear.com/)
- 書籍：*The 12 Week Year*（2013）
