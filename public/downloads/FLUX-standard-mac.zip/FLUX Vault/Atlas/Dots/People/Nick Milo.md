---
up: "[[PKM MOC]]"
collection: People
related:
  - "[[LYT 框架]]"
created: 2026-01-07
says: "Linking Your Thinking (LYT) 的創造者——用連結而非分類來組織想法"
---

**Linking Your Thinking (LYT)** 和 Ideaverse 系統的創造者。

## 核心理念

- 用**連結**組織，不用資料夾分類
- **ACE** 結構：Atlas（知識）、Calendar（時間）、Efforts（行動）
- **Maps of Content (MOC)**：連結相關筆記的索引頁
- 筆記是 **Notes**：概念、觀點、問題、語錄、人物

## 為什麼重要

LYT 提供了這套系統的知識管理骨架。你在 `Atlas/` 看到的資料夾結構就是基於他的框架。

## 連結

- [linkingyourthinking.com](https://www.linkingyourthinking.com/)
