> 知識管理區。把想法和資料沉澱成可以重複使用的知識卡片。

## 結構

```
Atlas/
├── Sources/    完整的原始出處（書 / 文章 / 影片 / Podcast / 講座 / 課程 / 論文）
├── Dots/       從 Source 拆出的原子知識點（5 類）
├── Maps/       MOC 索引頁（3+ 張相關卡片就建一張 MOC）
└── log.md      歸檔記帳本
```

**比喻**：
- **Sources** = 書櫃（完整的書）
- **Dots** = 你在書上畫的重點（一張卡一個重點）
- **Maps** = 你自己整理的書單 / 索引
- **log.md** = 每次歸檔記一筆帳

---

## Sources/（出處清單）

7 個子資料夾對應來源類型：

| 資料夾 | 放什麼 |
|---|---|
| `Articles/` | 網路文章、Blog、Newsletter |
| `Books/` | 書 |
| `Videos/` | YouTube、影片、線上課錄影 |
| `Podcasts/` | Podcast 節目 |
| `Courses/` | 課程 |
| `Talks/` | 演講、研討會 |
| `Papers/` | 論文 |

**一個來源 = 一個檔案**。檔名：`YYYY-MM-DD-主題關鍵字.md`

---

## Dots/（知識小抄，5 類）

| 資料夾 | 放什麼 | 判斷規則 |
|---|---|---|
| `Things/` | 概念、工具、方法 | 這是什麼？ |
| `Statements/` | 觀點、原則、主張 | 我相信什麼？ |
| `People/` | 人物卡片 | 是在講一個人嗎？ |
| `Questions/` | 待查問題 | 是明確「以後要查」嗎？ |
| `Quotes/` | 引言 | 是某人說的一句話嗎？ |

**判斷順序**：人 → 引言 → 問題 → 主張 → 其他都 Things

---

## 歸檔流程（手動 SOP）

讀完一本書、一篇文章、一支影片，想留下來，按這個順序：

1. **建 Source** — 在 `Atlas/Sources/{type}/` 建檔，檔名 `YYYY-MM-DD-主題關鍵字.md`，frontmatter 填 `up`（連到哪張 MOC）、`type`、`url`、`author`、`created`、`status`
2. **拆 Dots** — 把關鍵概念 / 主張 / 引言 / 人物 / 待查問題各自拆成一張原子卡，放到 `Atlas/Dots/{類別}/`；檔名是斷言，不是主題名
3. **連 MOC** — 在 `Atlas/Maps/` 找對應 MOC，把新卡片加進去；如果同主題已有 3+ 張卡片但還沒 MOC，建一張
4. **寫 log** — 在 `Atlas/log.md` append 一段紀錄：`## YYYY-MM-DD HH:MM | 主題` + 來源 + 新增 Dots + 矛盾（如有）

> 不確定怎麼起手？看範例：[[Sources/Books/2026-01-15-Atomic Habits]]、[[log]]。

---

## 卡片規範

- **一卡一概念**，50-300 字；超過 500 字就拆
- **不寫 H1 標題**（Obsidian 檔名就是標題），開頭直接寫定義段落
- **檔名是斷言**，不是主題名：
  - ✅ `30 歲轉職的三個信號.md`
  - ❌ `轉職筆記 1.md`
- **`says` 一句話 15-30 字**，獨立可讀
- **`source`** 連回 `Atlas/Sources/`，**絕對不要**連 `Inbox/`（會變 ghost link）
- **`## 參考資料`** 放在最底部
