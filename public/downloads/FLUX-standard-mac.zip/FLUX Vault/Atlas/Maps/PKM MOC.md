---
created: 2026-01-07
---

個人知識管理——如何捕捉、組織、運用你學到的東西。

---

## 框架

- [[LYT 框架]] -- Linking Your Thinking（ACE + Notes + Maps）

## 人物

- [[Nick Milo]] -- LYT 創造者

---

## 知識在這套系統中的流動

```
Inbox/           -- 原始捕捉（靈光一閃、連結、語錄）
    |
    v
Atlas/Sources/   -- 完整原始來源
    |
    v
Atlas/Dots/      -- 從 Source 拆出的原子卡（5 類）
    |
    v
Atlas/Maps/      -- 透過 MOC 串連
    |
    v
Efforts/       -- 應用到實際工作中
```
