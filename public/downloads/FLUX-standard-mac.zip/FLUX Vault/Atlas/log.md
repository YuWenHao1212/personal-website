> Atlas 歸檔記帳本。歸檔時在這 append 一段紀錄。
> 格式：`## YYYY-MM-DD HH:MM | 主題` + 來源 + 新增 Dots + 矛盾。

---

## 2026-01-15 21:30 | Atomic Habits 第 1-3 章

- 來源：[[2026-01-15-Atomic Habits]]
- 新增 Dots：[[習慣的四個階段]]
- 矛盾：無

> 上面這段是範例。第一次歸檔之後，新紀錄 append 在下方。
