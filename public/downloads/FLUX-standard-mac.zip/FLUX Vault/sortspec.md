---
sorting-spec: |
 target-folder: /
 Home
 Inbox
 Cockpit
 Efforts
 Calendar
 Atlas
 Guides
 Templates
 %
 CLAUDE
 sortspec
---
