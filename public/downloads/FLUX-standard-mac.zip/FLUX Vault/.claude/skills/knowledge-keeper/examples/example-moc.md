# MOC 範例

這是 `Atlas/Maps/個人效率 MOC.md` 的完整樣子。

---

## 檔案內容

```markdown
---
up:
created: 2026-04-16
---

個人效率 — 怎麼讓每天的時間和注意力產出更多。範圍涵蓋時間管理、注意力分配、工具選擇、溝通流程。

---

## Things

- [[催辦郵件的三段式結構]]
- [[12 Week Year]]
- [[Lead 與 Lag 指標]]
- [[Hook-First 寫作方法]]

## Statements

- [[執行力贏過完美計畫]]
- [[LINE 已讀不回不等於客戶無意願]]
- [[控制 Lead、結果是副產品]]

## People

- [[Brian Moran]]
- [[Nick Milo]]

## Questions

- [[為什麼長文章 SEO 比短文章好？]]
- [[為什麼 LINE 已讀不回不等於客戶拒絕？]]

## Quotes

- [[行動是抗焦慮的解藥]]
```

---

## 解析

**檔名**：`個人效率 MOC.md`
- ✅ 主題名 + 空格 + `MOC`（FLUX 慣例）

**Frontmatter 極簡**：
- `up:` 留空（這是最上層的 MOC、沒有更上層的）
- `created:` 建檔日期
- 對齊 FLUX `Templates/Map-Template.md` 風格

**第一段**：一句話描述主題範圍
- 不寫 H1
- 直接給讀者「這個 MOC 涵蓋什麼、不涵蓋什麼」

**五區塊結構**：
- Things / Statements / People / Questions / Quotes 五個 H2
- 每區塊列 wikilinks
- 空的區塊可以省略（例：純人物 MOC 可能沒 Quotes）

**什麼時候建這個 MOC**：
- 累積 ≥ 3 張相關 Dot 卡才建（1-2 張還不用）
- 上面這個 MOC 有 12 張卡 → 已經是成熟 MOC
- 剛開始累積到 3-5 張時就建、之後新卡會自然找到家

**MOC 是會分裂的活文件**：
- 上面這個 MOC 之後可能拆成「時間管理 MOC」+「個人品牌 MOC」+「客戶溝通 MOC」
- 拆的時機：某類別超過 8-10 張卡、開始難掃描時
