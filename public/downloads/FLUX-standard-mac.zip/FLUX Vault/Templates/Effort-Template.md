---
status: active
created: {{date}}
---

## 這是什麼

（一段話描述這個 Effort 的目的。）

## 對應 Goal

> 這個 Effort 服務 [[12-WEEK-PLAN]] 的哪個目標？沒有 → 它可能不該活在 Active（考慮搬 Idle / Sleeping）。

- **對應目標**：（例：目標 1：把運動從「想到才做」變成「每週固定」）
- **本 Effort 負責的 Lead Indicators**：
  -

> Areas 通常服務同一個 12 週目標多輪、Projects 通常綁 1 個目標、可能跨 1-2 輪 12 週循環。

## 目前狀態

-

## 重要檔案

| 檔案 | 用途 |
|------|------|
|  |  |
