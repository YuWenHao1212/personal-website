> 當前 12 週週期的 2-3 個目標 + Lead/Lag Indicators。
> 由 [[VISION]] 衍生 — 確認 12 週後想看到的進展對齊長期方向。

---

## 週期資訊

- **12 週期間**：YYYY-MM-DD（Www）~ YYYY-MM-DD（Www）
- **WAM 日**：每週X（每週最後一天）

| Week | 起訖 | WAM 日 |
|------|------|--------|
| W1  | MM/DD - MM/DD | MM/DD |
| W2  | MM/DD - MM/DD | MM/DD |
| W3  | MM/DD - MM/DD | MM/DD |
| W4  | MM/DD - MM/DD | MM/DD |
| W5  | MM/DD - MM/DD | MM/DD |
| W6  | MM/DD - MM/DD | MM/DD |
| W7  | MM/DD - MM/DD | MM/DD |
| W8  | MM/DD - MM/DD | MM/DD |
| W9  | MM/DD - MM/DD | MM/DD |
| W10 | MM/DD - MM/DD | MM/DD |
| W11 | MM/DD - MM/DD | MM/DD |
| W12 | MM/DD - MM/DD | MM/DD |

> ⚠️ W1-W12 必須全部展開寫具體日期（不要寫 `...`），讓 daily skill 比對方便。

---

## 目標 1：[一句話描述]

**對應 VISION 面向**：（健康與體能 / 技能與學習 / 職涯與收入 / 人際與關係 / 生活方式）
**對齊 VISION 的哪句話**：「[從 VISION.md 3 年願景或 10 年願景複製一句]」

**Lag Indicator**（追求的結果，無法直接控制）：
- 例：體脂降到 20%

**Lead Indicators**（你能 100% 控制的行動，2-3 個）：
- 例：每週重訓 3 次
- 例：每週有氧 2 次（30 min 以上）

---

## 目標 2：[一句話描述]

**對應 VISION 面向**：
**對齊 VISION 的哪句話**：「」

**Lag Indicator**：
-

**Lead Indicators**：
-
-

---

## 目標 3：[一句話描述]（選填，最多 3 個）

**對應 VISION 面向**：
**對齊 VISION 的哪句話**：「」

**Lag Indicator**：
-

**Lead Indicators**：
-
-

---

## 判斷 Lead vs Lag

| 問題 | 答案 |
|------|------|
| 「我做這個行動，它一定會發生嗎？」 | 是 → Lead；否 → Lag |
| 「這取決於別人嗎？」 | 否 → Lead；是 → Lag |

> 範例：「體脂降到 20%」是 Lag（取決於身體反應）。能控制的是「每週重訓 3 次」= Lead。
> 詳見 [[Lead 與 Lag 指標]]。

---

**Created**: YYYY-MM-DD
