---
order: 4
---

每天起床不知道該先做什麼？每日規劃解決這個問題。每天早上花 5 分鐘，從週計畫中挑出今天要推進的事，剩下的時間就專心做。

---

## 模板

每篇每日筆記的結構如下：

```
## 今日焦點
> 今天我一定要完成的那件事是什麼？

## 任務
（表格：任務、目標、預估時間、備註）

## 筆記
（白天隨手記下的想法）

## 結束回顧
- 已完成
- 移到明天
- 今天學到的
```

完整模板請見 [[Daily-Template]]。

---

## 早上流程（5-10 分鐘）

1. **補昨天的 sync（fallback）** ⭐
   - 開昨天的 `Cockpit/Daily/YYYY-MM-DD.md`、看「已完成」清單
   - 對每項看「對應 Lead Indicator」欄、到 [[Weekly-Commitment]] 補打勾
   - 為什麼：人常忘了跑晚間回顧。這步是 fallback、確保 Weekly-Commitment 不脫節 ≥ 24 小時。如果昨晚有跑回顧、這步通常 no-op（已勾過）
2. **在 `Cockpit/Daily/` 建立今天的筆記**（檔名：`YYYY-MM-DD.md`）
3. **查看 [[Weekly-Commitment]]** — 這週有哪些 Lead Indicators 要完成？
4. **掃描可用任務來源**（不要只看 Lead Indicators、要看實際可推進的事）：
   - **`Efforts/Areas/`** — 永續領域（範例：[[Health/README|Areas/Health]]）、每個 README 看「對應 Goal」section、判斷今天可推進什麼
   - **`Efforts/Projects/Active/`** — 進行中專案（範例：[[English Learning/README|Projects/Active/English Learning]]）、看最新進度判斷下一步
   - **[[BACKLOG]]** — 有沒有適合今天順手做的？
   - **`Inbox/`** — 如果累積筆記、可以順手處理 1-2 則
   > ⚠️ 不要讀 `Efforts/OVERVIEW.md`、它可能沒同步、**目錄結構才是 SSOT**
5. **挑 1-3 個任務**，選擇能真正推進本週 Lead Indicators 的事
   - 每個任務在 Daily-Template 表格的「對應 Lead Indicator (commitment)」欄填上本週對應的 Lead 名稱（晚上回顧時要用）
6. **設定你的那件事** — 如果今天只能完成一個任務，哪一個最重要？

---

## 白天

- **執行任務**，照你的每日筆記走
- **捕捉靈感**到 `Inbox/`（不要為了整理而打斷你的工作節奏）— 完整流程見 [[06-Knowledge-Capture]]
- **在筆記區隨手記錄**，有什麼想法就寫下來

---

## 晚上回顧（5 分鐘）

1. **勾選完成的任務**
2. **同步到 [[Weekly-Commitment]]** ⭐
   - 對「已完成」清單每項任務、看 Daily-Template 表格的「對應 Lead Indicator (commitment)」欄
   - 對應到本週某個 Lead Indicator → 到 [[Weekly-Commitment]] 那條打勾
   - 「對應」欄空白 → 補標、或承認這項是 Bonus（WAM Step 4 處理）
   - 這是 **Daily ↔ Weekly-Commitment 的 sync hook、WAM 計分用這個**。沒同步 = WAM 分數會低估
3. **把未完成的任務移到明天**
4. **寫下 1 個學到的東西** — 今天教會了你什麼？

---

## Daily Note vs Journal

這個 Vault 有兩種每日書寫：

| | Daily Note（每日筆記） | Journal（日記） |
|---|---|---|
| **位置** | `Cockpit/Daily/` | `Calendar/Journal/` |
| **用途** | 工作規劃 + 任務追蹤 | 個人反思 |
| **模板** | [[Daily-Template]] | [[Journal-Template]] |
| **頻率** | 每個工作日 | 隨時想寫就寫 |
| **內容** | 任務、筆記、回顧 | First Light、Last Light、自由書寫 |

你可以兩種都用，或只用一種。它們服務不同的需求。

---

## 用 AI 加速

不想手動挑任務？告訴 AI「規劃今天」，它會讀你的 Weekly-Commitment，自動生成今天的筆記。詳見 [[08-Upgrade-with-AI]]。

> AI 跑「規劃今天」/「回顧今天」的**完整 SOP 與反向 sync 規則**寫在 vault 根目錄的 `CLAUDE.md`（早上 fallback、晚間 sync hook、Effort 掃描順序、不讀 OVERVIEW.md 等）。本指南只是學員視角的精簡版。要客製 AI 行為 → 改 `CLAUDE.md`。

---

## 小技巧

- **不要過度規劃。** 3 個任務比 10 個任務但 7 個沒完成好得多。
- **那件事不可妥協。** 即使是糟糕的一天，也要完成那一件事。
- **學習是複利。** 每天的小洞見，幾週後就會累積成智慧。
