---
order: 5
---

計畫訂了卻沒人追蹤，三週後就忘了——這是大多數目標失敗的原因。WAM（Weekly Accountability Meeting）每週花 15-25 分鐘回顧進度、調整方向，讓你不會偏離軌道。

---

## 什麼時候做

選一個固定的時間和日子。建議：
- **週日晚上** — 規劃下一週
- **週一早上** — 全新的開始
- **週五下午** — 收尾本週

哪一天不重要。持續做才重要。

---

## 8-step 流程

### Step 0：確認今天是 WAM 日

打開 [[Weekly-Commitment]]，看「本週」section 確認今天是 WAM 日。如果不是，但你還是想跑，沒問題（系統會問你確認）。

### Step 1：計分（3 分鐘）

數本週 Lead Indicators (commitments) 完成幾項。

```
完成率 = 完成數 / 總數 × 100%
```

誠實面對——半完成的不要打勾。

### Step 2：回顧三問（5 分鐘）

- **什麼做法有效？**（是什麼條件讓你做到的？時段、精力、環境、工具？）有效的做法，加倍投入。
- **什麼沒做到？**（具體一點：「太忙」→ 哪件事佔了時間？能避免嗎？）不批判，只收集數據。
- **下週要調整什麼？**（如果上週才剛調整，建議再觀察 1-2 週）

### Step 3：Carry-over 強制決定 ⭐

每項未完成的 Lead Indicator 強制四選一：

- **做** → 排進下週（加 `⟲N` 標記 carry 次數）
- **拆** → 太大，拆成子任務，第一個進下週
- **延** → 標確定週次，搬去 BACKLOG
- **砍** → 不做了，從來源刪除

> **強制規則**：連續 2 週 carry-over（`⟲2`）→ 不准再 carry。必須砍/拆/延三選一。避免「做不到 → 再 carry → 永遠在 carry」的鬼打牆。

**⚡ 反向 sync 到 12-WEEK-PLAN**（砍/拆 時必做）：

每次選「砍」或「拆」、要問自己：

| 動作 | 問題 | 處理 |
|------|------|------|
| **砍** | 「這項下週也不帶、要不要從 [[12-WEEK-PLAN]] 也砍？」 | OK → 同步刪 12-WEEK-PLAN 對應目標下那條 Lead；不 OK → 提醒「下週新建 Weekly-Commitment 又會抄回來、要再砍一次」 |
| **拆** | 「拆出來的子任務要回填 12-WEEK-PLAN 嗎？」 | 通常 yes → 同步加進 12-WEEK、舊的標砍 |
| **做** / **延** | — | 不動 12-WEEK-PLAN |

> 為什麼：[[12-WEEK-PLAN]] 是「整季戰略」、是 Weekly-Commitment 的源頭。砍 Weekly-Commitment 卻不砍 12-WEEK → 下週新 Weekly-Commitment 又被抄回來 → 鬼打牆。

### Step 4：Bonus 升級檢查 ⭐

問自己：「這週有沒有計畫外但很重要、想下週正式排進去的事？」

這些「計畫外完成」叫 **Bonus**。如果同主題的 Bonus **連續 2 週**出現 → 下週把它正式 lock 為 Lead Indicator。

> 為什麼：Bonus 是真實重要的訊號。連續出現 = 它本來就該排進來，是你沒看到。

**⚡ 反向 sync 到 12-WEEK-PLAN**（lock 時必做）：

lock 為下週 Lead Indicator 的同時、**同步加進 [[12-WEEK-PLAN]]** 對應目標下：

- 不確定屬於哪個目標 → 問自己「這項對應到 VISION 的哪個面向？」對應到的那個 12-WEEK 目標就是它的家
- 如果完全找不到對應目標 → 可能本季 12-WEEK-PLAN 漏了一個目標、或這項其實該歸 Bonus 不該升 Lead

### Step 5：BACKLOG ≥4 週清理 ⭐

掃 [[BACKLOG]]，看每項的 `(YYYY-MM-DD added)` 後綴。**今天 - added 日期 ≥ 28 天**的項目，強制四選一：

- **拉進下週** → 進下週 Lead Indicators
- **拆小** → 太大，拆成可執行的小步驟
- **砍掉** → 不做了，刪除

> 為什麼：BACKLOG 不能變垃圾堆。≥4 週沒動 = 它不是真的想做，要不就是太大不知怎麼開始。

### Step 5.5：Effort 對齊檢查 ⭐

掃 `Efforts/Areas/` 和 `Efforts/Projects/Active/`，每個 README 看「對應 Goal」section：

| 狀態 | 處理 |
|------|------|
| ✅ 對應當前 12-WEEK 目標 | 留 Active |
| ⚠️ 對應欄空白 / 對應舊目標 | 問：「下週要分配時間嗎？不要 → 搬 `Projects/Idle/`」 |
| ❌ 確認不投入 | 搬 `Projects/Sleeping/` 或 `Idle/` |
| 🎉 已完成 | 搬 `Efforts/Projects/Done/`（README 加完成日期） |

> 為什麼：`Projects/Active/` 是「本季戰略執行位」，不是「我曾經想做的事大集合」。Effort 漂離戰略 → 佔心智頻寬沒產出。WAM 每週掃一次強制做決定。

### Step 6：Lock 下週 Lead Indicators

整合進下週的 Lead Indicators：
1. Carry-over 決定為「做」或「拆」的
2. Bonus 升級項（同步寫進 [[12-WEEK-PLAN-Template|12-WEEK-PLAN]]，見 Step 4）
3. BACKLOG 拉進來的
4. 全新項目

**數量限制**：3-5 個。

> 結構參考 [[12-WEEK-PLAN-Template]]（目標 1/2/3 分組、每個目標下 2-3 個 Lead）。下週 Weekly-Commitment 的 Lead 一律從 12-WEEK-PLAN 的當期目標群延伸 — 不要憑空多一條「不對應任何 12-WEEK 目標」的 Lead。

### Step 7：寫進 Weekly-Commitment.md

把本週搬到「歷史紀錄」section，新建上方為下週 Lead Indicators。

### Step 8：收尾

明天開始說「規劃今天」或 `/daily`。

---

## Phase Review（W4 / W8 / W12）⭐

每 4 週、WAM 加跑一段 **Vision Reconnect**（5-10 分鐘）。把鏡頭從週拉到月、從月拉到季、從季拉到 10 年。

| Week | 加跑的事 |
|------|---------|
| **W4** | 第一個 month 跑完。Lead Indicator 設計合理嗎？哪個目標明顯失準？ |
| **W8** | 中期檢視。最後 4 週要硬推、還是承認某目標收手？ |
| **W12** | 完整循環回顧 → 跳「[[#12 週循環收尾（W12）]]」 |

### Vision Reconnect 流程

1. **讀 [[VISION]]**（10 年 + 3 年願景 + Anti-Vision + 核心價值觀）
2. **問自己**：「目前的 12 週目標還在服務這個願景嗎？有沒有哪個目標其實已經偏離方向？」
3. **依答案處理**（反向 sync 到 VISION 的判定樹）：

| 自我答 | 動作 |
|--------|------|
| 「方向沒偏」 | 不動 VISION、繼續本季 12-WEEK |
| 「VISION 本身要改」（10 年 / 3 年願景變了） | 帶改 [[VISION]] 對應段落、加 update 註記（`> YYYY-MM-DD update: ...`）。**本季 12-WEEK 不動** |
| 「VISION 不變、12-WEEK 目標排錯了」 | 提醒「下個循環重新規劃時調整」、**本季 12-WEEK 不動**（避免中途換戰略導致紀律崩盤） |

> 原則：VISION 是長期方向、不頻繁改。但偏了不反映現實也不對。Phase Review 是強制檢查點、不讓「目標漂離方向」無聲地過 12 週。

---

## 分數解讀

| 分數 | 意義 | 行動 |
|------|------|------|
| **85%+** | On Track | 維持節奏 |
| **70-84%** | Below Target | 微調 |
| **65-69%** | 黃燈 | 需要注意，找原因 |
| **低於 65%** | 紅燈 | 大幅調整。承諾太多？目標不切實際？ |

---

## 模板

使用 [[WAM-Template]] 進行結構化的 WAM（含 Lead/Lag 計分、Vision Reconnect、Phase Review）。

---

## 用 AI 加速

告訴 AI「WAM」，它會自動讀取你的 Weekly-Commitment、計算分數、帶你走完 8 個步驟。詳見 [[08-Upgrade-with-AI]]。

> AI 跑 WAM 的**完整 SOP 與反向 sync 規則**寫在 vault 根目錄的 `CLAUDE.md`（Step 3 砍/拆 12-WEEK 同步問句、Step 4 Bonus 升級寫回、Step 5.5 Effort 對齊處理、Phase Review/W12 循環收尾的判定樹等）。本指南是學員視角的精簡版。要客製 AI 行為 → 改 `CLAUDE.md`。

---

## 常見陷阱

| 陷阱 | 解法 |
|------|------|
| 「就跳過這一週」 | 永遠不要跳過。就算只花 5 分鐘的精簡版也比什麼都不做好 |
| 對低分感到沮喪 | 分數是回饋，不是成績。調整然後繼續前進 |
| 不誠實 | 把半完成的項目打勾會汙染你的數據 |
| 過度調整 | 給改變 2-3 週的時間，再來判斷效果 |
| 連續 carry-over 同一項 | 強制四選一規則：連 2 週沒做 → 不是太大就是不重要，砍掉或拆解 |

---

## 12 週循環收尾（W12）

跑到 W12（12 週結束），WAM 會自動觸發**循環回顧**：

1. 用 [[Review-Template]] 寫一份完整回顧（含 Lag Indicator 結果 + Lead Indicator 12 週平均完成率 + 學到什麼）
2. 把回顧寫到 `Cockpit/Goals/archive/YYYY-MM-DD-cycle-review.md`
3. 接著問「下一輪要調整什麼？準備好的話，我們來設定新的 12 週計畫」→ 重新跑第一次設定，建下一個 12 週的 12-WEEK-PLAN.md
