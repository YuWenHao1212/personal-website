嘿，歡迎。

自從在 Blog 和 Facebook/Threads 記錄自己的工作流之後，不時有讀者來問：「你的系統怎麼建的？我也想要一套。」

問的人越來越多，我決定把它打包成一個可以直接用的 Vault——就是你現在打開的這個。我把它叫做 **FLUX**。

> **F**ocus 專注目標 · **L**earn 連結知識 · **U**pgrade 迭代升級 · e**X**ecute 每日執行

一套讓你把知識、目標和行動串在一起的個人作業系統。每 12 週一個循環，讓你不斷趨近想成為的那個自己。

---

## 你可能也是這樣

年初設了目標，三月就忘了。筆記散落在 Notion、Google Docs、手機備忘錄，需要的時候找不到。每天起床打開電腦，不確定該先做什麼。

不是你不夠努力，是缺一套系統把這些碎片串起來。

用了 FLUX 之後，我的日常變成這樣：

```
我：規劃今天

Claude：本週 Lead Indicators 還有 2 項未完成（重訓、寫 500 字練習文），
        加上昨天 carry-over 的「讀完 1 章書」。
        建議今日任務：
        1. 讀完《Atomic Habits》第 4 章（昨天 carry-over）
        2. 去健身房練腿（本週 Lead Indicator）
        3. 處理 Inbox 中 4 則筆記（知識整理）
```

一句話，30 秒。AI 讀你的本週 Lead Indicators、看你的進度、幫你排好今天的任務。

---

## 跑了三個月的結果

我自己用這套系統三個月：

- **每天 30 分鐘**，早上規劃 + 晚上打勾
- **月 pageview 3K → 150K**（yu-wenhao.com，三個月 50 倍成長）
- **累積 56 篇中文部落格 + 25 篇英文**，節奏穩定
- **從零建了 4 個網站**並上線（yu-wenhao.com、neatoolkit.com、seolens.com、airesumeadvisor.com）
- **WAM 平均 80 分**（每週問責會議，滿分 100）

不是因為我特別有紀律。是系統讓「下一步該做什麼」變得很清楚，你只需要照著做。

---

## FLUX 怎麼組成的

![FLUX 三層架構：方向（Focus）是底座、系統（Learn/Upgrade）疊在上面、槓桿（eXecute）在最上層。底座沒打好、上面都會歪。](_assets/images/flux-three-layers.webp)

三套方法論，兩個工具 — 管行動、管知識、管執行：

**PARA · 管行動**（Tiago Forte《打造第二大腦》）— 用可行動程度分類：Projects 有 deadline、Areas 持續經營、Archive 沉睡舊案 → `Efforts/`（`Projects/Active`、`Areas`、完成 `Projects/Done`、休眠 `Sleeping`）。第四類 **Resources（主題參考）就是 `Atlas/`** — 知識不混進行動層。

**[[02-LYT-Framework|卡片盒筆記]] · 管知識**（Luhmann；LYT 是它的 Obsidian 實現）— 這層正是 PARA 的 Resources，一卡一概念、wikilink 互相連結，筆記越多複利越大 → `Atlas/`。

**[[03-12-Week-Year-Setup|12 Week Year]] + WAM · 管執行** — 10 年願景 → 12 週目標 → 每週 Lead Indicators，週末 WAM 檢討、lock 下週。行動對了，結果是副產品 → `Cockpit/`。

**[[Obsidian]]** — 你整個人生系統的載體。目標、知識、每天的記錄、成長軌跡都在這裡。

**[[Claude Code]]** — 讀懂這一切的 AI。幫你規劃、追蹤、執行、連結，把散落的碎片變成前進的動力。

你只需要做一件事——決定方向。

---

## 你會得到什麼

打開這個 Vault，你馬上有：

- **現成的資料夾結構** — 不用從零設計，打開就能用
- **目標管理模板** — 願景、12 週計畫、每週計分卡，全部預建好
- **填好的範例** — 每個模板都有真實範例，看到「填好的樣子」才知道怎麼寫自己的
- **AI 自動化流程** — 一句話規劃今天、一句話執行週會、一句話記錄想法（需設定 AI CLI，詳見 [[08-Upgrade-with-AI]]）
- **知識管理系統** — 捕捉想法、建立連結、持續累積
- **9 篇教學指南** — 每個模組都有說明，不怕不會用

---

## 準備好了？

→ [[01-Quick-Start]]，10 分鐘了解整套系統，然後開始你的第一個 FLUX 循環。

---

## 設定好之後，你的日常就這麼簡單

- **規劃今天** → 告訴 AI「規劃今天」
- **記錄一個想法** → 告訴 AI「記錄一個想法」
- **檢視我的目標** → 打開 [[12-WEEK-PLAN]] 或 [[Weekly-Commitment]]
- **每週問責** → 告訴 AI「執行 WAM」
- **不確定怎麼用？** → 瀏覽 `Guides/` 資料夾

---

## 延伸閱讀

想了解更多背後的思路，這幾篇是我寫過最完整的：

- [多數人學 AI 的順序反了：先方向、再系統，AI 才是槓桿](https://yu-wenhao.com/zh-TW/blog/flux-direction-system-leverage/?utm_source=flux-vault-standard&utm_medium=vault) — FLUX 的核心理念
- [年度目標總是失敗？我用 Claude Code 建了一套目標管理系統](https://yu-wenhao.com/zh-TW/blog/ai-goal-management-system/?utm_source=flux-vault-standard&utm_medium=vault)
- [12 Week Year 完整指南](https://yu-wenhao.com/zh-TW/blog/12-week-year-guide/?utm_source=flux-vault-standard&utm_medium=vault)
- [從 Obsidian 到 Claude Code：打造可程式化的人生](https://yu-wenhao.com/zh-TW/blog/personal-panopticon/?utm_source=flux-vault-standard&utm_medium=vault)
- [用了 5 年 Roam Research，為什麼在 AI 時代我選擇 Obsidian？](https://yu-wenhao.com/zh-TW/blog/roam-research-to-obsidian/?utm_source=flux-vault-standard&utm_medium=vault)
- [Claude Code 教學：5 分鐘完成安裝與第一個任務](https://yu-wenhao.com/zh-TW/blog/claude-code-tutorial/?utm_source=flux-vault-standard&utm_medium=vault)

---

## 做這個的人

科技業十多年，從工程師到 PM 到數據分析。2025 年開始用 AI 一個人做產品——四個月做完一個 SaaS，三天上線一個免費工具站。

目前是 **AI 工作流導入的企業講師與顧問**。FLUX 是我每天在跑的工作系統，也是我帶企業和個人導入 AI 的底層方法——結合知識管理、目標執行和 AI，讓我第一次對自己的人生有了掌控感。

**Yu-WenHao**
- 📥 **每週一封實戰信** → [訂閱 Newsletter](https://yu-wenhao.com/?utm_source=flux-vault-standard&utm_medium=vault&utm_campaign=newsletter) — 我怎麼用這套系統 + AI 的真實紀錄
- [個人網站](https://yu-wenhao.com/?utm_source=flux-vault-standard&utm_medium=vault) — 完整故事
- [NeatToolkit](https://neatoolkit.com) — 免費線上工具

---

## 卡住的時候

這些內容沒有藏私——你現在看到的就是完整版。

但新系統總會有摸不清楚的地方。卡住的時候：

1. 先翻 `Guides/` 裡對應的那一份教學
2. 問你手邊的 Claude Code（`CLAUDE.md` 已經教它怎麼帶你）
3. 還是卡 → 寫信到 [mail@yu-wenhao.com](mailto:mail@yu-wenhao.com)，或到 [yu-wenhao.com](https://yu-wenhao.com) 找我
