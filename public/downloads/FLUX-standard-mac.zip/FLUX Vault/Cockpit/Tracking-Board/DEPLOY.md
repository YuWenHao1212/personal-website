# FLUX Tracking Board — 部署說明

FLUX Tracking Board：一頁式個人任務看板 — Backlog → Todo → In Progress → Done（＋Blocked 停車格），附本週 Score 與結算封存。
跑在你自己的 Cloudflare 帳號上（免費方案就夠），資料存在看板專屬的雲端小資料庫（Durable Object，SQLite）。

> 本檔 = 部署＋API 使用說明（給 Claude 照做）。**請保持檔名 `DEPLOY.md`** — `BOARD-MODE.md` 與啟用流程都指名讀它。
> 這是什麼、要不要啟用 → 看同資料夾的 `README.md`。

## 需要的東西

- Cloudflare 帳號（免費）
- Node.js（含 npx）— 建議裝最新 LTS；部署工具（wrangler）需要 Node 22 以上，版本太舊它會明確擋下並告訴你怎麼升級

## 部署一步

在這個資料夾（`wrangler.toml` 所在位置）打開終端機：

```bash
npx wrangler deploy
```

第一次跑會跳出瀏覽器要你登入 Cloudflare 授權 — 授權完它會接著部署。
跑完會印出網址（`https://tracking-board.你的子網域.workers.dev`），打開就是你的看板。

不用建資料庫、不用貼任何 id — 看板資料的儲存空間（Durable Object）會在第一次使用時自動長出來。

> ⏳ 剛部署完的前幾分鐘，網址偶爾會回 404 或 `error code: 1042`（雲端還在佈點），連續失敗兩三次也正常 — 等 30 秒再試，不是你做錯。

## 建卡：走 API（給 Claude 用）

看板上沒有「新增」按鈕 — 建卡是 Claude 的工作。把你的看板網址給 Claude，請它幫你開卡：

```bash
curl -X POST "https://tracking-board.你的子網域.workers.dev/api/issues" \
  -H "content-type: application/json" \
  -d '{"fields":{
    "title": "彙整本週門市銷售週報",
    "type": "task",
    "priority": "P1",
    "status": "todo",
    "week": "2026-W29",
    "effort": "Efforts/Projects/Active/月活動表",
    "tags": ["週報"],
    "due": "2026-07-17",
    "body": "- [ ] 收齊各店檔案\n- [ ] 彙整成表"
  }}'
```

（實際使用時，`fields` 旁請照下方「寫入安全」多帶一個 `"expectedRev"`。）

`fields` 裡的欄位都可省略（有預設值）。常用欄位：

| 欄位 | 值 | 說明 |
|---|---|---|
| `title` | 文字 | 卡片標題 |
| `status` | `backlog` / `todo` / `in-progress` / `done` / `blocked` | 不給 = `backlog` |
| `type` | `task` / `bug` / `feature` / `chore` | 不給 = `task` |
| `priority` | `P0`–`P3` | 不給 = `P2` |
| `week` | ISO 週，例 `2026-W29` | 掛了才進本週 Score |
| `effort` | `Efforts/Areas/…` 或 `Efforts/Projects/Active/…` | 看板依它自動分組 |
| `tags` | 陣列，例 `["週報"]` | 特殊 tag：`seed` = 未來再說（虛線卡、不計分）、`bonus` = 額外做的（不計分） |
| `due` / `body` | 日期 / Markdown | 選填 |

其他 endpoints（改卡、留言、封存也都能請 Claude 代打）：

```
GET    /api/issues                 整包看板
GET    /api/score?week=2026-W29    某週 Score（省略 week = 本週）
GET    /api/archive                封存卡
PATCH  /api/issues/:id             {"fields":{...}} 改卡（改 status、補 week…）
POST   /api/issues/:id/comments    {"comment":{"text":"..."}} 留言
POST   /api/issues/:id/archive     封存
POST   /api/issues/:id/unarchive   還原
GET    /api/northstar              北極星（12 週目標＋Lag；null = 未設定、板頭整條隱藏）
PATCH  /api/northstar              {"northstar":{...}} 整包替換（null = 清除）
PUT    /api/issues                 {"blob":{...}, "archive":{...}, "expectedRev":N} 整包匯入
                                   （搬家／備份還原用，見下方「換網址」與附錄；expectedRev 必填）
```

**北極星欄位**（SoT 在 vault 的 `12-WEEK-PLAN.md`／`Weekly-Commitment.md`，板上只是投影 — 一律整包替換）：

```json
{"northstar": {
  "season": "2026 Q3",
  "season_start": "2026-06-29",
  "weeks_total": 12,
  "goals": [
    {"title": "目標一句話（12-WEEK-PLAN 目標標題）",
     "vision": "對齊 VISION 的那句話（tooltip 用、可省略）",
     "lag": {"name": "Lag 名稱", "current": "45%", "target": "100%"}}
  ]
}}
```

- `season_start` = W1 起日（板頭 W{n}/12 由它自動推算，不用每週改）
- `goals[].lag.current` = Weekly-Commitment「Lag 觀察表」的目前值 — **每次 WAM 更新一次**（Step 7）

### 寫入安全（expectedRev — 給 Claude 的必守規則）

看板的儲存端會把所有寫入排成一列（一次處理一筆），但「你讀取之後、寫入之前，板子被別的視窗或另一個 Claude 改過」這種邏輯衝突還是要靠版本號擋。所以：

1. **寫入前先 `GET /api/issues`**，回應的 `meta.rev` = 目前版本號
2. **每筆寫入（POST / PATCH / PUT）body 都帶 `"expectedRev": <那個 rev>`**（跟 `fields` / `comment` 並列）
3. 每筆寫入成功的回應都有新的 `rev` — 連續寫入就一路帶下去（不用重新 GET）
4. 收到 **HTTP 409** = 板子在你讀取之後被改過：重新 GET 拿最新 `meta.rev`、確認內容沒衝突，再重試
5. **寫入一律一次一件** — 等前一筆回應成功再發下一筆，不要平行發

沒帶 expectedRev 的寫入照舊接受（相容；PUT 例外 — 必帶），但請一律帶。

## 使用備忘

- **跟看板 API 讀寫一律用 curl**：用 python（urllib / requests）打這個網址會被 Cloudflare 擋下（403）。
- **寫入帶 expectedRev、一次一件**：見上方「寫入安全」。
- **網址 = 鑰匙**：沒有登入機制，拿到網址的人就能看能改。自己用沒問題，別把網址公開貼出去。
- **重新整理瀏覽器 = 重載**：看板沒有重載按鈕，Claude 幫你開完卡後，重新整理頁面就看到。
- **Week 欄位**用 ISO 週格式（例：`2026-W29`），掛了 week 的卡才進 Score。
  今天所在的 ISO 週：`TZ='Asia/Taipei' date '+%G-W%V'`（mac / Linux 通用；Windows 學員請 Claude 改用 PowerShell 對應指令）。
  ⚠️ 12-WEEK-PLAN 的 W1~W12 是「季內第幾週」、不是 ISO 週——填卡一律用上面指令換算，別直接搬 W{N}。
- **Effort 欄位**對應你 vault 的路徑（`Efforts/Areas/…` 或 `Efforts/Projects/Active/…`），看板會自動依它分組。
- **換網址／洩漏補救**：⚠️ 跟 v2 不同 — **看板資料綁在 worker 身上，換名字部署 = 全新空板，卡片不會跟過去**。正確順序：
  1. **先備份**：`GET /api/issues` 和 `GET /api/archive` 的回應各存成檔案
  2. 改 `wrangler.toml` 的 `name` 再 `npx wrangler deploy`（= 建新 worker、新網址、空板）
  3. 把備份匯入新板：`PUT /api/issues`，body 帶 `{"blob": <issues 的整包回應>, "archive": <archive 的回應>, "expectedRev": 0}`
  4. `npx wrangler delete --name 舊名字` 刪掉舊 worker，洩漏的網址才失效
  5. 更新 CLAUDE.md 板子設定的網址
- **重置資料**（整板清空、從頭開始）：`npx wrangler delete` 把 worker 連同資料整個刪掉（**不可復原**、含封存區）— 指令會先問「Are you sure? This action cannot be undone.」，回 y 才會刪。刪完再 `npx wrangler deploy` 一次 = 全新空板（同網址）。
- **改欄名**：欄位定義在 `src/worker.js` 最上面的 `STATUSES` 常數（資料庫只存卡片）。改 `name` → `npx wrangler deploy` → 重新整理頁面就生效；`id` 別動（卡片資料綁它）。
- 改完 `public/index.html` 或 `src/worker.js` 後，重跑 `npx wrangler deploy` 就更新。deploy 完的頭幾秒可能還跑到舊版 — 等 5–10 秒再重新整理驗收。**重新部署不會動到卡片資料**（只要沒跑 `wrangler delete`）。

## 附錄：v2（KV 版）看板搬家到 v3

> 只適用「之前部署過 KV 版看板、現在要換這份 v3」的人。全新部署不用看這段。

**先 export、再 deploy — deploy 之後舊版 API 就不在了。** 順序不能反：

1. **Export（趁舊板還在線）**：
   ```bash
   curl -s "https://tracking-board.你的子網域.workers.dev/api/issues"  > board-backup.json
   curl -s "https://tracking-board.你的子網域.workers.dev/api/archive" > archive-backup.json
   ```
2. **Deploy v3**（同一個 worker 名字直接蓋過去）：在這個資料夾 `npx wrangler deploy`
3. **Import**：`PUT /api/issues`，body = `{"blob": <board-backup.json 內容>, "archive": <archive-backup.json 內容>, "expectedRev": 0}`
4. 重新整理看板網頁 → 卡片都在 → 完成。舊的 KV namespace 還留在你帳號裡（沒被刪、當備份），確認沒問題後可自行刪掉。

**已經先 deploy 了怎麼辦？** 資料沒有丟 — 還躺在舊的 KV namespace 裡，只是 API 拿不到了。救回來：

```bash
npx wrangler kv namespace list                    # 找到 BOARD_KV 那筆的 id
npx wrangler kv key get board:v2 --namespace-id <id> --remote > board-backup.json
```

拿回來的 JSON 就是整包看板（`issues` + `archive` 都在裡面），整理成 PUT body 匯入即可（`blob` = `{meta, issues}`、`archive` = `{issues: <archive 陣列>}`）。
