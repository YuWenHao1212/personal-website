# Dot 範例（單張卡片）

這是 `Atlas/Dots/Things/催辦郵件的三段式結構.md` 的完整樣子（搭配 `Atlas/Sources/Articles/2026-05-19-出貨排程新流程.md` 一起看）。

---

## 檔案內容

```markdown
---
up:
  - "[[個人效率 MOC]]"
collection: Things
related:
  - "[[LINE 已讀不回不等於客戶無意願]]"
  - "[[檔期異動要 72 小時內回覆]]"
created: 2026-05-19
says: "催辦郵件分成開場、內容、確認三段，學員讀信速度快且欄位齊全"
---

催辦郵件是對外溝通的標準工具。經過 2026-05 的新流程定義，郵件結構固定為三段：

## 開場（學員資訊）

- 學員姓名、員工編號
- 所屬門市、區域
- 已完成哪些前置課程
- 本次報名的課程名稱、編號

## 內容（時段+講師）

- 建議時段（至少給 2-3 個選項）
- 指派講師（照檔期商品優先順序排）
- 場地（如需實體）
- 教材準備清單

## 確認（回覆期限）

- 請門市於 72 小時內回覆確認檔期（見 [[檔期異動要 72 小時內回覆]]）
- 未回覆的處理方式（進 backlog、下期再排）

## 為什麼要分三段

- 結構固定 → 學員讀信速度快
- 欄位齊全 → 避免來回追問
- 時限明確 → 排程可控

## References

來源：[[Sources/Articles/2026-05-19-出貨排程新流程]]
```

---

## 解析

**檔名**：`催辦郵件的三段式結構.md`
- ✅ 結論式檔名（不是「催辦筆記」）
- ✅ 一句話說清楚這卡講什麼

**路徑**：`Atlas/Dots/Things/`
- ✅ 知識卡片落 `Atlas/Dots/`、不是 `Atlas/Notes/`（這套 vault 沒有 Notes 資料夾）

**`collection`**：填 `Things`（純字串）
- ✅ 純字串、不是 wikilink `"[[Things]]"`
- 這是「方法/結構」、不是人、不是主張、不是引言、不是問題 → 落 Things

**`says`**：「催辦郵件分成開場、內容、確認三段，學員讀信速度快且欄位齊全」
- 25 字（在 15-30 字規格內）
- 句型「X 是 Y 的 Z」變形：「X 分成 Y 三段，特點是 Z」

**`related`** 連到 2 張既有 Dot 卡：橫向連結建立網狀結構。**不連 `Inbox/`**（會變 ghost link）。

**沒有 `source_url` / `source_author` / `source_date` 4 欄**：
- ✅ Dot frontmatter 不放這些 — 來源資訊放 Source 檔
- ✅ Dot 用 `## References` wikilink 連回 Source 檔（`[[Sources/Articles/2026-05-19-出貨排程新流程]]`）
- 這樣半年後想看「這篇文章拆出了哪些卡」可以從 Source 翻、結構乾淨

**配對的 Source 檔長這樣**（`Atlas/Sources/Articles/2026-05-19-出貨排程新流程.md`）：

```markdown
---
up:
  - "[[個人效率 MOC]]"
type: article
url: "https://internal.pqi.example/promo-calendar-guide"
author: "王小美"
created: 2026-05-19
status: read
---

> 小美 2026-05 定義的出貨排程新流程。

## Key Takeaways

- 催辦郵件分成開場、內容、確認三段
- 檔期商品優先順序有三層
- 檔期異動要在 72 小時內回覆

## Dots

- [[催辦郵件的三段式結構]]
- [[檔期商品優先順序有三層]]
- [[檔期異動要 72 小時內回覆]]
- [[門市配貨的三個判斷條件]]

## References

[王小美內部郵件](https://internal.pqi.example/promo-calendar-guide)
```

**Source 和 Dot 互相連結**：
- Dot 的 `## References` 段 wikilink 連回 Source
- Source 的 `## Dots` 段 wikilink 列出衍生 Dot
- 雙向都通、知識網狀結構成形
