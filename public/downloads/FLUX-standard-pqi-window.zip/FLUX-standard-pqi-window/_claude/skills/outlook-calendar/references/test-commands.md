# outlook-calendar 驗收指令（Windows 實機測試用）

> 給講師 / IT 在 PQI 的 Windows 機器上驗證 skill 是否可用。
> 前提：傳統桌面版 Outlook 已登入公司帳號。`<PS1>` = calendar_ops.ps1 絕對路徑。

## 0. 通道測試（第一關）

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" status
```

- 預期：`{"ok": true, "calendar": "行事曆", "events_next_7_days": N}`
- 第一次跑會跳「有程式正在嘗試存取 Outlook」→ 按允許
- 噴 `無法建立 COM 物件` / `80040154` → 電腦是 New Outlook 或沒裝桌面版 Outlook → 整套 COM 方案不可用、回報講師

## 1. 讀行程

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" today
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" read_events -Days 7
```

- 對照 Outlook 行事曆畫面，事件數與時間要一致
- **重點驗證：週期性會議**（每週例會）要出現在正確日期 — 這是 `IncludeRecurrences` 展開邏輯，最容易出問題的地方
- **重點驗證：跨日事件**（例如三天研討會）要出現在中間那天的 `today` 結果裡 — 這是 overlap filter 邏輯
- 若 `read_events` 回傳空但 Outlook 有行程 → 疑似 Restrict 日期格式被系統地區設定影響、把機器的「地區格式」與輸出回報講師

## 2. 搜尋 + 讀單筆

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" search -Query "會議"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" read -EntryId "<上面拿到的 entry_id>"
```

- 中文關鍵字要能命中；`read` 要列出與會者與內文

## 3. 建個人行程（開視窗、不儲存）

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" create_event -Subject "skill 測試（可關掉）" -Start "2026-09-01 15:00" -End "2026-09-01 15:30"
```

- 預期：Outlook 跳出約會視窗、內容正確、`mode: "displayed"`
- **直接關掉視窗不儲存** — 確認行事曆上沒有多出任何東西

## 4. 建會議邀請（開視窗、不送出）

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<PS1>" create_event -Subject "skill 測試會議（勿傳送）" -Start "2026-09-01 16:00" -End "2026-09-01 16:30" -Attendees "<你自己的公司信箱>"
```

- 預期：跳出**會議**視窗（有「傳送」鈕）、收件者已帶入
- **直接關掉不傳送** — 確認沒有任何邀請寄出

## 收尾

**全部通過 = skill 可出貨。** 任何一關卡住，把完整錯誤輸出 + Outlook 版本（檔案 → Office 帳戶）回報講師。
