---
name: outlook-calendar
description: Calendar assistant — 用本機 Outlook（傳統桌面版）看行程、找空檔、建會議。觸發詞：「看我今天的行程」「明天有什麼會」「這週行程」「找空檔」「我下週三有空嗎」「建會議」「排會議」「約會議」或任何行事曆相關請求。透過 PowerShell + Outlook COM 操作，建會議預設只開視窗給使用者確認、絕不直接送出邀請。
---

# Outlook Calendar 工作流（PQI 版）

透過 PowerShell + Outlook COM 操作本機 Outlook 行事曆。跟 outlook-email skill 同一條 COM 通道 — 不需要帳密、不需要設定檔、不需要 IT 開通，**Outlook 桌面版已登入即可用**。

## 前提

- 電腦裝有**傳統桌面版 Outlook**（不是 New Outlook / 網頁版）且已設定好公司帳號
- 建議 Outlook 保持開啟（沒開時 script 會自動啟動它，第一次較慢）
- 第一次使用如果跳出「有程式正在嘗試存取 Outlook」對話框 → 請使用者按「允許」

## 安全規則

- **建會議 = 只開視窗**：`create_event` 預設用 `.Display()` 打開約會視窗，由使用者自己按「儲存」或「傳送」— script 絕不呼叫 `.Send()`
- **`-Save` 只用在兩個條件同時成立時**：純個人行程（沒有與會者）+ 使用者已在對話中明確確認時間與內容
- **不改不刪既有行程**：script 只有讀取與新增，沒有 update / delete 指令
- script 失敗時把錯誤原文回報，不要自行重試超過一次

## 工具指令

Script 位置：此 SKILL.md 同目錄下 `scripts/calendar_ops.ps1`（用絕對路徑）。

執行格式：
```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<絕對路徑>\calendar_ops.ps1" <command> [參數]
```

### 指令速查

| 指令 | 用途 | 主要參數 |
|------|------|---------|
| `status` | 行事曆名稱 + 未來 7 天事件數（通道測試用） | — |
| `today` | 今天的行程 | — |
| `read_events` | 未來 N 天行程（含週期性會議展開） | `-Days 7` |
| `search` | 搜尋主旨 + 地點（支援中文） | `-Query "關鍵字" [-Days 30]` |
| `read` | 讀一筆行程完整內容（與會者 + 內文） | `-EntryId "..."` |
| `create_event` | 建立行程 / 會議邀請（預設開視窗） | `-Subject "..." -Start "yyyy-MM-dd HH:mm" -End "..." [-Location] [-Body] [-Attendees "a@x;b@y"] [-Save]` |

所有指令回傳 JSON（`ok: true/false`，失敗有 `error`）。`-Attendees` 多人用分號分隔（Outlook 慣例）；有帶 `-Attendees` 就變成會議邀請、`-Save` 會被忽略（一律開視窗讓使用者按傳送）。

## 工作流程

### 看行程

- 「今天有什麼會」→ `today` → 按時間列出（時間、主旨、地點）
- 「這週 / 未來幾天」→ `read_events -Days N`
- 「上次跟 XX 的會議是哪筆」→ `search -Query "XX"` → 使用者選一筆 → `read`

### 找空檔（Claude 自己算、不靠 script）

使用者說「找空檔」「我下週三下午有空嗎」時：

1. `read_events -Days N` 拿該範圍所有行程
2. 先問使用者工作時段偏好（不知道就用預設 09:00–18:00、午休 12:00–13:00 不排）
3. 自己從行程空隙算出可用時段、列 2-3 個選項給使用者挑
4. 全日事件（`all_day: true`）要問使用者「這天算可排還是整天不排？」— 不要自己假設

### 建會議

使用者說「建會議」「幫我約 XX」時：

1. 收集：主旨、日期時間、長度、地點（實體 / 線上）、與會者 email、要不要附說明
2. 缺少的欄位問使用者、**不要自己編**（尤其與會者 email）
3. 跟使用者複述一次完整內容、確認後才跑 `create_event`
4. 視窗打開後告訴使用者：「會議視窗已打開，請確認內容後自行按『傳送』（有與會者）或『儲存並關閉』（個人行程）。」
5. **不要說「已送出邀請」** — script 沒有送出能力、送出永遠是使用者自己按的

### 會議 + 通知信的組合

要「建會議 + 寄通知信」時：會議走本 skill `create_event`、通知信走 outlook-email skill `draft`。兩個都是草稿 / 視窗確認、由使用者自己送出。
