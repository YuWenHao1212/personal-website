# calendar_ops.ps1 — Outlook COM calendar operations for PQI (Windows, classic desktop Outlook).
# Same COM channel as outlook-email (outlook_ops.ps1); opens the default calendar folder instead of Inbox.
# HITL by design: create_event only opens the appointment window (.Display) unless -Save is passed.
# This script never calls .Send().
#Requires -Version 5.1
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true, Position = 0)]
  [ValidateSet("status", "today", "read_events", "search", "read", "create_event")]
  [string]$Command,

  [int]$Days = 0,             # read_events / search: days ahead to scan (0 = command default: read_events 7, search 30)
  [string]$Query = "",        # search keyword (subject + location)
  [string]$EntryId = "",      # read
  [string]$Subject = "",      # create_event
  [string]$Start = "",        # create_event: "yyyy-MM-dd HH:mm"
  [string]$End = "",          # create_event: "yyyy-MM-dd HH:mm"
  [string]$Location = "",     # create_event
  [string]$Body = "",         # create_event: plain text agenda / notes
  [string]$Attendees = "",    # create_event: semicolon-separated emails -> becomes a meeting invite
  [switch]$Save,              # create_event: save directly instead of opening the window
  [int]$MaxItems = 200        # read_events / search: hard cap (recurring expansion safety)
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

function Out-Json($obj) { $obj | ConvertTo-Json -Depth 5 }
function Fail($msg) { Out-Json ([PSCustomObject]@{ ok = $false; error = $msg }); exit 1 }

function Parse-When($text, $label) {
  try {
    return [datetime]::ParseExact($text, "yyyy-MM-dd HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)
  } catch {
    throw "$label must be 'yyyy-MM-dd HH:mm' (got: $text)"
  }
}

function Event-Summary($e) {
  [PSCustomObject]@{
    entry_id   = $e.EntryID
    start      = $e.Start.ToString("yyyy-MM-dd HH:mm")
    end        = $e.End.ToString("yyyy-MM-dd HH:mm")
    subject    = $e.Subject
    location   = $e.Location
    all_day    = [bool]$e.AllDayEvent
    organizer  = $e.Organizer
    is_meeting = ($e.Recipients.Count -gt 0)
  }
}

# Standard COM recipe for expanding recurring events:
# Sort by [Start], set IncludeRecurrences, then Restrict to a bounded window.
# Never enumerate an IncludeRecurrences collection without Restrict (it expands forever).
# Overlap filter ([Start] < to AND [End] > from) so in-progress / multi-day events are included
# and an all-day event starting exactly at the upper bound is not.
function Get-EventsInRange($calendar, [datetime]$from, [datetime]$to, $filterText) {
  $items = $calendar.Items
  $items.Sort("[Start]")
  $items.IncludeRecurrences = $true
  $fmt = "g"   # culture-aware short date+time: Outlook parses Restrict dates per system locale
  $filter = "[Start] < '" + $to.ToString($fmt) + "' AND [End] > '" + $from.ToString($fmt) + "'"
  $ranged = $items.Restrict($filter)
  $result = @(); $scanned = 0
  foreach ($e in $ranged) {
    $scanned++
    if ($scanned -gt $MaxItems) { break }
    if ($e.Class -ne 26) { continue }   # 26 = olAppointment
    if ($filterText -and ($e.Subject -notlike "*$filterText*") -and ($e.Location -notlike "*$filterText*")) { continue }
    $result += Event-Summary $e
  }
  return , $result
}

try {
  $ol = New-Object -ComObject Outlook.Application
  $ns = $ol.GetNamespace("MAPI")
  $cal = $ns.GetDefaultFolder(9)   # 9 = olFolderCalendar

  switch ($Command) {

    "status" {
      $now = Get-Date
      $list = Get-EventsInRange $cal $now.Date $now.Date.AddDays(7) ""
      Out-Json ([PSCustomObject]@{ ok = $true; calendar = $cal.Name; events_next_7_days = $list.Count })
    }


    "today" {
      $now = Get-Date
      $list = Get-EventsInRange $cal $now.Date $now.Date.AddDays(1) ""
      Out-Json ([PSCustomObject]@{ ok = $true; date = $now.ToString("yyyy-MM-dd"); count = $list.Count; events = $list })
    }

    "read_events" {
      $now = Get-Date
      $scanDays = if ($Days -gt 0) { $Days } else { 7 }
      $list = Get-EventsInRange $cal $now.Date $now.Date.AddDays($scanDays) ""
      Out-Json ([PSCustomObject]@{ ok = $true; days = $scanDays; count = $list.Count; events = $list })
    }

    "search" {
      if (-not $Query) { Fail "search requires -Query" }
      $now = Get-Date
      $scanDays = if ($Days -gt 0) { $Days } else { 30 }
      $list = Get-EventsInRange $cal $now.Date $now.Date.AddDays($scanDays) $Query
      Out-Json ([PSCustomObject]@{ ok = $true; query = $Query; days = $scanDays; count = $list.Count; events = $list })
    }

    "read" {
      if (-not $EntryId) { Fail "read requires -EntryId" }
      $e = $ns.GetItemFromID($EntryId)
      $reqd = @(); $opt = @()
      foreach ($r in $e.Recipients) {
        if ($r.Type -eq 2) { $opt += $r.Name } else { $reqd += $r.Name }   # 2 = olOptional
      }
      Out-Json ([PSCustomObject]@{
        ok = $true
        subject = $e.Subject
        start = $e.Start.ToString("yyyy-MM-dd HH:mm"); end = $e.End.ToString("yyyy-MM-dd HH:mm")
        location = $e.Location; all_day = [bool]$e.AllDayEvent
        organizer = $e.Organizer; required = $reqd; optional = $opt
        is_recurring = [bool]$e.IsRecurring
        body = $e.Body
      })
    }

    "create_event" {
      if (-not $Subject) { Fail "create_event requires -Subject" }
      if (-not $Start -or -not $End) { Fail "create_event requires -Start and -End ('yyyy-MM-dd HH:mm')" }
      $startAt = Parse-When $Start "-Start"
      $endAt = Parse-When $End "-End"
      if ($endAt -le $startAt) { Fail "-End must be after -Start" }

      $appt = $ol.CreateItem(1)   # 1 = olAppointmentItem
      $appt.Subject = $Subject
      $appt.Start = $startAt
      $appt.End = $endAt
      if ($Location) { $appt.Location = $Location }
      if ($Body) { $appt.Body = $Body }

      $invited = @()
      $resolved = $true
      if ($Attendees) {
        $appt.MeetingStatus = 1   # 1 = olMeeting (invite; still not sent by this script)
        foreach ($a in ($Attendees -split ";")) {
          $addr = $a.Trim()
          if ($addr) { [void]$appt.Recipients.Add($addr); $invited += $addr }
        }
        $resolved = [bool]$appt.Recipients.ResolveAll()
      }

      if ($Save -and -not $Attendees) {
        $appt.Save()   # personal event, direct save (only after the user confirmed in chat)
        $mode = "saved"
      } else {
        $appt.Display()   # open the window; the user reviews, then saves or sends it themselves
        $mode = "displayed"
      }
      Out-Json ([PSCustomObject]@{
        ok = $true; action = "create_event"; mode = $mode
        subject = $Subject; start = $Start; end = $End; attendees = $invited
        attendees_resolved = $resolved   # false = some address didn't resolve; tell the user to check the red underline in the window
      })
    }
  }
} catch {
  Fail $_.Exception.Message
}
