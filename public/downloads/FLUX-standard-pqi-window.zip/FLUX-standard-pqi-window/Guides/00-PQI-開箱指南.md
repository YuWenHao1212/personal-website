---
order: 0
---

歡迎來到 PQI AI 工作流 vault。

這是**你個人的 AI 工作區**。工作坊結束後，這個 vault 就是你帶走的東西 — 你電腦上有一個會幫你做事的 Claude 助理。

---

## 為什麼你會收到這個 vault

這是為 **PQI 員工工作場景**設計的個人 AI 工作區。

裡面包含：

- **AI 工作流** — 讀檔 / 報表整併 / 數據分析 / 知識卡片 / 簡報素材
- **Outlook 助手** — 查信、草擬回信、看行程、建會議（已內建、Outlook 開著就能用）
- **日節奏** — 每天「開工」+「收工」5-10 分鐘（週一開工會自動跑 weekly review）
- **週節奏** — 週五「週末收尾 + Lock 下週」10-15 分鐘
- **個人筆記** — Daily / Journal / Inbox / Atlas（知識卡片）

工作坊跑這套、結束後你帶走它、你電腦上有一個會幫你做事的 Claude 助理。

---

## 第一次打開要做的 5 件事

### 1. 確認你的環境裝好了

依照安裝頁（yu-wenhao.com/zh-TW/studio-a/install、選 Windows）的步驟，你的 Windows 電腦上應該已經有：

| 項目 | 確認方式 |
|---|---|
| VS Code | 能打開、能看 `.md` 檔 |
| Obsidian | 能打開、知道「vault」是什麼 |
| Claude Code | 終端機輸入 `claude` 能跳出 Claude 對話 |
| Git for Windows | 終端機跑 `git --version` 有輸出 |
| 傳統桌面版 Outlook | 能收發公司信、看得到行事曆（**不是** New Outlook / 網頁版） |

> **任何一項沒有？** 回安裝頁照步驟跑、或在工作坊 LINE 群找講師。**不要自己亂試**。

### 2. 跑一次 vault 初始設定

第一次解壓 vault 後，資料夾裡是 `_claude` / `_obsidian`（底線開頭）— 這是為了讓 Windows 解壓不出錯，需要改回正式名稱。

1. 用 VS Code 打開 `FLUX-standard-pqi-window` 資料夾（檔案 → 開啟資料夾）
2. 打開整合終端機（`Ctrl + ~`）、輸入 `claude` 啟動 Claude Code
3. 跟 Claude 說：「**讀 Inbox/SETUP-CLAUDE.md 跑初始設定**」
4. Claude 會自動把 `_claude` → `.claude`、`_obsidian` → `.obsidian`、驗證檔案齊全

### 3. 在 Obsidian 打開這個 vault

1. 開 Obsidian → 點左下角「Open another vault」
2. 選「Open folder as vault」
3. 找到你電腦上的 `FLUX-standard-pqi-window/` 資料夾、選它
4. 看到左側邊欄出現 `Inbox / Atlas / Calendar / Cockpit / Efforts / Guides / Templates / Home.md` = 成功

### 4. 填「你是誰」3 欄（2 分鐘）

回到 VS Code 的 Claude Code，打開 `CLAUDE.md`、找到開頭的「## 你是誰」section、填這 3 欄：

- **稱呼**：你想被怎麼叫
- **PQI 職位**：部門 + 職位（例如「業務部 專員」「行銷部 企劃」）
- **直屬主管**（可選）

或直接跟 Claude 說「**幫我填**」、它會一個一個問。

填完後 Claude 對你的所有回應都會更貼近你。

> 不放會變的內容（每週工作 / 每月產出 / 痛點）— Claude 從每天對話自然 infer、或本來就在 `Cockpit/Weekly-Commitment.md`、避免兩處 drift。

### 5. 試一個簡單的事

挑一個你今天就能用得上的：

| 試試看 | 怎麼說 |
|---|---|
| 看最近的信 | 「看一下我最近的信」（Outlook 開著、第一次跳授權按允許） |
| 看今天的行程 | 「看我今天的行程」 |
| 整併兩張報表 | 把 Excel 檔拖進終端機、說「幫我把這兩張表合併、清掉重複欄位」 |
| 摘要一份文件 | 「讀這個檔案、給我 5 點摘要」 |
| 寫一篇日記 | 「寫日記」 |
| 規劃今天 | 「開工」或「規劃今天」 |
| 第一次 lock 本週 3-5 件主要任務 | 「調整本週」 |

---

## 工作坊會教什麼

- 環境建置 + 跑通你的第一個工作流（報表整併分析）
- 原子能力（圖片識別 / 文件處理 / 簡報素材）+ 拼成你部門的工作流
- Skill 化（一句話觸發）+ 卡點自救 + 後續維護

工作坊結束時，你帶走的：

- 一個會跑你工作流的 Claude 助理
- 一份個人 AI Workspace（這個 vault）
- 個人 Skill 庫（一句話觸發完整流程）
- 一套自救能力（卡住怎麼除錯、git 怎麼還原）

---

## 卡住的時候

1. **裝環境卡住** → 工作坊 LINE 群找講師
2. **用 AI 卡住** → 先翻 `Guides/` 對應教學、再問你手邊的 Claude
3. **真的搞不定** → 課程結束後 LINE 群仍開放 2 週答疑，或寫信到 mail@yu-wenhao.com

---

## 接下來

繼續讀 → [[01-Quick-Start]]（10 分鐘了解整套系統）
