---
up: "[[Productivity MOC]]"
collection: Things
related:
  - "[[Lead 與 Lag 指標]]"
created: 2026-01-07
says: "把 12 週當一年規劃，創造緊迫感、提升執行力"
---

由 Brian Moran 和 Michael Lennington 提出的目標執行框架。

核心理念：**把 12 週當作一整年來規劃。** 傳統年度計畫的問題是時間太長，容易產生「還有時間」的錯覺而拖延。12 週夠短，創造緊迫感；又夠長，能完成有意義的事。

## 3 原則

| 原則 | 定義 |
|------|------|
| **問責 Accountability** | 無論環境如何，對自己的行動和結果負全責 |
| **承諾 Commitment** | 遵守對自己的承諾，不找藉口 |
| **當下卓越 Greatness in the Moment** | 當下做出正確選擇，即使不想做也做 |

## 5 紀律

| 紀律 | 內容 |
|------|------|
| **願景 Vision** | 清晰的長期方向（10 年 + 3 年）|
| **計畫 Planning** | 把願景拆解成目標，目標拆解成每週行動 |
| **流程控制 Process Control** | 確保執行不偏離軌道的工具和系統（週計畫、WAM）|
| **衡量 Measurement** | 追蹤 Lead/Lag 指標 |
| **時間運用 Time Use** | Strategic Block、Buffer Block、Breakout Block |

## 關鍵機制

- **每週執行分數**：Lead Indicators 完成率 ≥ 85% 為目標
- **WAM（每週問責會議）**：每週回顧 + 計分

## 在這套系統中

- [[VISION]] -- 你的長期方向
- [[12-WEEK-PLAN]] -- 當前週期目標，含 Lead/Lag 指標
- [[THIS-WEEK]] -- 逐週追蹤
- [[WAM-Template]] -- 每週回顧流程

## 參考資料

- 書籍：*The 12 Week Year* by Brian Moran & Michael Lennington
