---
up: "[[PKM MOC]]"
created: 2026-01-07
---

我對「把事情做好」的思考。

---

## 框架

- [[12 Week Year]] -- 12 週目標週期 + 每週計分
- [[Lead 與 Lag 指標]] -- 衡量行為，不是結果
- [[LYT 框架]] -- 用連結組織知識
- [[習慣的四個階段]] -- 提示→渴望→反應→獎賞

## 原則

- [[執行力贏過完美計畫]]

## 來源

- [[2026-01-15-Atomic Habits]]

## 人物

- [[Nick Milo]] -- LYT 創造者
- [[Brian Moran]] -- 12 Week Year 作者

---

## 系統組件

- [[VISION]] -- 我要去哪裡
- [[12-WEEK-PLAN]] -- 這個週期的目標
- [[THIS-WEEK]] -- 每週追蹤
- [[Daily-Template]] -- 每日執行
