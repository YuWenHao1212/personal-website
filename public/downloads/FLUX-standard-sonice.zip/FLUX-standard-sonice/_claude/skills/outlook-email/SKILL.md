---
name: outlook-email
description: Email assistant — 用本機 Outlook（傳統桌面版）讀信、回信、草擬、轉寄、搜尋。觸發詞：「查信」「看最近的信」「有沒有新信」「讀這封信」「幫我看這封信」「草擬回信」「回覆這封」「寫一封信給...」「轉寄給...」「建草稿」或任何 email 相關請求。透過 PowerShell + Outlook COM 操作，只建草稿、絕不直接寄送。
---

# Outlook Email 工作流（SO NICE 版）

透過 PowerShell + Outlook COM 操作本機 Outlook。指令面對齊 STUDIO A email skill（email_ops.py），底層改用 COM — 不需要帳密設定檔、不需要 IMAP、不需要 IT 開通，**Outlook 桌面版已登入即可用**。

## 前提

- 電腦裝有**傳統桌面版 Outlook**（不是 New Outlook / 網頁版）且已設定好公司帳號
- 建議 Outlook 保持開啟（沒開時 script 會自動啟動它，第一次較慢）
- 第一次使用如果跳出「有程式正在嘗試存取 Outlook」對話框 → 請使用者按「允許」

## 安全規則

- **草稿優先**：所有信件只存草稿匣，不自動寄出（script 沒有 send 指令）
- **人工確認**：產完草稿後告訴使用者去 Outlook 草稿匣確認，不要說「已寄出」
- **不刪信**：只能標記已讀，不刪除（script 沒有 delete 指令）
- script 失敗時把錯誤原文回報，不要自行重試超過一次

## 工具指令

Script 位置：此 SKILL.md 同目錄下 `scripts/outlook_ops.ps1`（用絕對路徑）。

執行格式：
```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<絕對路徑>\outlook_ops.ps1" <command> [參數]
```

### 指令速查

| 指令 | 用途 | 主要參數 |
|------|------|---------|
| `status` | 收件匣總數 + 未讀數 | — |
| `check` | 列出未讀信件 | `-Count 10` |
| `recent` | 列出最近 N 封（已讀＋未讀） | `-Count 10` |
| `read` | 讀一封信完整內容（含附件清單） | `-EntryId "..."` |
| `search` | 搜尋主旨 + 寄件者（支援中文） | `-Query "關鍵字" -Count 10` |
| `draft` | 建新草稿 | `-Subject "..." -To "..." [-Cc] [-Body 純文字 \| -HtmlPath HTML檔]` |
| `reply` | 回覆草稿（Outlook 自動帶原文引用） | `-EntryId "..." [-Body \| -HtmlPath] [-ReplyAll]` |
| `forward` | 轉寄草稿（**原信附件自動帶上**） | `-EntryId "..." -To "..." [-Note "說明"] [-Cc]` |
| `mark_read` | 標記已讀（逗號分隔多封） | `-EntryId "id1,id2"` |
| `list_folders` | 列出信箱資料夾 | — |

所有指令回傳 JSON（`ok: true/false`，失敗有 `error`）。`to` / `cc` 多收件人用分號分隔（Outlook 慣例）。

> **內容傳遞**：純文字用 `-Body`（自動包成簡單 HTML）；格式信件（含表格）把 HTML 寫到暫存檔（vault `Inbox/.draft-tmp.html`，用完刪），用 `-HtmlPath` 傳絕對路徑。HTML 格式規則**必讀** `references/html-template.md`。

## 工作流程

### 回信（任何信件）

使用者說「幫我看這封信」「回覆這封」時：

1. 讀信：`read`（或直接讀使用者貼的內容）
2. 摘要：這封信在說什麼（重點、對方要什麼、截止日）
3. 討論：問使用者想怎麼回（哪些答應、哪些拒絕、語氣偏好）— **不要自己編內容**
4. 出草稿：根據討論寫完整回覆，給使用者看
5. 微調：使用者提修改 → 改到滿意
6. 存草稿：`reply`（自動帶原文引用，不要用 draft 手動拼引用）
7. 告知：「草稿已存到 Outlook 草稿匣，請開啟確認後自行送出。」

### 轉寄

使用者說「把這封轉給 X」「幫我把這封寄給 Y 看」時：

- `forward` 開新 thread 給新收件人；`reply` 是回原寄件人 — 分清楚
- **原信附件會自動帶上**（COM Forward() 原生行為），輸出的 `attachments_carried` 欄位列出帶了哪些，回報給使用者
- 有說明文字用 `-Note`（會顯示在轉寄內容上方）

### 看最近的信 / 查信

- 「最近的信」→ `recent`（預設 10 封）→ 簡要列出 → 使用者選一封 → `read`
- 「有沒有 XX 寄來的信」→ `search -Query "XX"` → 列結果 → `read`
- 「有新信嗎」→ `check`（只看未讀）

### 批次（重複信件）

1. 確認模板：信件格式、必填欄位
2. 確認資料來源：使用者提供資料表或口述
3. 產第一封讓使用者確認
4. 確認後逐封 `draft` 存草稿匣
5. 回報：產了幾封、收件人各是誰

## HTML 信件規則（產 HTML 時必遵守）

- **不要用 `<blockquote>`** — iOS Mail 渲染成帶色條縮排，手機看格式錯亂
- **不要用 `<h1>`~`<h6>`** — 各 mail client 差異大，用 `<strong>` 或 `<p style="font-size:18px;font-weight:bold;">`
- **所有樣式 inline style** — mail client 不吃 `<style>` block 或 class
- **扁平結構** — 不巢狀 `<div>`，用 `<p>` + `<br>` 排版
- 完整模板見 `references/html-template.md`

## 信件風格指南

使用者可以請你在此段落加入：語氣偏好、簽名檔、常用信件模板。
