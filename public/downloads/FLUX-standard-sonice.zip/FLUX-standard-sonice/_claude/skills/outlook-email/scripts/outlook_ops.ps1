# outlook_ops.ps1 — Outlook COM email operations for SO NICE (Windows, classic desktop Outlook).
# Command surface mirrors email_ops.py (STUDIO A IMAP version); backend is local Outlook COM.
# Draft-only by design: there is no send command in this script.
#Requires -Version 5.1
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true, Position = 0)]
  [ValidateSet("status", "check", "recent", "read", "search", "draft", "reply", "forward", "mark_read", "list_folders")]
  [string]$Command,

  [string]$EntryId = "",      # read / reply / forward / mark_read (comma-separated for mark_read)
  [int]$Count = 10,           # check / recent / search result limit
  [string]$Query = "",        # search keyword (subject + sender name)
  [string]$To = "",           # draft / forward
  [string]$Cc = "",           # draft / forward
  [string]$Subject = "",      # draft
  [string]$Body = "",         # plain text content (auto-wrapped as simple HTML)
  [string]$HtmlPath = "",     # path to UTF-8 HTML file (preferred for formatted mail)
  [string]$Note = "",         # forward: short note shown above forwarded content
  [switch]$ReplyAll,
  [int]$ScanLimit = 500       # search: max items scanned before giving up
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

function Out-Json($obj) { $obj | ConvertTo-Json -Depth 5 }
function Fail($msg) { Out-Json ([PSCustomObject]@{ ok = $false; error = $msg }); exit 1 }

function Get-ContentHtml {
  if ($HtmlPath) {
    if (-not (Test-Path $HtmlPath)) { throw "HTML file not found: $HtmlPath" }
    return (Get-Content -Path $HtmlPath -Raw -Encoding UTF8)
  }
  if ($Body) {
    $escaped = [System.Net.WebUtility]::HtmlEncode($Body) -replace "(\r`n|`n)", "<br>"
    return "<div style=""font-family:'Microsoft JhengHei',sans-serif;font-size:14px;line-height:1.6;"">$escaped</div>"
  }
  throw "Provide -HtmlPath or -Body"
}

# Insert new content right after <body> so Outlook's auto-quoted original stays below.
function Add-HtmlOnTop($mailItem, $newHtml) {
  $rx = [regex]"(?is)(<body[^>]*>)"
  if ($rx.IsMatch($mailItem.HTMLBody)) {
    $evaluator = { param($m) $m.Groups[1].Value + $newHtml }
    $mailItem.HTMLBody = $rx.Replace($mailItem.HTMLBody, $evaluator, 1)
  } else {
    $mailItem.HTMLBody = $newHtml + $mailItem.HTMLBody
  }
}

function Mail-Summary($m) {
  [PSCustomObject]@{
    entry_id        = $m.EntryID
    received        = $m.ReceivedTime.ToString("yyyy-MM-dd HH:mm")
    from            = $m.SenderName
    subject         = $m.Subject
    unread          = $m.UnRead
    has_attachments = ($m.Attachments.Count -gt 0)
  }
}

function Get-MailList($items, $limit, $filter) {
  $items.Sort("[ReceivedTime]", $true)
  $result = @(); $scanned = 0
  foreach ($m in $items) {
    $scanned++
    if ($scanned -gt $ScanLimit) { break }
    if ($m.Class -ne 43) { continue }   # 43 = olMail
    if ($filter -and ($m.Subject -notlike "*$filter*") -and ($m.SenderName -notlike "*$filter*")) { continue }
    $result += Mail-Summary $m
    if ($result.Count -ge $limit) { break }
  }
  return , $result
}

try {
  $ol = New-Object -ComObject Outlook.Application
  $ns = $ol.GetNamespace("MAPI")
  $inbox = $ns.GetDefaultFolder(6)   # 6 = olFolderInbox

  switch ($Command) {

    "status" {
      $unread = $inbox.Items.Restrict("[UnRead] = True")
      Out-Json ([PSCustomObject]@{ ok = $true; inbox_total = $inbox.Items.Count; unread = $unread.Count })
    }

    "check" {
      $unread = $inbox.Items.Restrict("[UnRead] = True")
      $list = Get-MailList $unread $Count ""
      Out-Json ([PSCustomObject]@{ ok = $true; count = $list.Count; messages = $list })
    }

    "recent" {
      $list = Get-MailList $inbox.Items $Count ""
      Out-Json ([PSCustomObject]@{ ok = $true; count = $list.Count; messages = $list })
    }

    "search" {
      if (-not $Query) { Fail "search requires -Query" }
      $list = Get-MailList $inbox.Items $Count $Query
      Out-Json ([PSCustomObject]@{ ok = $true; count = $list.Count; query = $Query; messages = $list })
    }

    "read" {
      if (-not $EntryId) { Fail "read requires -EntryId" }
      $m = $ns.GetItemFromID($EntryId)
      $atts = @(); foreach ($a in $m.Attachments) { $atts += $a.FileName }
      Out-Json ([PSCustomObject]@{
        ok = $true; from = $m.SenderName; from_email = $m.SenderEmailAddress
        to = $m.To; cc = $m.CC
        received = $m.ReceivedTime.ToString("yyyy-MM-dd HH:mm")
        subject = $m.Subject; attachments = $atts; body = $m.Body
      })
    }

    "draft" {
      if (-not $Subject) { Fail "draft requires -Subject" }
      $html = Get-ContentHtml
      $mail = $ol.CreateItem(0)   # 0 = olMailItem
      if ($To) { $mail.To = $To }
      if ($Cc) { $mail.CC = $Cc }
      $mail.Subject = $Subject
      $mail.HTMLBody = $html
      $mail.Save()   # draft only — never .Send()
      Out-Json ([PSCustomObject]@{ ok = $true; action = "draft"; saved_to = "Drafts"; subject = $Subject; to = $To })
    }

    "reply" {
      if (-not $EntryId) { Fail "reply requires -EntryId" }
      $html = Get-ContentHtml
      $item = $ns.GetItemFromID($EntryId)
      $reply = if ($ReplyAll) { $item.ReplyAll() } else { $item.Reply() }
      Add-HtmlOnTop $reply $html
      $reply.Save()   # draft only — never .Send()
      Out-Json ([PSCustomObject]@{ ok = $true; action = "reply"; saved_to = "Drafts"; reply_to = $item.Subject; reply_all = [bool]$ReplyAll })
    }

    "forward" {
      if (-not $EntryId) { Fail "forward requires -EntryId" }
      if (-not $To) { Fail "forward requires -To" }
      $item = $ns.GetItemFromID($EntryId)
      $fwd = $item.Forward()   # COM Forward() carries original attachments automatically
      $fwd.To = $To
      if ($Cc) { $fwd.CC = $Cc }
      if ($Note -or $HtmlPath -or $Body) {
        $noteHtml = if ($Note) {
          $escaped = [System.Net.WebUtility]::HtmlEncode($Note) -replace "(\r`n|`n)", "<br>"
          "<div style=""font-family:'Microsoft JhengHei',sans-serif;font-size:14px;line-height:1.6;"">$escaped</div><br>"
        } else { Get-ContentHtml }
        Add-HtmlOnTop $fwd $noteHtml
      }
      $fwd.Save()   # draft only — never .Send()
      $atts = @(); foreach ($a in $item.Attachments) { $atts += $a.FileName }
      Out-Json ([PSCustomObject]@{ ok = $true; action = "forward"; saved_to = "Drafts"; original_subject = $item.Subject; to = $To; attachments_carried = $atts })
    }

    "mark_read" {
      if (-not $EntryId) { Fail "mark_read requires -EntryId (comma-separated for multiple)" }
      $done = @()
      foreach ($id in ($EntryId -split ",")) {
        $m = $ns.GetItemFromID($id.Trim())
        $m.UnRead = $false
        $m.Save()
        $done += $m.Subject
      }
      Out-Json ([PSCustomObject]@{ ok = $true; marked_read = $done })
    }

    "list_folders" {
      $folders = @()
      foreach ($store in $ns.Folders) {
        $folders += [PSCustomObject]@{ store = $store.Name; folder = "(root)" }
        foreach ($f in $store.Folders) {
          $folders += [PSCustomObject]@{ store = $store.Name; folder = $f.Name; items = $f.Items.Count }
        }
      }
      Out-Json ([PSCustomObject]@{ ok = $true; folders = $folders })
    }
  }
} catch {
  Fail $_.Exception.Message
}
