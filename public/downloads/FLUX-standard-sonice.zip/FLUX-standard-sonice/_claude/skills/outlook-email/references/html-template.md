# HTML 信件模板（Outlook / 手機相容）

> 產 HTML 信件內文時照這份規則。沿用 STUDIO A email skill 的 email-safe 規則 + Peggy 工作流的表格模板。

## 鐵則

1. 所有樣式 **inline style**（mail client 不吃 `<style>` block / class）
2. 不用 `<blockquote>`（iOS Mail 渲染成色條縮排）
3. 不用 `<h1>`~`<h6>`（client 差異大）— 標題用 `<p style="font-size:18px;font-weight:bold;">`
4. 結構扁平：`<p>` + `<br>`，不巢狀 `<div>`
5. emoji（✅ ❌ ⚠️）保留原樣
6. 字體一律微軟正黑體 fallback：`font-family:'Microsoft JhengHei',sans-serif;`

## 基本模板

```html
<div style="font-family:'Microsoft JhengHei',sans-serif;font-size:14px;line-height:1.6;color:#333;">

<p>OO 您好：</p>

<p>正文第一段。</p>

<p>正文第二段，重點用 <strong>粗體</strong>。</p>

<p>謝謝！</p>

</div>
```

## 表格模板（含框線、header 灰底）

```html
<table style="border-collapse:collapse;width:100%;margin:16px 0;font-family:'Microsoft JhengHei',sans-serif;font-size:14px;">
  <tr>
    <th style="border:1px solid #ddd;padding:8px 12px;background:#f5f5f5;text-align:left;">欄位一</th>
    <th style="border:1px solid #ddd;padding:8px 12px;background:#f5f5f5;text-align:left;">欄位二</th>
  </tr>
  <tr>
    <td style="border:1px solid #ddd;padding:8px 12px;">內容</td>
    <td style="border:1px solid #ddd;padding:8px 12px;">內容</td>
  </tr>
</table>
```

## 使用方式

1. 把完整 HTML 寫到暫存檔：vault 的 `Inbox/.draft-tmp.html`（UTF-8）
2. `outlook_ops.ps1 draft/reply/forward` 用 `-HtmlPath "<絕對路徑>"` 傳入
3. 草稿建好後刪掉暫存檔
