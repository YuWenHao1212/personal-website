# 知識庫 folder 圖解

## 一張圖看懂

```
你的 FLUX Vault/
│
├── Atlas/                      📚 知識永久家
│   ├── Sources/                  完整原始來源（7 類）
│   │   ├── Articles/               網路文章、Blog
│   │   ├── Books/                  書
│   │   ├── Videos/                 YouTube、線上課
│   │   ├── Podcasts/               Podcast 節目
│   │   ├── Courses/                課程
│   │   ├── Talks/                  演講、研討會
│   │   └── Papers/                 論文
│   ├── Dots/                     從 Source 拆出的原子知識卡（5 類）
│   │   ├── Things/                 概念、工具、方法
│   │   ├── Statements/             觀點、主張、原則
│   │   ├── People/                 人物
│   │   ├── Questions/              思考種子（值得反覆探索）
│   │   └── Quotes/                 引言
│   ├── Maps/                     MOC 主題目錄
│   └── log.md                    歸檔記帳本
│
└── Inbox/                      📥 桌面亂堆區
```

---

## 每個資料夾放什麼

### Atlas/Sources/ — 完整原始來源

7 個子資料夾對應來源類型：

| 資料夾 | 放什麼 |
|---|---|
| `Articles/` | 網路文章、Blog、Newsletter |
| `Books/` | 書 |
| `Videos/` | YouTube、影片、線上課錄影 |
| `Podcasts/` | Podcast 節目 |
| `Courses/` | 課程 |
| `Talks/` | 演講、研討會 |
| `Papers/` | 論文 |

**一個來源 = 一個檔案**。檔名：`YYYY-MM-DD-主題關鍵字.md`

**Source frontmatter** 5 欄：`up`（連到 MOC）、`type`、`url`、`author`、`created`、`status`。

**Source 內文結構**：
- 開頭 blockquote 一段概述
- `## Key Takeaways` — 3-5 個重點
- `## Dots` — 從這 Source 拆出的 Dot 卡 wikilink
- `## References` — 原始連結 / 書目資訊

---

### Atlas/Dots/ — 知識卡片（原子化）

每張卡 = 一個概念。**拆卡的核心規則：原子化**。

#### 原子化四原則

**1. 一卡一概念** — 一張卡只講一件事
- 寧可拆 3 張小卡，不要塞 1 張大卡
- 大卡未來引用時會尷尬（只想引一部分）

**2. 自足性** — 單獨看得懂
- 不依賴別張卡的上下文
- 三個月後回頭看也能看懂

**3. 可複用** — 未來能被別的主題引用
- 好的卡片會在多個 MOC 裡出現
- 例：「LINE 已讀不回不等於客戶無意願」可以用在「催辦」「客戶溝通」「危機處理」多個主題

**4. 標題是結論** — 檔名寫「這卡講什麼」，不是主題分類

| ❌ 不好 | ✅ 好 |
|---|---|
| `催辦筆記 1.md` | `LINE 已讀不回不等於客戶無意願.md` |
| `怡君的檔期排程流程.md` | `催辦郵件的三段式結構.md` |
| `Apple 產品.md` | `M3 Pro 適合教學培訓用.md` |
| `學員問題.md` | `門市配貨的三個判斷條件.md` |

**判斷「這張卡夠不夠原子」的 test**：
- 能不能用一句話說清楚？（能 = 夠原子）
- 會不會想在檔名加「及」「和」「與」？（會 = 該拆兩張）

---

#### 5 類 Dots — 五路判斷樹

照順序問，能停就停：

```
1. 是在講一個「人」嗎？           → People/
2. 是「我相信什麼」的主張？      → Statements/
3. 是別人說的話、原句引用？      → Quotes/
4. 是值得反覆思考的種子？        → Questions/
5. 其他全部（概念/工具/方法）    → Things/
```

| 資料夾 | 放什麼 | 例子 |
|---|---|---|
| `People/` | 人物卡片 | 客戶、講師、供應商、思考者 |
| `Statements/` | 觀點、主張、判斷規則 | 「執行力贏過完美計畫」、「LINE 已讀不回不等於客戶無意願」 |
| `Quotes/` | 引言、語錄 | 「Action is the antidote to despair — Joan Baez」 |
| `Questions/` | 思考種子（開放性問題、沒有標準答案） | 「為什麼 LINE 已讀不回不等於拒絕？」 |
| `Things/` | 所有概念、工具、方法、框架、事實（預設選項） | 「12 Week Year」、「催辦郵件的三段式結構」、「Lead 與 Lag 指標」 |

**判斷時的小撇步**：
- 不確定 = 預設 Things。Things 是最大、最常用的籃子。
- 一句話含主詞 + 「應該」「不等於」「優先於」 = 多半是 Statements
- 一句話是別人的引用 + 含作者 = 多半是 Quotes
- 一句話是疑問句 = 多半是 Questions

**Dot frontmatter** 5 欄：`up`、`collection`（純字串、不是 wikilink）、`related`、`created`、`says`。
**Dot 不放 `source_*` 4 欄** — 來源資訊在 Source 檔、Dot 用 `## References` wikilink 連回 Source。

---

### Atlas/Maps/ — 主題目錄（MOC）

某個主題的「目錄頁」，列出所有相關的 Dots。

**MOC = Map of Content**（內容地圖）。

例子：`Atlas/Maps/個人品牌 MOC.md` 裡會列：
- [[行動是抗焦慮的解藥]]
- [[Hook-First 寫作方法]]
- [[執行力贏過完美計畫]]
- [[Nick Milo]]
- [[為什麼長文章 SEO 比短文章好？]]

**什麼時候建 MOC**：
- 遇到新主題、且至少有 3 張 Dot 卡 → 值得建一個
- 只有 1-2 張卡 → 還不用，等累積到 3 張再建

**MOC 五區塊結構**（建議）：
```markdown
## Things
- [[卡片 1]]
- [[卡片 2]]

## Statements
- [[卡片 3]]

## People
- [[某某某]]

## Questions
- [[思考種子 1]]

## Quotes
- [[語錄 1]]
```

---

### Atlas/log.md — 歸檔記帳本

每次歸檔都 append 一段。格式：

```markdown
## 2026-05-19 14:30 | 怡君 檔期排程新流程

- 來源：[[Sources/Articles/2026-05-19-檔期排程新流程]]
- 新增 Dots：[[催辦郵件的三段式結構]]、[[檔期商品優先順序有三層]]
- 矛盾：無

---
```

4 欄：日期時間+主題 / 來源 / 新增的 Dots / 矛盾旗標。

---

### Inbox/ — 桌面亂堆區

還沒分類的東西先丟這裡：
- `[研究]` 跑完的結果（如果當下不歸檔）
- 臨時想法、還沒想清楚的筆記
- 看到有趣但還沒決定怎麼處理的連結

**重要**：`Inbox/` 是**暫存區**，會被定期清空。

👉 **Atlas/Dots/ 的卡片絕對不要連到 `Inbox/`**（會變 ghost link）

---

## 新東西放哪裡（決策樹）

```
新東西來了
│
├─ 完整的來源（URL、書、影片、Podcast、課程）？
│   → 先在 Atlas/Sources/{type}/ 建一個 Source 檔
│      （檔名：YYYY-MM-DD-主題關鍵字.md）
│   → 再從中拆 2-5 張 Dot 卡
│
├─ 一句話想法 / 個人結論（無外部來源）？
│   → 跳過 Source、直接建 1 張 Dot
│      （內文 ## References 段寫「個人想法」）
│
├─ 從來源拆出的重點？
│   → Atlas/Dots/{Things/Statements/People/Questions/Quotes}/
│   （照五路判斷樹走，記得檢查原子化：一卡一概念、標題是結論）
│
├─ 某主題的目錄/索引？
│   → Atlas/Maps/XXX MOC.md（累積 ≥ 3 張 Dot 才建）
│
├─ 還沒分類、臨時筆記？
│   → Inbox/
│
└─ 是要做的任務、不是知識？
    → Cockpit/BACKLOG.md（不關這個 skill 的事）
```

---

## 知識飛輪：研究時先查自己

每次 `[研究]` 時，archivist 會**先**搜內部知識庫（Atlas/Sources + Atlas/Dots + Atlas/Maps + Inbox）
再讓 researcher 上網找新資料。

原因：
- 你的工作有循環性（每週發 Blog、每月複盤）
- 以前可能記過類似內容，重查是浪費
- 內部已有 → 補強舊卡就好
- 內部沒有 → 才真的需要外部搜尋

**累積越多卡片 → [研究] 越有效率 → 更想累積卡片**。這是飛輪。
