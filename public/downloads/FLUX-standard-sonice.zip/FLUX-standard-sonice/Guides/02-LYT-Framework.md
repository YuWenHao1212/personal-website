---
order: 2
---

筆記越多越亂？找不到之前寫過的東西？問題不在你，在你的整理方式。LYT（Linking Your Thinking）用連結取代分類，讓筆記越多越有用，而不是越多越混亂。

---

## 核心理念

> 不要按分類來整理，要按連結來整理。

傳統的資料夾系統迫使你為每一則筆記選擇「唯一」的歸屬位置。但想法不會只屬於一個分類 — 它們會和很多東西產生連結。

LYT 使用**連結**（`[[像這樣]]`）來建立一張互相關聯的想法網絡。資料夾提供輕量的結構；連結才是真正的組織方式。

---

## ACE：三大支柱

這個 Vault 用 ACE 來區分三種思考模式：

### Atlas — 「我知道什麼？」

你的知識庫。包含：
- **Notes/** — 個別的知識卡片（參見下方「五種筆記類型」）
- **Maps/** — 把相關筆記串起來的索引頁（MOC, Maps of Content）

### Calendar — 「什麼時候發生了什麼？」

你的時間軸。包含：
- **Journal/** — 個人每日反思（First Light / Last Light）

> 循環回顧（12 週結束時的回顧）放在 `Cockpit/Goals/archive/`，屬於目標管理的一部分。

### Efforts — 「我正在做什麼？」

你的工作台。包含：
- **Areas/** — 持續經營、沒有結束日的生活領域（例如「健康」「理財」「職涯」）
- **Projects/** — 有明確目標的專案，依狀態分四層：Active（正在推進）、Idle（暫停但可能回來）、Sleeping（休眠）、Done（已完成）

---

## 五種筆記類型

`Atlas/Dots/` 裡的每一則知識卡片都屬於五種類型之一：

| 類型 | 記錄什麼 | 資料夾 | 範例 |
|------|----------|--------|------|
| **Things** | 概念、工具、框架 | `Dots/Things/` | [[LYT 框架]] |
| **Statements** | 你的觀點、洞見 | `Dots/Statements/` | [[執行力贏過完美計畫]] |
| **Questions** | 待探索的開放式問題 | `Dots/Questions/` | 「習慣是怎麼形成的？」 |
| **Quotes** | 別人說的話 | `Dots/Quotes/` | 「媒介即是訊息」 |
| **People** | 思想家、創作者、導師 | `Dots/People/` | [[Nick Milo]] |

> 這個 Vault 在 LYT 之上加了 `Atlas/Sources/` — 存完整原始出處。Dots 是從 Source 拆出的原子卡片。

### 為什麼要分五種？

它們迫使你用不同的角度思考：
- **Thing**：「這東西**是**什麼？」（定義）
- **Statement**：「我**怎麼看**這件事？」（觀點）
- **Question**：「我對什麼**好奇**？」（探索）

大多數人只寫 Thing 類型的筆記。加入 Statement 和 Question 會讓你的筆記更有個人特色，也更實用。

---

## MOC（Maps of Content）

MOC 是一則索引筆記，彙整了相關筆記的連結。把它想成某個主題的目錄。

範例：[[Productivity MOC]] 連結到所有跟生產力有關的筆記。

MOC **不是資料夾**。它們是活的文件，會持續成長與演化。一則筆記可以出現在多個 MOC 中——frontmatter 的 `up` 欄位可以放多個 MOC：

```yaml
up:
  - "[[Productivity MOC]]"
  - "[[PKM MOC]]"
```

### 什麼時候該建立 MOC

當你發現同一個主題下有 5 則以上的筆記，而且你想要一個地方把它們全部看到。

---

## 知識怎麼流動

```
Inbox/           -- 想到什麼先丟這裡
    |
    v
Atlas/Sources/   -- 完整原始來源（文章 / 影片 / Podcast...）
    |
    v
Atlas/Dots/      -- 從 Source 拆出的原子知識卡（5 類）
    |
    v
Atlas/Maps/     -- 彙整成 MOC
    |
    v
Efforts/        -- 把知識應用到實際工作中
```

完整的捕捉和處理流程 → [[06-Knowledge-Capture]]

---

## 致謝

LYT 由 [Nick Milo](https://www.linkingyourthinking.com/) 創建。這個 Vault 在他的框架基礎上做了簡化，讓你能更快上手。
