---
order: 4
---

每天起床不知道該先做什麼？每日規劃解決這個問題。每天早上花 5-10 分鐘，盤點今天要推進的事，剩下的時間就專心做。

---

## 模板

每篇每日筆記的結構如下：

```
## 今日焦點
> 今天我一定要完成的那件事是什麼？

## 任務
（表格：任務、目標、預估時間、備註）

## 筆記
（白天隨手記下的想法）

## 結束回顧
- 已完成
- 移到明天
- 今天學到的
```

完整模板請見 [[Daily-Template]]。

---

## 早上流程（5-10 分鐘）

最簡單的方法：跟 Claude 說「**規劃今天**」。Claude 會自動跑下面這些步驟。

### Claude 會做的事

0. **（週一才跑）確認本週 commitment** — 讀 `Cockpit/Weekly-Commitment.md` 本週段落、跟你確認「保持 / 微調 / 重新 lock？」（細節走 [[05-Weekly-Routine|調整本週]]）。其他天跳過此 step。
1. **看最近 2 個 daily notes** — 看你昨天/前天做了什麼、有什麼還沒做完
2. **掃描可用任務來源**：
   - **`Efforts/Areas/`** — 永續領域（你的長期工作場景）
   - **`Efforts/Projects/Active/`** — 進行中專案
   - **[[BACKLOG]]** — 待辦清單裡有沒有適合今天順手做的（挑出來時、Claude 會從 BACKLOG 同步刪除那項）
   - **`Inbox/`** — 累積的筆記、可以順手處理 1-2 則（挑進 Daily 時任務寫「處理 `Inbox/XXX.md`」、晚上收工時 Claude 才知道對應源頭）
   > ⚠️ Claude **不會讀 `Efforts/OVERVIEW.md`**、它可能沒同步、**目錄結構才是 SSOT**
3. **跟你討論**今天要做什麼（不會直接幫你決定）
   - **連續 ≥3 天拖延的項目**主動點名：「『XXX』已經連續 3 天沒做了，今天要做嗎？」
4. **建立今天的 Daily Note** 在 `Cockpit/Daily/YYYY-MM-DD.md`

### 任務規則

- 主要任務 **3-5 件**（跟 Weekly-Commitment 對齊；少於 3 沒推進感、多於 5 容易 carry-over 鬼打牆）
- Claude 會問你：「如果今天只能完成一件事，你選哪個？」→ 填入「焦點」區塊（焦點 = 主要任務的第 1 件）
- 5 min 內可完成的小事 / 雜事放「如有空檔」區塊

### 不用 AI 也行

如果不想用 Claude，直接複製 `Templates/Daily-Template.md` 自己填也可以。

---

## 白天

- **執行任務**，照你的每日筆記走
- **捕捉靈感**到 `Inbox/`（不要為了整理而打斷你的工作節奏）— 完整流程見 [[06-Knowledge-Capture]]
- **在筆記區隨手記錄**，有什麼想法就寫下來

---

## 晚上回顧（5 分鐘）

跟 Claude 說「**收工**」或「**回顧今天**」。Claude 會：

1. **讀今天的 Daily Note**
2. **跑 git 看今天動過什麼**（輔助回憶，Day 1 課程已 setup git）：
   - `git log --since=midnight --oneline` 看今天的 commits
   - `git status --short` 看 uncommitted 改動
   Claude 用 git 結果 prompt 你「我看到你今天 commit 過 X、有完成嗎？」— 但最終答案還是你說的算，不會替你下結論。
3. 問：「今天完成了哪些？有沒有要移到明天的？」
4. 問：「今天學到什麼？一句話就好。」
5. **更新 Daily Note 的「一日回顧」區塊**
6. **沒做完的事** → 三選一處理（針對「## 任務」表格中沒勾完的事）：
   - **「## 任務」表格那行不動**（保留作當日「規劃 vs 實際」的對比紀錄）
   - **移到明天** → Claude 在「一日回顧 → 移到明天」section 加一行（明早規劃今天會讀到）
   - **進 BACKLOG** → Claude 在 `Cockpit/BACKLOG.md` 加一行：`- [ ] 任務 (YYYY-MM-DD added)`
   - **砍掉** → 不 record（消失即可）。但**先確認再砍**
7. **同步打勾 Weekly-Commitment** → 對「已完成」的任務，看是否對應 `Cockpit/Weekly-Commitment.md` 的某件本週主要任務 → 回去 Weekly-Commitment 補打勾。**這是 Daily ↔ Weekly 雙向 sync 的關鍵動作**，每天收工都要做。
8. **快速 review 今天的 Inbox**（輕量）→ 問「今天 Inbox 有動嗎？」涵蓋 (a) 今天新捕捉的想法 (b) 今天從 Inbox 挑進 Daily 處理過的檔案。要 review 就對每則三選一：**歸檔到 Atlas（用 knowledge-keeper、原檔 delete）/ 進 BACKLOG（同 step 6 格式、原檔 delete）/ 留 Inbox**。沒動 / 留著就 skip。
9. **收工 commit（可選）** → 問「要不要把今天的改動 commit 起來？」、同意就一句總結 commit。養成版本控制習慣、vault 不會莫名搞丟。

### 自動提醒（Claude 在合適時機會提）

| 條件 | Claude 會問 |
|---|---|
| 月初 1-3 日 | 「上個月的 daily notes 要不要歸檔到 `Cockpit/Daily/archive/YYYY-MM/`？」 |
| Inbox 累積 > 10 則 | 「Inbox 累積 X 則，要『處理 Inbox』嗎？」 |
| BACKLOG 有項目躺超過 4 週 | 「『XXX』在 BACKLOG 躺了 X 週了，要拉進來 / 拆小 / 砍掉？」 |

不用刻意記，這些提醒會在「規劃今天 / 收工」流程中自動出現。

---

## Daily Note vs Journal

這個 Vault 有兩種每日書寫：

| | Daily Note（每日筆記） | Journal（日記） |
|---|---|---|
| **位置** | `Cockpit/Daily/` | `Calendar/Journal/` |
| **用途** | 工作規劃 + 任務追蹤 | 個人反思 |
| **模板** | [[Daily-Template]] | [[Journal-Template]] |
| **頻率** | 每個工作日 | 隨時想寫就寫 |
| **內容** | 任務、筆記、回顧 | First Light、Last Light、自由書寫 |

你可以兩種都用，或只用一種。它們服務不同的需求。

---

## 小技巧

- **不要過度規劃。** 3 個任務比 10 個任務但 7 個沒完成好得多。
- **那件事不可妥協。** 即使是糟糕的一天，也要完成那一件事。
- **學習是複利。** 每天的小洞見，幾週後就會累積成智慧。

---

> AI 跑「規劃今天」/「收工」的**完整 SOP** 寫在 vault 根目錄的 `CLAUDE.md`。本指南只是學員視角的精簡版。要客製 AI 行為 → 改 `CLAUDE.md`。
