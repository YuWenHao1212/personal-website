---
order: 6
---

如何使用 [[LYT 框架]] 將零散的想法轉化為持久的知識。

---

## 流程

```
1. 捕捉 (CAPTURE)    -- 丟進 Inbox/
2. 歸檔 (SOURCE)     -- 有價值的存到 Atlas/Sources/（完整原始來源）
3. 拆卡 (DOT)        -- 從 Source 拆原子知識卡到 Atlas/Dots/
4. 連結 (CONNECT)    -- 連到 Maps 和相關卡片
5. 應用 (APPLY)      -- 在 Efforts 中使用（內容創作、選題、引用）
```

> 第 2-4 步是手動操作 — 在 Inbox 處理時，挑出有價值的內容自己建 Source、拆 Dots、連 MOC。詳見 [[../Atlas/README]]。

---

## 第 1 步：捕捉

當你遇到有趣的東西——一個想法、一句話、一個連結、一個洞察——把它放進 `Inbox/`。

規則：
- **先不要整理。** 先記下來就好。
- **先不要編輯。** 原始狀態就好。
- **一則筆記一個想法。** 之後比較好處理。

在 `Inbox/` 建立一則新筆記，檔名隨意。即使是 `Inbox/idea.md` 也可以。

---

## 第 2 步：處理

在每日或每週回顧時，逐一檢視 `Inbox/` 裡的筆記，問自己：

> 這是什麼類型的知識？

| 如果是... | 移到 | 加上 frontmatter |
|-----------|------|-----------------|
| 概念、工具或框架 | `Notes/Things/` | `collection: Things` |
| 你自己的觀點或洞察 | `Notes/Statements/` | `collection: Statements` |
| 想要探索的問題 | `Notes/Questions/` | `collection: Questions` |
| 別人說的話 | `Notes/Quotes/` | `collection: Quotes` |
| 關於某個人 | `Notes/People/` | `collection: People` |

填寫 frontmatter：
```yaml
---
up: (這則筆記屬於哪個 Map？)
collection: Things
related: (與哪些其他 Notes 有關聯？)
created: 2026-01-15
says: "一句話摘要"
---
```

`says` 欄位迫使你把想法提煉成一句話。如果你沒辦法用一句話總結，那你可能還沒真正理解它。

---

## 第 3 步：連結

加上 `[[links]]` 連結到：
- 它所屬的 **Map**（透過 `up:` frontmatter）
- **相關的 Notes**（透過 `related:` frontmatter 和內文連結）
- 更新 **Map**，加入連回這則 Note 的連結

---

## 第 4 步：應用

知識只有在改變你的行動時才有用。尋找機會將 Notes 應用在你的 Efforts 中：

- 在寫部落格文章？查看你的 Maps 找相關的 Notes。
- 在規劃專案？查看你是否有關於類似問題的 Notes。
- 在做決策？查看你的 Statements 找原則。

---

## 什麼時候處理

- **每天**：快速掃過 Inbox（2-3 分鐘）
- **每週**：固定挑一天做更深入的處理（5-10 分鐘）
- **不要讓 Inbox 堆超過** 10-15 則筆記

---

## 寫好一張卡片

流程會了，但卡片品質決定了它未來能不能被找到、被連結、被使用。

→ 詳見 [[07-Writing-Good-Cards]]

---

## 用 AI 加速

告訴 AI「記錄一個想法」，它會問你類型、幫你建卡片、加上 frontmatter 和連結。詳見 [[08-Upgrade-with-AI]]。

---

## 範例

你讀了一篇關於習慣養成的文章。

1. **捕捉**：建立 `Inbox/habit-article.md`，記下關鍵洞察
2. **處理**：這是一個 Thing → 移到 `Atlas/Dots/Things/習慣養成.md`
3. **連結**：連結到 [[Productivity MOC]]，關聯相關概念
4. **應用**：用這個洞察來改善你的每日工作流程
