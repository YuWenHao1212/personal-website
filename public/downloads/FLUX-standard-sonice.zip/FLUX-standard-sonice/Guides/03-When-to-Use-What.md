---
order: 3
---

打開 vault，看到 8 個資料夾（Inbox / Atlas / Calendar / Cockpit / Efforts / Guides / Templates / Home.md）。**這份指南教你：今天遇到一件事、想記下來，要放哪裡？**

> [[02-LYT-Framework]] 講「為什麼這樣設計」。本篇講「實際遇到事情怎麼分」。

---

## 三個核心區別

vault 內**所有區塊**只做三件事：

| 區別 | 你的需求 | 對應區塊 |
|---|---|---|
| **規劃 / 執行** | 「今天要做什麼？」「本週要交什麼？」 | `Cockpit/` |
| **時間軸 / 反思** | 「我今天做了什麼？有什麼感受？」 | `Calendar/Journal/`、`Cockpit/Daily/` |
| **沉澱知識** | 「這個原則 / 想法、半年後我還想找得到」 | `Atlas/`（透過 `Inbox/` 中轉） |

「工作場景」（你的長期領域 / 進行中的專案）放在 `Efforts/`。

---

## 判斷樹：這個東西放哪？

**問題 1**：這是「任務」、「想法」、還是「事件 / 心情紀錄」？

```
任務 = 你要做的事
想法 = 你學到 / 想記下來的概念
事件 = 今天發生的事 + 你的反思
```

### 「任務」型 → Cockpit/

| 子問題 | 放哪 |
|---|---|
| 今天就要做、已經排進今天 | `Cockpit/Daily/YYYY-MM-DD.md` 的任務表 |
| 本週要做、還沒排到哪天 | `Cockpit/Weekly-Commitment.md` 本週清單 |
| 想做、還沒排進本週 | `Cockpit/BACKLOG.md` |
| 跨多天 / 多步驟的大任務 | 建到 `Efforts/Projects/Active/{專案}/` |

### 「想法」型 → Inbox/ 中轉，沉澱去 Atlas/

| 子問題 | 放哪 |
|---|---|
| 想法還很模糊、不知道有沒有用 | `Inbox/` 隨手寫 |
| 想法已經清楚、值得留下 | 跟 Claude 說「[歸檔] 這個想法」→ `Atlas/Dots/` |
| 一篇文章 / 一支影片 / 一本書 | 跟 Claude 說「[歸檔] 這篇 URL」→ `Atlas/Sources/` + 拆出 `Atlas/Dots/` |

> 不確定要不要歸檔？先丟 `Inbox/`、之後說「處理 Inbox」一起整理。

### 「事件 / 心情」型 → Calendar/Journal/ 或 Cockpit/Daily/

| 子問題 | 放哪 |
|---|---|
| 今天做了什麼、進度怎樣（工作日誌） | `Cockpit/Daily/YYYY-MM-DD.md` |
| 今天的感受、晨間想法、晚間反思（個人日記） | `Calendar/Journal/YYYY-MM-DD.md` |

> Daily 和 Journal 是**兩套不同系統**、不要混。Daily 看任務進度、Journal 看你這個人。

---

## 區塊速查表

| 區塊 | 放什麼 | 會不會清掉 |
|---|---|---|
| `Cockpit/Daily/` | 每天的工作日誌 | 月初歸檔到 `Cockpit/Daily/archive/YYYY-MM/` |
| `Cockpit/Weekly-Commitment.md` | 本週 3-5 件主要任務 | 本週段落會在週末搬到「歷史紀錄」 |
| `Cockpit/BACKLOG.md` | 還沒排進本週的待辦 | 永久保留、定期清不再做的 |
| `Calendar/Journal/` | 個人日記（晨光 / 暮光 / 自由書寫） | 永久保留 |
| `Inbox/` | 暫存、未分類想法 | 永遠是暫時的、要定期清空 |
| `Atlas/Sources/` | 完整原始來源（書 / 文章 / 影片 / Podcast） | **永久** |
| `Atlas/Dots/` | 從 Source 拆出的原子知識卡 | **永久** |
| `Atlas/Maps/` | MOC 主題索引頁 | **永久** |
| `Atlas/log.md` | 歸檔記帳本 | **永久** |
| `Efforts/Areas/` | 永續經營的領域（沒有結束日） | 永久 |
| `Efforts/Projects/Active/` | 進行中、有目標和期限 | 完成後搬到 `Efforts/Projects/Done/` |
| `Efforts/Projects/Idle/` | 暫停中、可能回來做 | 半年沒動 → 考慮搬 Sleeping |
| `Efforts/Projects/Sleeping/` | 不再積極做、但有歷史紀錄 | 永久保留 |
| `Efforts/Projects/Done/` | 已完成的專案 | 永久保留（成就紀錄）|

> ⚠️ **永久 vs 暫時**：只有 `Atlas/` 和 `Efforts/`（含 Areas / Projects）是真的「**長期沉澱**」。其他都會隨時間清掉或重整。

---

## 三個常見錯誤

### 錯誤 1：把所有東西都丟 Inbox

「等我有空再分」→ 一個月後 Inbox 累積 50 則、永遠不會清。

**正確**：Inbox 是**暫存**、不是**儲存**。每週至少清一次（跟 Claude 說「處理 Inbox」）。能歸檔的歸 Atlas、能變任務的進 BACKLOG、不要的直接刪。

### 錯誤 2：用 Daily Note 當日記

「今天感覺心情有點低落、跟同事吵架了」→ 這該進 Journal、不是 Daily。

**正確**：Daily = 看任務、Journal = 看你這個人。同一天可以兩份都寫、互不衝突。

### 錯誤 3：知識卡片連到 Inbox

「這張 Dot 是從 Inbox 的某則筆記拆出來的、就連回 Inbox 吧」→ Inbox 清掉後、Dot 的連結變 ghost link、再也回不去原始脈絡。

**正確**：Dot 的 `## References` 段，**只連 `Atlas/Sources/` 或寫「個人想法」**。如果這份 Inbox 筆記值得保留、先把它建成 Source（搬去 `Atlas/Sources/Articles/`）、再拆 Dot 連回去。

---

## 還是不確定？

直接問 Claude：

> 「我有一個 XXX、放哪裡比較好？」

Claude 會根據這份指南 + 你的工作場景判斷、給你建議。

---

## 下一步

- 了解每日規劃怎麼跑 → [[04-Daily-Planning]]
- 了解週節奏（週一規劃 / 週五收尾）→ [[05-Weekly-Routine]]
- 了解知識怎麼歸檔 → [[06-Knowledge-Capture]]
