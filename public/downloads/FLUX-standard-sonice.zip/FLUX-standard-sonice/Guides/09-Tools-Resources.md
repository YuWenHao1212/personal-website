---
order: 9
---

跑 FLUX 你需要什麼工具？答案是：一個免費的 App 就夠了。其他都是選配。

---

## 必備

| 工具 | 用途 | 費用 |
|------|------|------|
| [Obsidian](https://obsidian.md) | 筆記 + Vault 管理 | 免費（個人使用） |

就這樣。其他都是選配。

---

## 推薦

| 工具 | 用途 | 費用 |
|------|------|------|
| Obsidian Sync | 跨裝置同步 Vault | $4/月 |
| iCloud / Dropbox / Google Drive | 替代同步方案（免費） | 免費 |

---

## 選配（AI 增強）

| 工具                                                        | 用途              | 費用          |
| --------------------------------------------------------- | --------------- | ----------- |
| [Claude Code](https://claude.ai)                          | AI CLI 自動化工具    | $20/月 (Pro) |

詳見 [[08-Upgrade-with-AI]] 的設定說明。

---

## 推薦書單

| 書名                        | 作者           | 為什麼推薦          |
| ------------------------- | ------------ | -------------- |
| *Atomic Habits*           | James Clear  | 理解習慣如何養成與持續    |
| *How to Take Smart Notes*（卡片盒筆記） | Sönke Ahrens | 卡片盒筆記法的原始方法論   |
| *Building a Second Brain* | Tiago Forte  | 另一個知識管理的觀點     |

---

## 本 Vault 指南

| 資源 | 內容 |
|------|------|
| [[01-Quick-Start]] | 從這裡開始 |
| [[Home]] | 你的儀表板 |
| 所有 Templates | 現成可用的模板 |
| [[08-Upgrade-with-AI]] | AI 自動化指南 |

---

## 課後支援

| 資源 | 對象 | 怎麼聯繫 |
|---|---|---|
| 工作坊 LINE 群 | 工作坊學員（裝環境 / 用 AI 卡住） | 群內找講師 |
| Email 講師（進階諮詢） | 進階問題 / 個人諮詢 | mail@yu-wenhao.com |
| yu-wenhao.com | 看更多 AI 工作流相關文章 | 直接逛 |
