# setup-integrations.md — Outlook / 釘釘 串接（選配，給 Claude Code 看的執行腳本）

> 這份是**選配**串接指南：把公司的 Outlook 信箱（M365）和釘釘行事曆接進 Claude Code。
> **前提**：公司 IT 已完成對應的前置設定（見各 Part 開頭的「IT 前置條件」）。還沒開放就先不要跑 — 跑了也會卡在授權那步。
> 使用者說「串接 email」→ 跑 Part A；「串接行事曆」→ 跑 Part B。兩個獨立、可只裝一個。

---

## 給 Claude 的總原則

- **一步一步帶**：每步跑完確認成功才進下一步、失敗就停下回報（不要自己亂試 workaround）
- **所有指令在 PowerShell 跑**（不是 Git Bash）— 釘釘 dws 在 Git Bash 會有路徑格式問題
- **授權流程由使用者親自操作**：瀏覽器登入、輸入公司帳密、按同意 — Claude 只給指引、不經手帳密
- 卡住 → 請使用者到工作坊 LINE 群找講師、保留錯誤訊息截圖

---

## Part A：Outlook 信箱（Microsoft 365）

### IT 前置條件（管理員做、一次性）

公司 M365 管理員需要先在 Azure 完成（沒做完以下步驟、使用者登入會被拒絕）：

1. `portal.azure.com` → Microsoft Entra ID → App registrations → 建立應用程式（例如「SO NICE AI Tool」）
2. API permissions → Microsoft Graph → Delegated → `Mail.ReadWrite`、`Mail.Send`、`offline_access`
3. **Grant admin consent**
4. 把 Tenant ID + Client ID 提供給講師 / 學員

### Step A1：確認 Node.js

```powershell
node --version
```

需要 **v20 以上**。沒有 → 請使用者回安裝頁裝 Node.js LTS、裝完重開 PowerShell 再試。

### Step A2：加入 MCP server

> Windows 上 `npx` 是 `.cmd` 檔，**必須**用 `cmd /c` 包起來，否則 Claude Code 啟動不了它。

```powershell
claude mcp add ms365 -s user -- cmd /c "npx -y @softeria/ms-365-mcp-server --org-mode --preset mail"
```

（如果講師有提供 Tenant ID / Client ID，附加 `--tenant-id <TENANT> --client-id <CLIENT>` 參數。）

### Step A3：登入授權（使用者親自操作）

重啟 Claude Code 後，請使用者說「登入 Outlook」→ 呼叫 ms365 的 `login` 工具 → 會給一個網址 + 一組代碼：

1. 使用者自己開瀏覽器到該網址、輸入代碼
2. 用**公司 M365 帳號**登入、按同意
3. 回到 Claude Code 呼叫 `verify-login` 確認

### Step A4：驗證

1. **讀**：「列出我今天收到的信」→ 應該列得出來
2. **寫**：「幫我草擬一封測試信存草稿匣」→ 用 `create-draft-email`、然後請使用者開 Outlook 確認草稿匣有這封
3. 跟使用者說明安全規則：**Claude 永遠只存草稿、不直接寄**（CLAUDE.md 已有此規則）

---

## Part B：釘釘行事曆（DingTalk）

### IT 前置條件（管理員做、一次性）

1. 釘釘管理員登入 `open-dev.dingtalk.com`（開發者後台）
2. 找「CLI 訪問管理」（CLI Access Management）→ 啟用
3. 員工申請時（Step B3 的 Apply）後台一鍵核准

### Step B1：安裝 dws CLI（PowerShell）

```powershell
irm https://raw.githubusercontent.com/DingTalk-Real-AI/dingtalk-workspace-cli/main/scripts/install.ps1 | iex
```

裝完驗證：

```powershell
dws --version
```

### Step B2：把 dws skill 裝進 Claude Code

```powershell
dws skill setup --mode mono --target claude --yes
```

裝到 `%USERPROFILE%\.claude\skills\dws\`。用 mono 模式（穩定版）、不要用 multi（實驗中）。

### Step B3：登入授權（使用者親自操作）

```powershell
dws auth login
```

會開瀏覽器 → 使用者用自己的釘釘帳號登入、選 SO NICE 組織、授權（管理員核准後才會過）。

驗證：

```powershell
dws auth status
```

### Step B4：驗證

1. **讀**：「我今天有什麼日程？」→ Claude 用 `dws calendar event list` 查
2. **寫**：「幫我建一個明天 10 點的測試日程」→ 建立前先唸內容給使用者確認 → 建完請使用者開釘釘 app 確認看得到 → 確認後刪掉測試日程
3. 提醒安全規則：**建 / 改 / 刪日程前都會先跟你確認、預設不加其他參與者**（CLAUDE.md 已有此規則）

### 已知地雷

- Token 偶爾 auto-refresh 失敗 → 重跑 `dws auth login` 即可
- 用 Git Bash 跑 dws 會有路徑問題 → 一律 PowerShell

---

## 裝完之後

兩個都裝好（或只裝其中一個）後，告訴使用者：

> ✅ 串接完成。之後直接說「整理今天的信」「草擬回信」「我明天有什麼日程」「幫我建個會議」就能用。
> 規則：信永遠只存草稿、日程動作前會先跟你確認。

本檔**不要刪** — 之後換電腦 / token 失效重設時還會用到。
