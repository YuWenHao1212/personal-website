# SETUP-CLAUDE.md — vault 第一次設定（給 Claude Code 看的執行腳本）

> 這份檔是給 **Claude Code（Sonnet）** 看的、不是給你（使用者）看的。
> 在 vault 內跑 `claude`、貼「請讀取 Inbox/SETUP-CLAUDE.md 並依步驟執行」即可、Claude 會照下面跑完並自動刪掉本檔。

---

## 給 Claude 的執行步驟（請照順序跑、跑完報結果）

### Step 1：偵測 vault 結構

跑 `ls -la` 看 vault 根目錄有什麼：

| 看到什麼 | 代表 | 下一步 |
|---|---|---|
| `.claude/` + `.obsidian/` | mac / Linux 解壓（隱藏資料夾保留） | **跳到 Step 3** |
| `_claude/` + `_obsidian/` | Windows 解壓（zip 改名避開隱藏） | **進 Step 2** |
| 兩種都沒 | vault 不完整 | **停下、回報**「vault 根目錄找不到 `.claude/_claude` 或 `.obsidian/_obsidian`、請確認 zip 完整解壓」 |

### Step 2：rename 隱藏資料夾（Windows 解壓才跑）

跑：

```bash
mv _claude .claude && mv _obsidian .obsidian
```

跑完用 `ls -la` 驗證 `.claude/` + `.obsidian/` 都在。失敗就停下回報。

### Step 3：驗證 vault 結構完整

確認下列 path 都存在（用 `ls` 或 `test -e`）：

- `CLAUDE.md`
- `Home.md`
- `.claude/agents/archivist.md`
- `.claude/agents/researcher.md`
- `.claude/skills/knowledge-keeper/SKILL.md`
- `.obsidian/app.json`
- 6 個資料夾：`Templates/`、`Atlas/`、`Cockpit/`、`Efforts/`、`Inbox/`、`Guides/`

少任何一個 → 停下、回報「vault 不完整、缺 X、請重新解壓」。

### Step 4：報告 + 刪除本檔

跑 `rm Inbox/SETUP-CLAUDE.md` 刪掉本檔（已用完、留著只會塞 Inbox）。

然後回報使用者：

> ✅ Vault 結構就緒。`.claude/` + `.obsidian/` 都到位、Claude Code 和 Obsidian 都能認得。
>
> **下一步**：回安裝頁對一次驗證清單、然後用 Obsidian 打開 `Home.md` 開始。第一句可以跟我說「規劃今天」。

---

## 注意

- **本檔只跑一次**：跑完 Step 4 就刪、留著之後 Claude 每次互動會誤讀
- **失敗時保留**：任何 Step 卡住、不要刪本檔、回報錯誤讓使用者 / 講師 debug
- **不要動其他 vault 內容**：本腳本只負責 rename + 驗證、不該改 CLAUDE.md / Templates / Atlas
- **與 setup-integrations.md 的分工**：本檔處理「vault 結構就緒」；`Inbox/setup-integrations.md` 是選配的 Outlook / 釘釘串接（需公司 IT 前置設定、講師通知開放後才跑）— **不要**在本檔跑完後主動推銷那個
