# SETUP-CALENDAR.md — 釘釘行事曆串接（給 Claude Code 看的執行腳本）

> 這份檔是給 **Claude Code（Sonnet）** 看的、不是給你（使用者）看的。
> 在 vault 內跑 `claude`、貼「請讀取 Inbox/SETUP-CALENDAR.md 並依步驟執行」即可。
> 過程中需要：你的手機（釘釘 App 掃 QR code）+ 管理員（人資）核准一次。

---

## 給 Claude 的執行步驟（請照順序跑、每階段完成先讓使用者確認再繼續）

使用者是 SO NICE 的同仁、用 Windows 電腦、不是工程師 — 全程用白話引導。

### 重要規則（全程遵守）

1. 這次只做「安裝 + 登入 + 驗證讀取」：只能「讀取」行事曆，絕對不要建立、修改、刪除任何日程。
2. 任何指令失敗：把完整錯誤訊息原文顯示給使用者，停下來等，不要自己嘗試其他修復方式。
3. 除了 dws 本身，不要安裝任何其他軟體。
4. 需要使用者在手機或瀏覽器操作時，明確說「現在換你做」並描述會看到什麼畫面。
5. 【記錄 log】開始時在使用者桌面建 `dws-setup-log.md`。每階段把「階段編號、時間、指令、完整輸出原文、你的判斷」追記進去。卡住時這份 log 給講師判讀用。
6. log 絕不寫入 token、密碼、金鑰 — 出現就用 [已遮蔽] 取代。

### 階段 0：環境確認

- 桌面建 log 檔，第一筆：時間、Windows 版本、PowerShell 版本。
- 跑 `dws version` 看是否已裝過（沒裝是正常，不算錯誤）。
- 網路測試：`Test-NetConnection login.dingtalk.com -Port 443`，結果記 log。

### 階段 1：安裝 dws（釘釘官方 CLI）

- PowerShell 執行：
  irm https://raw.githubusercontent.com/DingTalk-Real-AI/dingtalk-workspace-cli/main/scripts/install.ps1 | iex
- 裝完跑 `dws version` 確認版本號。指令找不到（PATH 問題）→ 引導使用者關掉終端機重開再試。
- 安裝器會自動把 dws skill 裝進 `.claude\skills\dws` — 這是正常的，記 log 即可。

### 階段 2：登入授權（最關鍵的一步）

- 執行 `dws auth login`。
- 瀏覽器會開釘釘登入頁 → 現在換使用者做：用手機釘釘 App 掃 QR code、選 SO NICE 組織、按授權。
- 如果出現「CLI data access is not enabled」/「等待管理員核准」之類訊息：**這不是錯誤**。指令會自動送出申請並等待。請使用者立刻 LINE 通知人資（管理員）到釘釘開發者後台（open-dev.dingtalk.com → CLI 訪問管理）按核准 — 通常一分鐘內就過、指令會自動繼續。
- 等超過 5 分鐘還沒過 → 停下、記 log、請使用者改天再跑一次（人資核准後隨時可重來）。
- 成功後跑 `dws auth status` 確認 authenticated: true，記 log。

### 階段 3：讀取驗證

- 查「今天和明天」的行事曆日程（用 dws calendar 查詢指令、只讀取；語法不確定先 --help）。
- 用表格列給使用者看，請使用者確認跟釘釘 App 裡看到的一致。
- 結果記 log（只記筆數和主旨，不記日程詳細內容）。

### 階段 4：收尾

1. 結果總結追記到 log 最上方（安裝版本 / 授權結果 / 讀到幾筆 / 卡住的地方）。
2. 跑 `rm Inbox/SETUP-CALENDAR.md` 刪掉本檔（已用完）。
3. 告訴使用者：

> ✅ 釘釘行事曆串接完成。重開 Claude Code 之後，直接說「**看我今天的行程**」「**幫我找明天下午的空檔**」就能用。
>
> 桌面有一份 `dws-setup-log.md`，可以刪掉；如果過程有卡住，把它傳給講師。

---

## 注意

- **成功才刪本檔**：任何階段卡住、保留本檔 + log、截圖傳 LINE 群找講師
- **管理員核准是一次性的**：核准過一次之後，以後重新登入（token 過期重掃 QR）都不需要再核准
- **不要動其他 vault 內容**：本腳本只負責 dws 安裝與驗證
