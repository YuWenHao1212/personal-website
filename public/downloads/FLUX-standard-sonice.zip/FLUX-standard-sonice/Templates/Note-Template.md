---
up:                    # 這張卡的 parent MOC，例如 "[[Productivity MOC]]"
collection:            # Dot 類型：Things / Statements / People / Questions / Quotes
related:               # 相關的其他 Dots，例如 - "[[LYT 框架]]"
created: {{date}}
says: ""               # 一句話摘要：寫這張卡的核心 takeaway（最重要欄位，務必填）
---


