# Windows 版 FLUX-standard 還原 — 給 Claude 的指令（不是給人看的）

你是 Claude Code，正在 Windows 學員的電腦上跑。
這份 prompt 會把 `_claude/` 和 `_obsidian/` 還原成 `.claude/` 和 `.obsidian/`。

> **為什麼需要**：Windows File Explorer 預設隱藏 dot 開頭的資料夾，所以打包時改名讓學員看得到。Obsidian / Claude Code 真正要用的還是 dot 開頭的版本，所以必須還原。

---

## 全程規則

- 全程在同一對話完成、不打斷。每完成一個 Part 就回報結果、再進下一個。
- Claude Code 每個 Bash 呼叫都是 fresh shell — Part 0 拿到 `VAULT_ROOT` 後，後續所有 `"$VAULT_ROOT/..."` 必須**替換成絕對路徑字串**，不要依賴 shell 變數展開。
- 任何步驟失敗 → 停下來告訴學員「請聯絡講師」，不要自己 debug。

---

## Part 0：環境檢查

跑：

```bash
pwd
```

預期看到 vault 根目錄（例：`C:\Users\<name>\Documents\FLUX-standard` 或 macOS path）。

**確認你在 vault 根目錄**：

```bash
test -f Home.md && test -f CLAUDE.md && test -d Cockpit && test -d Inbox && echo "ROOT OK" || echo "WRONG DIR"
```

- 看到 `ROOT OK` → 把 `pwd` 結果記成內部變數 `VAULT_ROOT`（後續 Bash 替換用），進 Part 1
- 看到 `WRONG DIR` → 告訴學員「請先 `cd` 到 FLUX-standard 資料夾內再重跑」，停下來

---

## Part 1：偵測 staging 狀態

跑：

```bash
test -d _claude && echo "_claude=YES" || echo "_claude=NO"
test -d _obsidian && echo "_obsidian=YES" || echo "_obsidian=NO"
test -d .claude && echo ".claude=YES" || echo ".claude=NO"
test -d .obsidian && echo ".obsidian=YES" || echo ".obsidian=NO"
```

根據四個結果決定走哪條：

| `_claude` | `_obsidian` | `.claude` | `.obsidian` | 走哪 |
|---|---|---|---|---|
| YES | YES | NO | NO | **Part 2A**（正常情況） |
| YES | YES | YES | YES | **Part 2B**（學員手快先開過 Obsidian，強制覆蓋） |
| NO | NO | YES | YES | **Part 3**（已 rename 過，只需驗證） |
| 其他組合 | | | | **停下來** — 告訴學員「vault 結構異常，請聯絡講師」+ 把四個結果列給他看 |

---

## Part 2A：正常 rename

```bash
cd "<VAULT_ROOT 絕對路徑>"
mv _claude .claude
mv _obsidian .obsidian
```

跑完進 Part 3 驗證。

---

## Part 2B：強制覆蓋（學員先開過 Obsidian 的救援路徑）

> 設計決策：工作坊 setup 階段學員不可能有真實設定要保護，直接刪空殼用 `_obsidian/` 覆蓋。

```bash
cd "<VAULT_ROOT 絕對路徑>"
rm -rf .claude .obsidian
mv _claude .claude
mv _obsidian .obsidian
```

跑完進 Part 3 驗證。

---

## Part 3：驗證結構

```bash
cd "<VAULT_ROOT 絕對路徑>"
test -d .claude/agents && \
test -d .claude/skills/knowledge-keeper && \
test -d .obsidian/plugins/custom-sort && \
test -d .obsidian/plugins/obsidian-style-settings && \
test -d .obsidian/themes/AnuPpuccin && \
test -f .obsidian/workspace.json && \
echo "VAULT OK" || echo "VAULT BROKEN"
```

- **看到 `VAULT OK`** → 進 Part 4 結案
- **看到 `VAULT BROKEN`** → 跑下面這段把實際狀態列出來，給學員看，叫他聯絡講師（不要自己修）：

  ```bash
  for p in .claude/agents .claude/skills/knowledge-keeper \
           .obsidian/plugins/custom-sort \
           .obsidian/plugins/obsidian-style-settings \
           .obsidian/themes/AnuPpuccin \
           .obsidian/workspace.json; do
    test -e "$p" && echo "OK  $p" || echo "MISSING  $p"
  done
  ```

---

## Part 4：結案

跟學員說：

- ✅ vault 已還原 — `.claude/` 和 `.obsidian/` 都就位
- 現在可以打開 Obsidian → 「開啟資料夾」→ 選這個 vault 資料夾
- 第一次開 Obsidian 會自動載入 plugin（custom-sort 排序、style-settings 樣式、AnuPpuccin theme）
- Windows File Explorer 看不到 `.claude/` 和 `.obsidian/` 是**正常的**（系統預設隱藏 dot 開頭資料夾）— Obsidian 和 Claude Code 內部都能讀到
- 這份 `SETUP-CLAUDE.md` 可以保留在 `Inbox/`，下次重設用得到

不要說「rename 完成」這種技術細節給學員 — 就講「設定還原完成、可以開 Obsidian 了」。
