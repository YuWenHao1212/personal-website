# 板子模式 — 流程差異（給 Claude 讀）

> 只有 `CLAUDE.md` 開頭「板子設定」的看板網址**有填**時，本檔才適用。
> 本檔只寫「與 CLAUDE.md 原文不同的地方」— 沒寫到的步驟一律照 CLAUDE.md 原文執行。
> 部署、API 端點、欄位、重置指令 → 一律查同資料夾 `DEPLOY.md`（單一出處，本檔不重複）。

---

## 總則

1. **卡片 = 任務的唯一帳本。** `BACKLOG.md` 已退役；`Efforts/` 目錄仍是專案本體的家，卡片用
   effort 欄連回去。同一件事不要同時記在檔案和板子 — 兩本帳一定失聯。
2. **目標層完全不變。** VISION / 12-WEEK-PLAN / Phase Review / 反向 sync 規則 2-4 照 CLAUDE.md 原文跑。
   板子只接手「執行層」：任務池、每日挑卡、每週計分。
3. **fail-soft — 看板連不上就退回檔案流程。** 任何看板呼叫失敗（連不上／錯誤回應／409 重試 3 次仍失敗）：
   (a) 跟使用者說一聲「板子連不上、這步先照檔案流程做」；
   (b) 該步驟改照 CLAUDE.md 原文執行。**注意**：啟用時 Weekly-Commitment 任務段與 BACKLOG.md
   已退役——fallback 時別照檔上的 checkbox 報完成率（永遠 0）、別把 BACKLOG 公告當任務池，
   進度改以最近的 daily notes 推估、並跟使用者說明是估算；
   (c) 在今天 Daily Note 筆記區記一行「⚠ 板子未同步：{做了什麼}」；
   (d) 下次連上時，先把 ⚠ 記錄補同步到卡，再進流程。

## 硬規則（違反會弄壞資料）

- **跟看板讀寫一律用 curl**（python urllib/requests 會被 Cloudflare 擋 403）。用法見 `DEPLOY.md`。
- **寫入一律帶 `expectedRev`、一次一件、不平行**。完整規則見 `DEPLOY.md`「寫入安全」段。
- **WAM 先抄後封**：分數與完成卡清單先抄進 `Weekly-Commitment.md` 歷史，才跑結算封存（順序不可反）。
- 砍卡（放棄）＝把卡的 `resolution` 填 `dropped`，**不是刪卡** — 有 resolution 的卡不進計分、留下紀錄。

---

## 開工差異（其餘照原文）

- **自動提醒（Prereq 之後）**：第 2 條「還有 Y 個 Lead Indicators 未完成」的 Y 改跟看板本週 Score 拿
  （total − done）；其餘提醒照原文（讀的是 WC「本週」meta、兩模式共用）。
- **Step 1（補同步 fallback）**：改為 — 讀昨天 Daily「已完成」清單對卡號，發現卡還不是 done 的
  **先列出來問一句**：「這幾張 Daily 說做完了、板上不是 done — 是忘了收工（我補成 done）？
  還是你後來自己退回的（維持現狀）？」確認才改、**不自動蓋**（板子可能有你後來手動的修正）。
  「對應」欄空白的項目照原文處理（提醒、不主動補）。
- **Step 3（本週進度）**：完成率改問看板本週 Score（done／total／%）——**帶 week 參數查**，
  以 WC「本週起訖」所在的 ISO 週為準（換算見 DEPLOY.md「使用備忘」Week 條；
  12-WEEK-PLAN 的 W{N} 是季內序號、不是 ISO 週，別直接搬）；W{N} Day X 照原文從 12-WEEK-PLAN 算。
  本週一張卡都沒掛（total = 0）→ 跟使用者說「本週還沒掛卡」、規劃時順便挑卡掛 week，不硬報分數。
- **Step 4（掃描任務）**：**不掃 Efforts 目錄**，改跟看板拿整板一次：
  - 「Todo」＋「In Progress」＝今天的候選清單（effort 欄顯示所屬專案）
  - 「Blocked」：due 已到／已過的卡，逐張問「要拉回今天嗎？」
  - 「Backlog」：created 距今 ≥28 天的卡點名提醒（卡 body 內有日期行〔搬家／延回〕→ 以**最新一行**為準；
    tags 含 `seed` 的卡**跳過** — 「未來再說」不逼表態；強制清理留給 WAM）
  - 臨時冒出來的事：使用者**真的要承諾本週做完**才掛 week（進分母）；只是順手做掉、不想佔承諾分母
    → 開卡 tag `bonus`（做完算加分、不稀釋分數）
  - `Inbox/` 累積提醒照原文
- **Step 5（建 Daily Note）**：任務表「對應」欄改填**卡號＋標題**（例 `ISS-042 週報彙整`）。
  選進今天的卡：還在 backlog／todo 的改成 todo 或 in-progress（真的開始做才 in-progress）、
  沒掛 week 的補上本週。

## 收工差異（其餘照原文）

- **Step 1** 補一句：完成紀錄以看板為準 — git log 看不到改卡。
- **Step 4（同步）**：不打勾 Weekly-Commitment（板子模式沒有 checkbox 清單），改為逐卡同步：
  - 做完 → 卡改 done；還在做 → 留 in-progress；今天沒動也不打算做 → 問使用者退回 todo 或 backlog
  - 做完、卡住、**或進度有變**的卡順手留言：做了什麼／進度到哪（例 2/3 次）、產出在哪、
    卡在哪／等什麼 — 標準是「之後打開這張卡，不用翻對話紀錄就能接手」

## WAM 差異（其餘照原文）

- **Step 1（計分）**：分數改跟看板拿本週 Score（done／total／%）——帶 week 參數、
  以 WC「本週起訖」的 ISO 週為準（同開工 Step 3），燈號表照原文。
  回應裡的卡片清單留著 — Step 7 抄歷史要用。total = 0 → 跟使用者確認本週沒掛卡、跳過計分。
- **Step 3（carry-over）**：對象＝本週 week 卡裡 status 不是 done 的，逐張問 做／拆／延／砍：
  - **做** ＝ week 改下週、標題尾加 `⟲N`（`⟲2` 不准再選「做」— 照原文強制規則）
  - **拆** ＝ 開子卡第一張（week=下週、⟲ 重計）；原卡 resolution 填 `dropped`、留言「拆為 {新卡號}」
  - **延** ＝ week 清空、退回 backlog（body 補一行今天日期 — 給 28 天鬧鐘用）
  - **砍** ＝ resolution 填 `dropped`
  - 反向 sync 規則 2 的兩個必問照原文。
- **Step 4（Bonus）**：本週 tags 含 `bonus` 的卡＝計畫外完成清單；升級判斷照原文，
  升級＝開正式卡（下週 week、去掉 bonus tag）。
- **Step 5（清理）**：掃「看板 Backlog 欄」created ≥28 天的卡（body 有日期行〔搬家／延回〕以最新一行為準；
  tags 含 `seed` 的卡跳過），三選一照原文；拉進下週＝week 填下週、status 改 todo。
- **Step 5.5（Effort 對齊）**：判定表照原文，加查 orphan：對照板上未封存卡的 effort 欄 —
  active 專案板上一張卡都沒有 → 問「開一張卡？還是這專案該歸檔／搬 Idle？」
- **Step 6（Lock 下週）**：＝讓下週的卡到位 — carry／拆／Backlog 拉進來的已改好，
  新項目開新卡（week=下週、status=todo、對得上就掛 effort）。總數 3-5 張照原文；
  挑卡時攤開 12-WEEK-PLAN 的目標對照 — 每張下週卡都該說得出服務哪個目標。
- **Step 7（寫進 Weekly-Commitment＝分數簿）**：
  - 歷史紀錄加 `### W{N}（起訖）— XX%`：資料一律用 Step 1 拿到的那份 —
    完成卡逐行 `[x] 卡號 標題`；未完成卡 `[ ] 卡號 標題 → 做⟲N／拆／延／砍`；bonus 卡列「Bonus」小段
  - 「本週」meta 三行改下週、本週分數清空、Lag 觀察表 — 都照原文
  - **然後才結算封存**：本週 week 的 done 卡＋dropped 卡逐張封存（一次一件）；
    或請使用者按板上「結算封存」鈕 — 第一次問偏好、之後記住（**按鈕只封 done 卡 — dropped 卡由 Claude 補封**）。
    封存時順掃：板上還有**更早週**的 done／dropped 殘卡（上次沒封完的）→ 一併封存。
    封存不影響歷史週查分（歷史分數永遠可跟看板重查）。
- **W12 循環收尾**：跑完最後一次 WAM（含結算封存）後 — 本季完成卡全在封存區；
  **Backlog 卡跨季保留**（想法池不因換季蒸發），新一季第一次 WAM 的 28 天鬧鐘會逼舊卡表態。
  使用者想整板從零開始 → `DEPLOY.md`「重置資料」（先警告：含封存區全清、不可復原）。

## 開卡規則（隨時適用）

幫使用者建卡時：把講過的脈絡整理進卡片內容；缺關鍵資訊最多追問一題、不知道的不編；
對得上 `Efforts/` 路徑就掛 effort、對不上留空；預設進 Backlog（使用者說「這週要做」才掛 week、填 todo）。
標準同留言：之後打開這張卡，不用再問、不用翻對話就能接手。

## Inbox 批次差異

「轉為任務」→ 開一張看板 Backlog 卡（不寫 BACKLOG.md）；或照原文寫進今天的 Daily Note。
