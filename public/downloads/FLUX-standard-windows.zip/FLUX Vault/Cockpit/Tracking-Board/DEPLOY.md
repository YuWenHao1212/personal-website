# FLUX Tracking Board — 部署說明

FLUX Tracking Board：一頁式個人任務看板 — Backlog → Todo → In Progress → Done（＋Blocked 停車格），附本週 Score 與結算封存。
跑在你自己的 Cloudflare 帳號上（免費方案就夠），資料存在 Workers KV。

> 本檔 = 部署＋API 使用說明（給 Claude 照做）。**請保持檔名 `DEPLOY.md`** — `BOARD-MODE.md` 與啟用流程都指名讀它。
> 這是什麼、要不要啟用 → 看同資料夾的 `README.md`。

## 需要的東西

- Cloudflare 帳號（免費）
- Node.js（含 npx）
- 第一次會要你登入：跑指令時跳出瀏覽器授權即可（`npx wrangler login`）

## 部署三步

在這個資料夾（`wrangler.toml` 所在位置）打開終端機：

**1. 建 KV namespace（存看板資料的地方）**

```bash
npx wrangler kv namespace create BOARD_KV
```

> 說「已存在」？表示這個帳號之前跑過 — 沿用舊的 id（跑 `npx wrangler kv namespace list` 找），或先刪掉重建。

**2. 填 id**

上一步會印出一段設定，把其中的 `id`（32 碼英數字）貼進 `wrangler.toml` 最下面：

```toml
[[kv_namespaces]]
binding = "BOARD_KV"
id = "貼你剛拿到的 id"
```

（`binding = "BOARD_KV"` 不要改。）

**3. 部署**

```bash
npx wrangler deploy
```

跑完會印出網址（`https://tracking-board.你的子網域.workers.dev`），打開就是你的看板。

> ⏳ 剛部署完的前幾分鐘，網址偶爾會回 404 或 `error code: 1042`（雲端還在佈點），連續失敗兩三次也正常 — 等 30 秒再試，不是你做錯。

## 建卡：走 API（給 Claude 用）

看板上沒有「新增」按鈕 — 建卡是 Claude 的工作。把你的看板網址給 Claude，請它幫你開卡：

```bash
curl -X POST "https://tracking-board.你的子網域.workers.dev/api/issues" \
  -H "content-type: application/json" \
  -d '{"fields":{
    "title": "彙整本週門市銷售週報",
    "type": "task",
    "priority": "P1",
    "status": "todo",
    "week": "2026-W29",
    "effort": "Efforts/Projects/Active/月活動表",
    "tags": ["週報"],
    "due": "2026-07-17",
    "body": "- [ ] 收齊各店檔案\n- [ ] 彙整成表"
  }}'
```

（實際使用時，`fields` 旁請照下方「寫入安全」多帶一個 `"expectedRev"`。）

`fields` 裡的欄位都可省略（有預設值）。常用欄位：

| 欄位 | 值 | 說明 |
|---|---|---|
| `title` | 文字 | 卡片標題 |
| `status` | `backlog` / `todo` / `in-progress` / `done` / `blocked` | 不給 = `backlog` |
| `type` | `task` / `bug` / `feature` / `chore` | 不給 = `task` |
| `priority` | `P0`–`P3` | 不給 = `P2` |
| `week` | ISO 週，例 `2026-W29` | 掛了才進本週 Score |
| `effort` | `Efforts/Areas/…` 或 `Efforts/Projects/Active/…` | 看板依它自動分組 |
| `tags` | 陣列，例 `["週報"]` | 特殊 tag：`seed` = 未來再說（虛線卡、不計分）、`bonus` = 額外做的（不計分） |
| `due` / `body` | 日期 / Markdown | 選填 |

其他 endpoints（改卡、留言、封存也都能請 Claude 代打）：

```
GET    /api/issues                 整包看板
GET    /api/score?week=2026-W29    某週 Score（省略 week = 本週）
GET    /api/archive                封存卡
PATCH  /api/issues/:id             {"fields":{...}} 改卡（改 status、補 week…）
POST   /api/issues/:id/comments    {"comment":{"text":"..."}} 留言
POST   /api/issues/:id/archive     封存
POST   /api/issues/:id/unarchive   還原
```

### 寫入安全（expectedRev — 給 Claude 的必守規則）

看板整包存 KV，兩筆寫入同時進來會互相蓋掉。所以：

1. **寫入前先 `GET /api/issues`**，回應的 `meta.rev` = 目前版本號
2. **每筆寫入（POST / PATCH）body 都帶 `"expectedRev": <那個 rev>`**（跟 `fields` / `comment` 並列）
3. 每筆寫入成功的回應都有新的 `rev` — 連續寫入就一路帶下去（不用重新 GET）
4. 收到 **HTTP 409** = 板子在你讀取之後被改過：重新 GET 拿最新 `meta.rev`、確認內容沒衝突，再重試
5. **寫入一律一次一件** — 等前一筆回應成功再發下一筆，不要平行發（平行寫同一塊板仍可能互相蓋掉）

沒帶 expectedRev 的寫入照舊接受（相容），但請一律帶。

## 使用備忘

- **跟看板 API 讀寫一律用 curl**：用 python（urllib / requests）打這個網址會被 Cloudflare 擋下（403）。
- **寫入帶 expectedRev、一次一件**：見上方「寫入安全」— 兩筆寫入平行發會互相蓋掉。
- **網址 = 鑰匙**：沒有登入機制，拿到網址的人就能看能改。自己用沒問題，別把網址公開貼出去。
- **重新整理瀏覽器 = 重載**：看板沒有重載按鈕，Claude 幫你開完卡後，重新整理頁面就看到。
- **Week 欄位**用 ISO 週格式（例：`2026-W29`），掛了 week 的卡才進 Score。
  今天所在的 ISO 週：`TZ='Asia/Taipei' date '+%G-W%V'`（mac / Linux 通用）。
  ⚠️ 12-WEEK-PLAN 的 W1~W12 是「季內第幾週」、不是 ISO 週——填卡一律用上面指令換算，別直接搬 W{N}。
- **Effort 欄位**對應你 vault 的路徑（`Efforts/Areas/…` 或 `Efforts/Projects/Active/…`），看板會自動依它分組。
- **換網址／洩漏補救**：改 `wrangler.toml` 的 `name` 再 deploy = **建新 worker，舊的不會消失** —
  要再跑 `npx wrangler delete --name 舊名字` 刪掉，洩漏的網址才失效（新舊綁同一個 KV、卡片不受影響）。
- **重置資料**：`npx wrangler kv key delete board:v2 --binding BOARD_KV --remote`（整板清空、從頭開始）。
- **改欄名**：欄位定義在 `src/worker.js` 最上面的 `STATUSES` 常數（KV 只存卡片）。改 `name` → `npx wrangler deploy` → 重新整理頁面就生效；`id` 別動（卡片資料綁它）。
- 改完 `public/index.html` 或 `src/worker.js` 後，重跑 `npx wrangler deploy` 就更新。deploy 完的頭幾秒可能還跑到舊版 — 等 5–10 秒再重新整理驗收。
