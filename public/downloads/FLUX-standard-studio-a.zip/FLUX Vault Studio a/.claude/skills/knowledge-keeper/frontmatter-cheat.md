# Frontmatter 照抄表

**什麼是 frontmatter**：每個 .md 檔案最上面用 `---` 包起來的區塊，放這個檔的標籤資訊。
**不用懂語法，照抄、填空就好。**

兩種主要檔型：
- **Source**（完整原始來源）→ `Atlas/Sources/{type}/`
- **Dot**（從 Source 拆出的原子知識卡）→ `Atlas/Dots/{類別}/`

---

## Source 範本（完整原始來源）

路徑：`Atlas/Sources/{Articles|Books|Videos|Podcasts|Courses|Talks|Papers}/YYYY-MM-DD-主題關鍵字.md`

```markdown
---
up:
  - "[[個人效率 MOC]]"
type: article
url: "https://internal.studioa.example/scheduling-guide"
author: "Kat Chang"
created: 2026-05-19
status: read
---

> 這份 Source 在講 Kat 2026-05 定義的排課新流程：催辦郵件三段式 + 講師優先順序 + 排課衝突 72 小時規則。

## Key Takeaways

- 催辦郵件分成開場、內容、確認三段
- 講師優先順序有三層：核心 / 備援 / 客座
- 排課衝突要在 72 小時內回覆

## Dots

- [[催辦郵件的三段式結構]]
- [[講師優先順序有三層]]
- [[排課衝突要 72 小時內回覆]]
- [[學員分班的三個判斷條件]]

## References

來源：[Kat Chang 內部郵件 2026-05-19](https://internal.studioa.example/scheduling-guide)
```

**怎麼填**：

| 欄位 | 寫什麼 | 範例 |
|---|---|---|
| `up` | 這份 Source 屬於哪個 MOC 主題（可多個）| `"[[個人效率 MOC]]"` |
| `type` | 來源類型（7 選 1） | `article` / `book` / `video` / `podcast` / `course` / `talk` / `paper` |
| `url` | 原始連結 | `"https://..."`（書沒有就空字串 `""`） |
| `author` | 作者 / 主講人 / 出處 | `"Kat Chang"` |
| `created` | 建檔日期 | `2026-05-19` |
| `status` | 讀完狀態 | `read` / `reading` / `to-read` / `archived` |

**Source 內文結構**：
- 開頭 blockquote 一段概述（這份來源在講什麼）
- `## Key Takeaways` — 3-5 個重點 bullet
- `## Dots` — 從這 Source 拆出的 Dot 卡 wikilink（拆完 Dot 後回頭填）
- `## References` — 原始連結 / 書目資訊

---

## Dot 範本（知識卡片）

路徑：`Atlas/Dots/{Things|Statements|People|Questions|Quotes}/一句話結論.md`

```markdown
---
up:
  - "[[個人效率 MOC]]"
collection: Things
related:
  - "[[LINE 已讀不回不等於客戶無意願]]"
  - "[[排課衝突要 72 小時內回覆]]"
created: 2026-05-19
says: "催辦郵件分成開場、內容、確認三段，學員讀信速度快且欄位齊全"
---

催辦郵件是對外溝通的標準工具。經過 2026-05 的新流程定義，郵件結構固定為三段：

## 開場（學員資訊）

- 學員姓名、員工編號
- 所屬門市、區域
- 已完成哪些前置課程
- 本次報名的課程名稱、編號

## 內容（時段+講師）

- 建議時段（至少給 2-3 個選項）
- 指派講師（照講師優先順序排）

## 確認（回覆期限）

- 請學員於 72 小時內回覆確認時段（見 [[排課衝突要 72 小時內回覆]]）

## References

來源：[[Sources/Articles/2026-05-19-排課新流程]]
```

**怎麼填**：

| 欄位 | 寫什麼 | 範例 |
|---|---|---|
| `up` | 這張卡屬於哪個 MOC 主題（可多個） | `"[[個人效率 MOC]]"`、`"[[催辦 MOC]]"` |
| `collection` | 這張卡是哪一類（**純字串、不要 wikilink**）| `Things` / `Statements` / `People` / `Questions` / `Quotes` |
| `related` | 相關的其他 Dot 卡（橫向連結） | `"[[催辦郵件的三段式結構]]"` |
| `created` | 建卡日期 | `2026-05-19` |
| `says` | **一句話講這張卡的重點**（15-30 字） | 依 5 類各自寫法（見下表） |

**Dot 內文結構**：
- 一句話定義 / 核心觀點（不寫 H1）
- 可有 `## H2` 子段（細節、舉例、應用）
- 最後 `## References` 段：
  - 有 Source 檔 → wikilink 連回 `[[Sources/{type}/YYYY-MM-DD-XXX]]`
  - 個人想法 → 寫「個人想法 / created YYYY-MM-DD」
  - Inbox 來源 → 寫「Inbox 來源 / 處理日 YYYY-MM-DD」

⚠️ **Dot frontmatter 不放 `source_url` / `source_author` / `source_date`**。來源資訊存在 Source 檔；Dot 用 `## References` wikilink 連回 Source。

⚠️ **`collection` 用純字串**，不要寫 `"[[Things]]"`。

---

## 5 類各自的 `says` 寫法

| 類型 | `says` 句型 | 範例 |
|---|---|---|
| **Things** | 「X 是 Y 的 Z」 | 「12 Week Year 是 Brian Moran 提出的目標執行週期框架」 |
| **Statements** | 「X 因為 Y 所以 Z」 | 「執行力贏過完美計畫，因為計畫會在執行中發現盲點」 |
| **People** | 「X 的角色，以 Y 聞名」 | 「Nick Milo 是 LYT 框架的創造者，以 Obsidian 知識管理聞名」 |
| **Questions** | 「為什麼 X 會導致 Y？」 | 「為什麼 LINE 已讀不回不等於客戶拒絕？」 |
| **Quotes** | 「原句——作者」 | 「Action is the antidote to despair——Joan Baez」 |

---

## People 卡的差異

`People/` 類的 Dot 可以多填 2 個欄位：

```markdown
---
up:
  - "[[教學培訓 MOC]]"
collection: People
related:
  - "[[催辦郵件的三段式結構]]"
created: 2026-05-19
says: "Kat Chang 是 STUDIO A 教學培訓部主管，定義了排課流程"
role: "教學培訓部主管"
company: "STUDIO A"
---

關於這個人的筆記：背景、偏好、合作風格、聯絡方式。

## References

第一次見面：2026-05-19
個人想法（無 Source 檔）
```

**多填 2 欄**：`role`（職位）+ `company`（公司）。

---

## Questions 卡的差異

`Questions/` 類的 Dot 是「思考種子」—— 值得反覆探索、沒有最終答案的問題、多填 1 個欄位追蹤思考狀態：

```markdown
---
up:
  - "[[個人品牌 MOC]]"
collection: Questions
related:
  - "[[Hook-First 寫作方法]]"
created: 2026-05-19
says: "為什麼長文章 SEO 比短文章好？"
status: open
---

問題的背景、為什麼要查、查到之後要做什麼。

## References

來源：自己想到的
個人想法（無 Source 檔）
```

**多填 1 欄**：`status`（`open` / `answered` / `deprecated`）。

---

## log.md 範本

路徑：`Atlas/log.md`（每次歸檔 append 一段）

```markdown
## 2026-05-19 14:30 | 歸檔主題

- 來源：[[Sources/Articles/2026-05-19-XXX]] 或 「個人想法」
- 新增 Dots：[[新卡片 1]]、[[新卡片 2]]
- 矛盾：無

---
```

**欄位**：
- 第一行：日期時間 + 歸檔主題簡述
- 來源：Source wikilink 或「個人想法」字面字
- 新增 Dots：這次歸出來的卡片 wikilink
- 矛盾：
  - 無衝突 → 寫「無」
  - 有衝突 → 寫「⚠️ 與 [[舊卡片]] 衝突：一句話說明」

---

## MOC 範本（Map of Content）

路徑：`Atlas/Maps/主題名 MOC.md`

對齊 FLUX `Templates/Map-Template.md` 的極簡風格 + 五類分區：

```markdown
---
up:
created: 2026-05-19
---

這個主題的目錄頁。一句話描述主題範圍。

---

## Things

- [[卡片 1]]
- [[卡片 2]]

## Statements

- [[卡片 3]]

## People

- [[某某某]]

## Questions

- [[思考種子 1]]

## Quotes

- [[語錄 1]]
```

MOC 不要寫 H1 標題（檔名已是標題）。從一句話主題描述開始。

**MOC 門檻**：主題累積 ≥ 3 張 Dot 才建 MOC（1-2 張還不用）。

---

## 常見錯誤

| 錯誤 | 正確做法 |
|---|---|
| Dot 檔名寫「催辦筆記 1.md」 | 改成結論：「LINE 已讀不回不等於客戶無意願.md」 |
| `related` 連到 `Inbox/` | Inbox 會被清空，`related` 要連 `Atlas/Dots/` 的其他卡片 |
| Dot 內文寫 `# H1` | 檔名已經是標題，直接從內文開始 |
| `up` 亂填（填不存在的 MOC） | 先檢查 `Atlas/Maps/` 有沒有，沒有就先建 MOC 再回來填 |
| `collection: "[[Things]]"`（wikilink） | 改純字串：`collection: Things` |
| `collection` 填了不存在的類型 | 只能 5 選 1：Things / Statements / People / Questions / Quotes |
| Dot frontmatter 塞 `source_url` / `source_author` | 移除這些欄位、改在 Source 檔放，Dot 用 `## References` wikilink 連回 |
| URL 來源直接拆 Dot 不建 Source | 先建 `Atlas/Sources/{type}/YYYY-MM-DD-XXX.md`、再拆 Dot |
