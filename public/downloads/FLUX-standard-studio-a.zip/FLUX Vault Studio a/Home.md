嘿，歡迎來到 **STUDIO A AI 工作流 vault**。

FLUX 是我（余文皓）整合幾套經典方法 + Claude Code 出來的個人工作方法（PARA / 卡片盒筆記 / 12 Week Year，細節見下方〈三套方法論〉），這個版本為 STUDIO A 客製。

這是你個人的 AI 工作區。Claude 知道你在做什麼、知道你的工作場景、會幫你規劃今天、寫信、查行事曆、整理筆記、跑數據分析。

> **F**ocus 專注目標 · **L**earn 連結知識 · **U**pgrade 迭代升級 · e**X**ecute 每日執行

---

## 從這裡開始

如果這是你第一次打開 vault，**先讀這份**：

→ [[00-STUDIO-A-開箱指南]]（10 分鐘了解這個 vault 怎麼用 + 你能拿來做什麼）

讀完後再讀：

→ [[01-Quick-Start]]（系統結構 + 基本操作）

---

## 設定好之後，你的日常就這麼簡單

**每天用得到的指令**：

- **開工** → 跟 Claude 說「規劃今天」 — Claude 看你的進行中專案、待辦、昨天紀錄，幫你排今天要做的事
- **收工** → 跟 Claude 說「收工」 — 晚上 5 分鐘回顧今天
- **寫日記** → 跟 Claude 說「寫日記」 — 早晚各一次反思
- **記錄一個想法** → 跟 Claude 說「記錄一個想法」 — 想法進 Inbox、之後再整理
- **歸檔知識** → 跟 Claude 說「[歸檔] 這篇文章」— 拆成可重用的知識卡片
- **處理 Inbox** → 跟 Claude 說「處理 Inbox」 — 批次整理累積的筆記

**每週用得到的指令**：

- **週一 開工**（含自動 weekly review）→ 跟 Claude 說「開工」 — Claude 會先確認本週 commitment（保持 / 微調 / 重新 lock）、再接 daily 規劃
- **週五 週末收尾** → 跟 Claude 說「週末收尾」或「lock 下週」 — 10-15 min 結算本週 + Lock 下週
- **臨時想調整本週清單** → 跟 Claude 說「調整本週」 — 週中主管加事 / 想換優先序時用

---

## Vault 結構

```
Inbox/              -- 快速捕捉（每日處理）
Atlas/              -- 知識管理（Sources / Dots / Maps）
Calendar/Journal/   -- 個人日記
Cockpit/            -- 個人駕駛艙（Daily / Weekly-Commitment / BACKLOG）
Efforts/            -- 工作場景（Areas / Projects）
Guides/             -- 11 篇自學教學（00 開箱 + 01-09 主題 + 10 FAQ）
Templates/          -- 模板（不要動）
```

詳細結構見 [[01-Quick-Start]]。

---

## 三套方法論

FLUX 站在三套經典方法論上 — 管行動、管知識、管執行：

**PARA · 管行動**（Tiago Forte《打造第二大腦》）— 用可行動程度分類：Projects 有 deadline、Areas 持續經營、Archive 沉睡舊案 → `Efforts/`（完成進 `Projects/Done`、休眠進 `Sleeping`）。第四類 **Resources（主題參考）就是下面的 `Atlas/`**。

**卡片盒筆記 · 管知識**（Luhmann《卡片盒筆記》；[[02-LYT-Framework|LYT]] 是它的 Obsidian 實現）— 這層正是 PARA 的 Resources，一卡一概念、wikilink 互相連結，筆記越多複利越大 → `Atlas/`。

**12 Week Year · 管執行**（Brian Moran《12週做完一年工作》）— 本週承諾 → 每日執行 → 週五 WAM 結算 → `Cockpit/`。

行動、知識、執行分開存，wikilink 串起來，Claude 在上面跑（讀檔、寫信、查行事曆、跑分析）— 就是一個會自己流的工作系統。

---

## 卡住的時候

1. 先翻 `Guides/` 裡對應的那一份教學
2. 問你手邊的 Claude Code（`CLAUDE.md` 已經教它怎麼帶你）
3. 還是卡 → LINE 訊息給 Kat / Peggy（課程結束後仍可問），或寫信到 [mail@yu-wenhao.com](mailto:mail@yu-wenhao.com)

---

## 延伸閱讀（選讀）

想更懂背後的思路、或把它用得更深：

- [多數人學 AI 的順序反了：先方向、再系統，AI 才是槓桿](https://yu-wenhao.com/zh-TW/blog/flux-direction-system-leverage/?utm_source=flux-vault-studio-a&utm_medium=vault) — FLUX 的核心理念
- [從 Obsidian 到 Claude Code：打造可程式化的人生](https://yu-wenhao.com/zh-TW/blog/personal-panopticon/?utm_source=flux-vault-studio-a&utm_medium=vault)
- [Claude Code 教學：5 分鐘完成安裝與第一個任務](https://yu-wenhao.com/zh-TW/blog/claude-code-tutorial/?utm_source=flux-vault-studio-a&utm_medium=vault)
