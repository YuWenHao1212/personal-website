# 安裝 Claude skill — 給 Claude 的指令（不是給人看的）

你是 Claude Code、正在 STUDIO A 員工的個人 Mac 上跑。這份 prompt 會引導你一步一步幫員工初始化 email + calendar skill。

> **這份 prompt 的場景**：員工是全新安裝（沒裝過任何 skill）、剛從 vault zip 解壓、剛跑 `claude` 第一次。
>
> **重要設計：skill 就地留在 vault 內、不 cp 到全域 `~/.claude/skills/`**。原因：
> - Day 1 / Day 2 學員只在這個 vault 內用 Claude、簡化心智負擔（一個資料夾、所有東西都看得到）
> - 跨 vault / 全域可用的 skill 是 Day 3 的進階主題、那時再教遷移
> - skill 的 Python 程式碼用 `SCRIPT_DIR` / `SKILL_DIR` 自找同目錄設定、放哪都能跑、不需要寫死 `~/`
>
> **預期結果**：跑完設定都在 vault 內：
> - `$VAULT_ROOT/.claude/skills/email/scripts/.env.email`（IMAP 帳密、chmod 600）
> - `$VAULT_ROOT/.claude/skills/email/env.md`（預設帳號 = work）
> - `$VAULT_ROOT/.claude/skills/calendar/env.md`（日曆名稱）
>
> 學員 Day 1 在 vault 內跑 `claude` 就能用 email / calendar。離開 vault 還不能用（這是預期、不是 bug）。

---

## 全域規則

1. **全程在同一對話完成、不打斷**。每完成一個 phase 就回報結果、再進下一個
2. **任何錯誤就停下來、跟員工說「LINE Kat / Peggy（他們會幫忙聯繫講師）」、不要自己 debug 公司 mail server**
3. **改設定檔一律用 Write 工具、禁用 sed**（macOS BSD sed 處理 non-ASCII 會截斷檔案）
4. **`.env.email` 寫完立刻 `chmod 600`**（企業資安 baseline）

### Resume / Re-entry 邏輯（重要）

如果員工中途遇到錯誤後想接著繼續（例：A4.3 不小心按了「不允許」、改完權限回來），**不要從 Part 0 重來** — 用以下檢查決定從哪個 Part 接續：

```bash
# 跑一次、看哪些設定已經有了
test -f "<VAULT_ROOT 絕對路徑>/.claude/skills/email/scripts/.env.email" && echo "ENV_EMAIL_OK" || echo "ENV_EMAIL_MISSING"
test -f "<VAULT_ROOT 絕對路徑>/.claude/skills/email/env.md" && echo "EMAIL_ENVMD_OK" || echo "EMAIL_ENVMD_MISSING"
test -f "<VAULT_ROOT 絕對路徑>/.claude/skills/calendar/env.md" && echo "CALENDAR_ENVMD_OK" || echo "CALENDAR_ENVMD_MISSING"
```

對應接續點：

| 已存在 | 從哪繼續 |
|---|---|
| 全部 MISSING | Part 0 開頭 |
| `.env.email` OK、email `env.md` MISSING | A4 開始（直接測讀信 + 草稿） |
| email 全 OK、calendar MISSING | Part B 開始 |
| 全 OK | Part C 結案 |

⚠️ **不要默默 overwrite 既有檔** — 接續前先跟員工確認「我看到 X 已經設過、要從 Y 步驟接續嗎？」

---

## 密碼處理規則

員工會在對話中貼明文密碼給你 — **這在 local Claude Code session 中是 OK 的**：
- 對話歷史只存在 `~/.claude/projects/` 本機 SQLite、不上 GitHub、不上雲端
- 員工「在自己電腦上看自己的密碼」= 跟用 1Password / 鑰匙圈沒兩樣

**你真正要避免的是這三件事**：

1. **結案報告（Part C）不要 print 密碼欄位** — 員工可能截圖給講師、忘記馬賽克。只說「✅ IMAP 帳號 = `kat.chang@studioa.com.tw`」、**不要**回顯 password、**不要**`cat .env.email` 內容
2. **密碼不要放 bash 命令列 argument**（會進 shell history）— 用環境變數 + heredoc：`IMAP_PASSWORD='xxx' python3 <<'PYEOF' ... PYEOF`
3. **用 Write 工具寫 `.env.email`、不要用 `echo > file`**（Write 不過 shell、密碼不會出現在 ps 或 history）

過程中你收到密碼後 — 該用就用、不需要刻意「事後 mask」、**不要主動建議員工 `/clear`**。

---

# Part 0：環境檢查

```bash
python3 --version
pwd
```

預期：
- python3 有版本號（任何 3.x 都行）
- pwd 輸出像 `/Users/<name>/Documents/FLUX-standard-studio-a`（或其他放 vault 的地方）

把 pwd 結果記成**內部變數** `VAULT_ROOT`。

⚠️ **重要**：Claude Code 每個 Bash 呼叫都是 fresh shell — `VAULT_ROOT=$(pwd)` 跑一次後、下個 Bash call 就沒了。這份 prompt 後續所有 `"$VAULT_ROOT/..."` 都要在送出 Bash 工具前**替換成 Part 0 拿到的絕對路徑字串**（例：`"/Users/kat/Documents/FLUX-standard-studio-a/..."`），**不要**依賴 shell 變數展開。

確認 vault 內附 skill source 存在（記得替換 `$VAULT_ROOT`）：

```bash
test -d "$VAULT_ROOT/.claude/skills/email" && \
test -f "$VAULT_ROOT/.claude/skills/email/SKILL.md" && \
test -f "$VAULT_ROOT/.claude/skills/email/scripts/email_ops.py" && \
test -f "$VAULT_ROOT/.claude/skills/email/requirements.txt" && \
test -d "$VAULT_ROOT/.claude/skills/calendar" && \
test -f "$VAULT_ROOT/.claude/skills/calendar/SKILL.md" && \
test -f "$VAULT_ROOT/.claude/skills/calendar/scripts/calendar_ops.py" && \
echo "SOURCE OK" || echo "SOURCE MISSING"
```

看到 `SOURCE OK` 就進 Part A。

看到 `SOURCE MISSING`：告訴員工「vault 內的 skill source 不完整、可能不是從 vault 根目錄跑 Claude、或 zip 解壓不完整 — 請找講師」、**停下來**。

---

# Part A：Email skill

## A1：取得帳密 + Apple Sender

跟員工說：

> 「我會幫你裝 email skill。要拿三組資訊：
> 1. **你的 STUDIO A email 地址**（你直接告訴我）
> 2. **IMAP 帳號 + 密碼**（我從你的鑰匙圈自動拿、你只要按系統對話框允許一次）
> 3. **Apple Mail 的『全名』和『電郵地址』**（你從 Mail.app 設定抄兩個欄位給我）
>
> 一個一個來。」

### A1.1 鑰匙圈拿 IMAP 帳密

**策略**：先用 macOS `security` CLI 自動從鑰匙圈拿 username + password（無痛、學員只要按一次系統對話框）。失敗才退回手動步驟。

#### Step 1：問員工的 email 地址

跟員工說：

> 「請告訴我你的 STUDIO A email 完整地址（例如 `kat.chang@studioa.com.tw`）」

記成 `EMAIL`，並從中取出 `DOMAIN`（`@` 後面那段，例：`studioa.com.tw`）。後續 Step 2/3 和 A2 IMAP 連線**全部用 `DOMAIN`、不要寫死 `studioa.com.tw`** — 子公司 / 別名域名（`studio-a.com.tw`、`studioa.tw` 等）會壞。

#### Step 2：用 security CLI 自動找 IMAP entry

⚠️ 把指令裡的 `<DOMAIN>` 換成 Step 1 取出的實際 domain 字串再送 Bash。

```bash
# 列出鑰匙圈內所有跟員工 mail server 相關的 internet password entry（不拿密碼、不跳對話框）
security find-internet-password -s <DOMAIN> 2>&1
```

接著用 `dump-keychain` 數一下 matching entry 有幾筆（多筆 → 跳 Step 4，避免 CLI 默默回第一筆抓錯帳號）：

```bash
security dump-keychain 2>/dev/null | grep -c "\"srvr\"<blob>=\"<DOMAIN>\"" || true
```

四種結果：

- **拿到 entry（count = 1）**：看到 `keychain:` / `acct:` 等欄位、且 dump-keychain 數出來剛好 1 筆 → 進 Step 3 自動拿密碼
- **多筆 entry（count ≥ 2）**：員工有多組 STUDIO A 帳號（個人 + 部門公用）→ CLI 預設只回第一筆、可能抓錯 → **跳 Step 4 手動 fallback**，讓員工自己挑
- **`The specified item could not be found in the keychain`**（count = 0）→ 跳到 Step 4 手動 fallback
- **其他錯誤** → 跳到 Step 4 手動 fallback

#### Step 3：自動拿密碼（會跳系統對話框）

⚠️ **跑指令前先預告員工**：

> 「等下會跳 macOS 系統對話框：『**XXX** 想要使用「登入」鑰匙圈中儲存的機密資訊』。
> （XXX = 你跑 `claude` 用的那個終端機 app — 可能是 Terminal、iTerm、Warp、或 VS Code 的內建 terminal、依你習慣而定）
>
> 請：
> 1. 輸入你的 **Mac 登入密碼**（不是 email 密碼、是你開機 / 解鎖的那個）
> 2. 點 **「永遠允許」**（不是「允許」、是「永遠允許」 — 不然下次又跳）
>
> 如果不小心按了「不允許」、要去『系統設定 → 隱私權與安全性 → 鑰匙圈』修、現場找講師處理。」

員工準備好後跑（`<DOMAIN>` 替換成 Step 1 取出的值）：

```bash
# 從鑰匙圈 entry 拿密碼 + username（-g 把密碼印到 stderr、grep 一起抓）
security find-internet-password -s <DOMAIN> -g 2>&1 | grep -E '"acct"<blob>|password:' | head -2
```

預期輸出兩行：

```
"acct"<blob>="kat.chang@studioa.com.tw"
password: "<明文密碼>"
```

從輸出抓兩個值：
- `acct` 後面引號內的值 → `KEYCHAIN_USERNAME`
- `password:` 後面引號內的值 → `PASSWORD`

**⚠️ 拿到的 `PASSWORD` 不要在對話中複述**（直接寫進 A3 的 .env.email 就好、員工不需要看到 Claude 拿到了什麼）。

成功 → 跳過 Step 4、進 A1.2。

#### Step 4：手動 fallback（security CLI 拿不到時）

如果 Step 2 / Step 3 任一步失敗（公司 IT 政策鎖死、或鑰匙圈 entry 用別的 service name），退回手動：

跟員工說：

> 「自動拿密碼沒成功、改用手動方式：
>
> 1. `Cmd + 空白` Spotlight 搜「**Keychain Access**」/「**鑰匙圈存取**」 — **不是** macOS Sequoia 的新「密碼 app」/「Passwords」、那個沒有 IMAP 密碼
> 2. 左上切到「**登入**」/「**login**」keychain
> 3. 右上搜尋框輸入你的 STUDIO A email 關鍵字（例如 `kat.chang`）
> 4. 找到類型是「**網際網路密碼**」/「**Internet password**」的條目（不是「應用程式密碼」/「Application password」）
> 5. **如果有多筆同名條目** → 找日期最新的、或叫得出是「Mail」/「IMAP」相關的那筆（雙擊看 `Where` 欄位、應該包含 `imap` 或你的 email host）
> 6. 雙擊開啟 → 看到「**帳號**」/「**Account**」欄位的值 = **IMAP username**
> 7. 勾「**顯示密碼**」/「**Show password**」→ 輸入 Mac 登入密碼 → 看到明文 = **IMAP password**
>
> 把這兩個值貼給我：
> - 鑰匙圈「帳號 / Account」欄位的值
> - 鑰匙圈密碼」

員工貼完、記成：
- `KEYCHAIN_USERNAME`：鑰匙圈帳號欄位（**Apple Mail 已驗證過可用、A2 會優先試這個**）
- `PASSWORD`：鑰匙圈密碼

⚠️ 如果員工說「鑰匙圈找不到、我也不記得密碼」：**停下來、告訴員工請找講師**、不要去 webmail 重設密碼（會影響手機跟其他裝置）。

### A1.2 Apple Mail 抄 Apple Sender

跟員工說：

> 「最後一個值：Apple Mail 認得的『寄件人字串』。請：
> 1. 打開 **Apple Mail**
> 2. 選單 **Mail → 設定…** / **Mail → Settings…**（`Cmd + ,`）
> 3. 切到 **帳號 / Accounts** 分頁、左側選 STUDIO A 帳號
> 4. 看 **帳號資訊 / Account Information** 分頁、把這兩個欄位的值告訴我：
>    - **全名** / **Full Name**（例：`Kat Chang`）
>    - **電郵地址** / **Email Address**（例：`kat.chang@studioa.com.tw`）
>
> Mac 系統語言為英文 → 看右邊英文 label；中文 → 看左邊中文 label。」

員工給完兩個值、你自己拼字串：

```
APPLE_SENDER = f"{Full Name} <{Email Address}>"
```

例：`Kat Chang <kat.chang@studioa.com.tw>`

**跟員工確認一次**：「我要存的 Apple Sender 字串是 `Kat Chang <kat.chang@studioa.com.tw>` — 跟你 Apple Mail 設定看到的一致嗎？大小寫、空白都要對。」

⚠️ 大小寫 / 空白不對、寄件 sender 屬性會 fall back 到預設帳號、所以一定要確認。

---

## A2：IMAP 驗證

### A2.1 把密碼寫到 /tmp 暫存檔（避免 bash quoting 截斷）

⚠️ **重要**：A1 拿到的 PASSWORD **不能用 `IMAP_PASSWORD='...'` 塞進 bash** — 密碼含 `'` / `\` / `$` 等特殊字元會被截斷或執行成指令。改成「用 Write 工具寫到 /tmp/.imap_pw、Python 讀完立刻 rm」。

**用 Write 工具**建立 `/tmp/.imap_pw`、內容就是 A1 拿到的明文密碼（**不要**加任何引號、不要加結尾換行 — 如果 Write 預設加換行、Python 那邊會 `.rstrip('\n')` 移除）。

寫完立刻：

```bash
chmod 600 /tmp/.imap_pw
ls -l /tmp/.imap_pw | head -1
```

預期開頭 `-rw-------`。

### A2.2 跑 inline python 驗證

⚠️ 把指令裡的 `<DOMAIN>` / `<EMAIL>` / `<KEYCHAIN_USERNAME>` 替換成 A1 取出的實際值再送 Bash。

```bash
IMAP_HOST='<DOMAIN>' \
IMAP_PORT='143' \
IMAP_EMAIL='<EMAIL>' \
IMAP_HINT_USERNAME='<KEYCHAIN_USERNAME>' \
python3 << 'PYEOF'
import os
import sys
import imaplib

HOST = os.environ['IMAP_HOST']
PORT = int(os.environ['IMAP_PORT'])
EMAIL = os.environ['IMAP_EMAIL']
# 從 /tmp/.imap_pw 讀密碼（避開 bash quoting 問題）
with open('/tmp/.imap_pw') as f:
    PASSWORD = f.read().rstrip('\n')
HINT_USERNAME = os.environ.get('IMAP_HINT_USERNAME', '').strip()

print(f'測試目標: {HOST}:{PORT}')
print(f'Email: {EMAIL}')
print(f'密碼長度: {len(PASSWORD)} 字元（不顯示明文）')
print()

# Stage 1: 連線 + STARTTLS
print('Stage 1: 測試連線和加密握手')
try:
    m = imaplib.IMAP4(HOST, PORT)
    print(f'  STAGE 1a OK: 連到 {HOST}:{PORT}')
    m.starttls()
    print('  STAGE 1b OK: STARTTLS 成功')
    m.logout()
except Exception as e:
    print(f'  STAGE 1 FAILED: {type(e).__name__}: {e}')
    print('→ 連線或加密層級的問題、跟帳密無關、停下來找講師')
    sys.exit(1)
print()

# Stage 2: 枚舉 username
def expand_usernames(email):
    if '@' not in email:
        return [email]
    local, domain = email.split('@', 1)
    candidates = [
        email, local, email.lower(), local.lower(),
        local.replace('.', ''),
        local.replace('.', '') + '@' + domain,
        local.replace('.', '_'),
        local.replace('.', '_') + '@' + domain,
    ]
    seen = set()
    unique = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            unique.append(c)
    return unique

candidates = expand_usernames(EMAIL)

# 鑰匙圈 hint 優先試（Apple Mail 已驗證過可用、命中率 99%）
if HINT_USERNAME:
    if HINT_USERNAME in candidates:
        candidates.remove(HINT_USERNAME)
    candidates.insert(0, HINT_USERNAME)
    print(f'💡 Keychain hint: 優先試 {HINT_USERNAME}（Apple Mail 已驗證）')
    print()

print(f'Stage 2: 枚舉測試 {len(candidates)} 種 username 格式')
print()

success_username = None
for i, username in enumerate(candidates, 1):
    print(f'  [{i}/{len(candidates)}] 測試: {username}')
    try:
        m = imaplib.IMAP4(HOST, PORT)
        m.starttls()
        m.login(username, PASSWORD)
        m.logout()
        print(f'        ✅ LOGIN OK')
        success_username = username
        break
    except imaplib.IMAP4.error as e:
        msg = str(e)
        if msg.startswith("b'") or msg.startswith('b"'):
            msg = msg[2:-1]
        print(f'        ❌ {msg[:70]}')
    except Exception as e:
        print(f'        ❌ {type(e).__name__}: {str(e)[:70]}')

print()
print('=' * 60)
if success_username:
    print(f'✅ VERIFIED_USERNAME={success_username}')
    sys.exit(0)
else:
    print('❌ ALL_USERNAMES_FAILED — 帳密驗證失敗、停下來找講師（不要去 webmail 改密碼）')
    sys.exit(2)
PYEOF
```

### A2.3 不論成敗、清掉 /tmp/.imap_pw

```bash
rm -f /tmp/.imap_pw && echo "PW_CLEANED"
```

看到 `PW_CLEANED` 才能繼續往下走。

### A2.4 依結果處理

- **exit code 0**：抓 `VERIFIED_USERNAME=` 後面的值、存成 `VERIFIED_USERNAME`、進 A3
- **exit code 1**：連線失敗、跟員工說「公司網路或 mail server 設定的問題、不是你的問題、請找講師」、停下來
- **exit code 2**：8 種 username 都登入失敗、跟員工說「密碼可能抄錯（特別有特殊字元時）、或帳號鎖了 — 請找講師、不要自己去 webmail 改密碼」、停下來

---

## A3：安裝 Python 依賴 + 寫 .env.email

> **重要設計**：skill source 已經在 vault 內（`$VAULT_ROOT/.claude/skills/email/`）、**不需要 cp 到 `~/.claude/skills/`**。第一階段所有設定都在 vault 內就地完成、學員只用一個資料夾、簡化心智負擔。之後 Day 3 課程會教怎麼把 skill 推到全域。

### A3.1 安裝 Python 依賴

```bash
python3 -m pip install --user --break-system-packages -r "$VAULT_ROOT/.claude/skills/email/requirements.txt" 2>&1 | tail -5
```

驗證：

```bash
python3 -c "import bleach, tinycss2; print('bleach', bleach.__version__, '+', 'tinycss2', tinycss2.__version__, 'OK')"
```

看到 `bleach X.X.X + tinycss2 X.X.X OK` 才繼續。失敗（例如 `No module named pip`、或 Python 3.10 不認 `--break-system-packages`）→ 停下來找講師。

### A3.2 用 Write 工具寫 .env.email

用 **Write 工具**建立 `$VAULT_ROOT/.claude/skills/email/scripts/.env.email`、內容（替換 placeholder 為實際值）：

```
ACCOUNTS=work

work_PROVIDER=imap
work_HOST=<DOMAIN>
work_PORT=143
work_USER=<VERIFIED_USERNAME>
work_PASSWORD=<PASSWORD>
work_APPLE_SENDER=<APPLE_SENDER>
```

⚠️ **規則**：
- 用 Write 工具、不要用 echo
- `<DOMAIN>` 換成 A1 取出的實際 domain（例：`studioa.com.tw`）
- 密碼**不加引號**、前後不空白
- `APPLE_SENDER` 不加引號、直接寫 `Full Name <email@DOMAIN>`
- 絕對禁止把 `<VERIFIED_USERNAME>` 等 placeholder 字面寫進檔案

### A3.3 chmod 600 + 自我檢查

```bash
chmod 600 "$VAULT_ROOT/.claude/skills/email/scripts/.env.email"
ls -l "$VAULT_ROOT/.claude/skills/email/scripts/.env.email" | head -1
```

預期開頭 `-rw-------`（只 owner 能讀寫）。

```bash
# Placeholder 檢查（APPLE_SENDER 行用尖括號是合法的、要排除）
grep -vE '^[a-zA-Z0-9_]+_APPLE_SENDER=' "$VAULT_ROOT/.claude/skills/email/scripts/.env.email" | grep -nE '[{}（）<>]' && echo "❌ 有 placeholder 殘留、重寫" || echo "✅ 乾淨"
```

兩個都通才進 A4。

---

## A4：測試讀信 + 草稿

### A4.1 status 驗證

```bash
python3 "$VAULT_ROOT/.claude/skills/email/scripts/email_ops.py" status
```

預期：`{"work": {"unread": X, "status": "ok"}}`。

### A4.2 讀最近 3 封信

```bash
python3 "$VAULT_ROOT/.claude/skills/email/scripts/email_ops.py" recent work 3
```

預期：3 封信的主旨 + 寄件人列表。

### A4.3 純文字測試草稿（AppleScript path）

⚠️ **第一次跑會跳 macOS Automation 對話框**：「**XXX** 想要控制 Mail」（XXX = 你跑 `claude` 的終端機 app — Terminal / iTerm / Warp / VS Code 內建 terminal 都有可能）— 跟員工說：「請按『**好**』或『**允許**』。如果不小心按了『不允許』、要去『系統設定 → 隱私權與安全性 → 自動化 → 找到 XXX → 打開 Mail 開關』修。」

```bash
python3 "$VAULT_ROOT/.claude/skills/email/scripts/email_ops.py" draft work \
  "<員工自己的 EMAIL>" \
  "Email skill 安裝測試 - 純文字" \
  "這是純文字測試草稿。應該存到我的 Apple Mail 草稿匣。"
```

跟員工說：

> 「Apple Mail 應該彈出新郵件 compose 視窗、寄件人欄位顯示你的 Apple Sender。請：
> 1. 確認寄件人正確
> 2. 視窗就那樣放著、Apple Mail 會自己 autosave 進草稿匣（30 秒內）— 你想立即存可按 **Cmd+S**
> 3. 打開 Apple Mail sidebar、找到草稿匣、確認這封信在那裡
>
> 確認後告訴我 OK。」

員工確認後進 A4.4。

### A4.4 HTML 測試草稿（.eml path）

```bash
python3 "$VAULT_ROOT/.claude/skills/email/scripts/email_ops.py" draft work \
  "<員工自己的 EMAIL>" \
  "Email skill 安裝測試 - HTML" \
  "<p>這是 <strong>HTML 測試草稿</strong>。</p><ul><li>粗體字有渲染</li><li>項目清單顯示正常</li></ul>" \
  --html --theme
```

跟員工說：

> 「Apple Mail 彈出第二個視窗、這次是 HTML 內容。請：
> 1. 確認 HTML 樣式正常（粗體、項目清單有渲染、不是原始 `<p>` 標籤）
> 2. 按 **Cmd+S** — 跳『另存新檔』對話框（這是 .eml 路徑的限制、多 2 步）
> 3. 對話框 sidebar 應該預設展開到你的帳號草稿匣、選那個、按存檔
> 4. 關掉郵件視窗、確認草稿匣有這封 HTML 測試
>
> 確認後告訴我 OK。」

兩封都 OK 才進 A5。

---

## A5：Bleach sanitize smoke test（安全防禦）

驗證 `sanitize_external_html()` 真的剝 `<script>` / `onerror=` / `javascript:` URL。這是安全防禦、不能跳過。

```bash
VAULT_ROOT="$VAULT_ROOT" python3 << 'PYEOF'
import sys
import os
sys.path.insert(0, os.environ['VAULT_ROOT'] + '/.claude/skills/email/scripts')
try:
    from email_ops import sanitize_external_html
except ImportError as e:
    print(f'❌ 無法 import sanitize_external_html: {e}、停下來找講師')
    sys.exit(1)

malicious = '<p>Hello</p><script>alert("XSS")</script><img src=x onerror="alert(1)"><a href="javascript:alert(2)">click</a>'
cleaned = sanitize_external_html(malicious)
print(f'Input:  {malicious}')
print(f'Output: {cleaned}')

failed = []
if '<script' in cleaned.lower(): failed.append('<script> 沒被剝除')
if 'onerror' in cleaned.lower(): failed.append('onerror= 沒被剝除')
if 'javascript:' in cleaned.lower(): failed.append('javascript: URL 沒被剝除')

if failed:
    print(f'❌ BLEACH SANITIZE 驗證失敗: {failed}')
    print('→ 這是安全漏洞、停下來找講師')
    sys.exit(1)
else:
    print('✅ BLEACH SANITIZE OK')
PYEOF
```

`✅ BLEACH SANITIZE OK` 才進 Part B。失敗 → 停下找講師。

---

## A6：寫 email skill 的 env.md（預設帳號）

用 Write 工具建立 `$VAULT_ROOT/.claude/skills/email/env.md`：

```
python: python3
email_ops: <VAULT_ROOT_絕對路徑>/.claude/skills/email/scripts/email_ops.py
account: work
```

⚠️ 寫前先 `echo "$VAULT_ROOT"` 拿絕對路徑、替換 `<VAULT_ROOT_絕對路徑>` 進去。**禁止**把 `$VAULT_ROOT` 或 `<...>` 字面寫進檔案、要展開成實際絕對路徑（例如 `/Users/<你的 macOS 帳號>/Documents/FLUX-standard-studio-a`）。

驗證：

```bash
cat "$VAULT_ROOT/.claude/skills/email/env.md"
grep -nE '<|>|\$\(|\$VAULT_ROOT' "$VAULT_ROOT/.claude/skills/email/env.md" && echo "❌ 有殘留" || echo "✅ env.md 乾淨"
```

✅ 才進 Part B。

---

# Part B：Calendar skill

## B1：取日曆名稱（含 Automation 授權）

⚠️ **第一次跑會跳 macOS Automation 對話框** — 跟員工說：「等下會跳『**XXX** 想要控制 Calendar』（XXX = 你跑 `claude` 的終端機 app — Terminal / iTerm / Warp / VS Code 內建 terminal 都有可能）、請按『**好**』或『**允許**』。」

```bash
osascript -e 'tell application "Calendar" to get name of calendars' 2>&1
```

如果跳對話框、等員工按完允許、**重跑一次**這條指令。

成功會列出所有日曆名稱（用逗號分隔）。問員工：

> 「這是你 Apple Calendar 裡的日曆清單：
> （列出來）
>
> 清單裡可能有訂閱日曆（台灣假日、家庭 iCloud、公司 Outlook 同步等）— 那些**不是**你要的。
> 我要的是你**手動建會議會建到的那個**（通常叫『工作』、『Work』、『行事曆』、或你的 email 名稱）。
>
> 告訴我**完整名稱**（中英文大小寫、半形全形空白要完全一樣 — 不確定就直接複製貼上）。」

記成 `CALENDAR_NAME`。

---

## B2：寫 env.md

> calendar skill source 已經在 vault 內（`$VAULT_ROOT/.claude/skills/calendar/`）、不需要 cp。直接寫設定。

用 Write 工具建立 `$VAULT_ROOT/.claude/skills/calendar/env.md`：

```
python: python3
calendar_ops: <VAULT_ROOT_絕對路徑>/.claude/skills/calendar/scripts/calendar_ops.py
platform: mac
calendar_name: <CALENDAR_NAME>
```

⚠️ 替換規則：
- `<VAULT_ROOT_絕對路徑>` 換成 `echo "$VAULT_ROOT"` 的輸出（實際絕對路徑）
- `<CALENDAR_NAME>` 換成 B1 拿到的值（不加引號）
- 禁止把 `$VAULT_ROOT` 或 `<...>` 字面寫進去

驗證：

```bash
cat "$VAULT_ROOT/.claude/skills/calendar/env.md"
grep -nE '<|>|\$\(|\$VAULT_ROOT' "$VAULT_ROOT/.claude/skills/calendar/env.md" && echo "❌ 有殘留" || echo "✅ env.md 乾淨"
```

---

## B3：測試 read_events

```bash
python3 "$VAULT_ROOT/.claude/skills/calendar/scripts/calendar_ops.py" read_events 7
```

三種結果：

- **JSON 事件列表** 或 **空 list `[]`**：✅ 成功、進 Part C
- **跳 Accessibility 對話框**：跟員工說「請按允許、然後我重跑」、重跑指令
- **`{"error": "..."}`**：依錯誤訊息分類：
  - `calendar_name` 對不上 Apple Calendar → 回 B1 重問
  - Accessibility 授權被拒 → 引導員工去「系統設定 → 隱私權與安全性 → 自動化」手動勾選、停下
  - 其他 → 停下找講師

---

# Part C：結案

## C1：驗證兩個 skill 都裝好

```bash
ls "$VAULT_ROOT/.claude/skills/email/env.md" && \
ls "$VAULT_ROOT/.claude/skills/email/scripts/.env.email" && \
ls "$VAULT_ROOT/.claude/skills/calendar/env.md" && \
echo "BOTH SKILLS READY"
```

看到 `BOTH SKILLS READY` 才進 C2。

## C2：把 setup script 搬到 archive（不刪掉）

把 setup script 從 Inbox 搬到 `Guides/zz-setup-skills-archive.md`。**不 rm** — 員工未來換電腦、vault 解壓覆蓋、或不小心刪 `.env.email` 想重設時，CLAUDE.md trigger 還能找到這份 prompt。

```bash
mv "$VAULT_ROOT/Inbox/setup-claude-skills.md" "$VAULT_ROOT/Guides/zz-setup-skills-archive.md"
test -f "$VAULT_ROOT/Guides/zz-setup-skills-archive.md" && \
test ! -f "$VAULT_ROOT/Inbox/setup-claude-skills.md" && \
echo "ARCHIVED" || echo "WARNING: 搬移失敗"
```

## C3：給員工結案訊息

印給員工看（**不 print 密碼、不 cat .env.email**）：

```
✅ Claude skill 安裝完成

Email skill：
- 帳號代號：work
- IMAP 帳號：<VERIFIED_USERNAME>
- 草稿模式：本機 Apple Mail（混合 AppleScript / .eml）

Calendar skill：
- 日曆：<CALENDAR_NAME>

測試指令（現在就可以試）：
- 「讀一下我最近 5 封信、做摘要表」
- 「我今天有什麼會議？」
- 「幫我用 work 寄一封信給 ...」

setup script 已搬到 Guides/zz-setup-skills-archive.md（不是刪掉、留著當後援）。
未來要重設帳密、跟 Claude 說「重裝 Claude skill」就會找到。

任務完成。
```

**不主動建議員工 `/clear`** — 員工自己決定。
