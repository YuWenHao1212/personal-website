---
order: 8
---

這個 Vault 是設計給 **AI 一起用**的。Claude Code（你電腦上的 AI CLI）讀取整個 vault、知道你在做什麼、會幫你做事。

---

## AI CLI 能做什麼

AI 程式助手在你的終端機中運行。它可以讀寫你 Vault 裡的檔案，也就是說它可以：

- **規劃今天** — 從你進行中專案 + Inbox + BACKLOG，跟你討論今天要做什麼、建立每日筆記
- **讀信摘要 + 寫回信草稿** — 用 email skill 接 Mail.app
- **查行事曆 + 建會議** — 用 calendar skill 接 Apple Calendar
- **歸檔知識卡片** — 從一篇文章拆出可重用的原子卡片到 Atlas
- **晚間收工** — 回顧今天、移動未完成事項

---

## 你已經有的 4 個工具

| Skill | 你能說的話 | 做什麼 |
|---|---|---|
| **email** | 「我最近的未讀信摘要」「寫一封回信給 X 確認 Y」| 讀信摘要、寫回信草稿到 Mail.app 草稿匣（**不會自動寄、永遠是草稿**）|
| **calendar** | 「我今天有什麼會議」「幫我建一個會議跟 X 約下週三」| 讀 Apple Calendar、建會議事件 + 通知信草稿（**不會自動寄邀請**）|
| **knowledge-keeper** | 「[歸檔] 這篇文章」「[研究] AI 新趨勢」 | 拆成知識卡片進 Atlas / 收集網路資料 |
| **個人工作流**（Daily / Journal / Inbox / Effort）| 「規劃今天」「寫日記」「處理 Inbox」「新增專案」「收工」| 走 CLAUDE.md 內定義的流程 |

詳見 [[09-Tools-Resources]]。

---

## CLAUDE.md 是什麼

這個 Vault 根目錄有一份 `CLAUDE.md`。Claude Code 打開 vault 時會自動讀取。

它教 Claude：
- 你的資料夾結構（什麼放哪）
- 每日規劃流程
- 收工流程
- Inbox 處理流程
- 求助流程
- 溝通風格偏好

**不用每次重複解釋**。你說「規劃今天」、Claude 就知道整套流程怎麼跑。

---

## 不用 AI 也行

這個 Vault 裡的一切都可以手動操作：
- 複製 `Templates/Daily-Template.md` 自己填、不用 AI 也能做 Daily Note
- `Atlas/` 的知識卡片自己手寫、不一定要 AI 拆
- Inbox 自己整理、不用 AI 建議

結構和框架本身才是真正的價值。AI 只是加速器。

---

## 進階玩法

| 工作流程 | 手動做 | 用 AI 做 |
|---|---|---|
| 每日規劃 | 複製模板，手動填入任務 | 跟 AI 說「規劃今天」、自動帶你討論 |
| Inbox 處理 | 逐則閱讀，判斷類型，手動搬移 | AI 建議類型和連結 |
| 寫回信 | 自己打 | AI 出草稿、你修改後寄出 |
| 查行事曆 | 開 Apple Calendar 看 | 跟 AI 說「今天有什麼會議」 |
| 跨檔搜尋 | 用 Cmd+F | 問 AI「我有什麼關於 X 的筆記？」 |

---

→ 完整工具清單與推薦資源見 [[09-Tools-Resources]]
