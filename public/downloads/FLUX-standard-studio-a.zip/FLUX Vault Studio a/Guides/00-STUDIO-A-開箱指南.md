---
order: 0
---

歡迎來到 STUDIO A AI 工作流 vault。

這是**你個人的 AI 工作區**。三日工作坊（6/2、6/5、6/9）結束後，這個 vault 就是你帶走的東西 — 你電腦上有一個會幫你做事的 Claude 助理。

---

## 為什麼你會收到這個 vault

這是為 **STUDIO A 員工工作場景**設計的個人 AI 工作區。

裡面包含：
- **AI 工作流** — email / calendar / 知識卡片 / 讀檔 / 寫信 / 跑分析
- **日節奏** — 每天「開工」+「收工」5-10 分鐘（週一開工會自動跑 weekly review）
- **週節奏** — 週五「週末收尾 + Lock 下週」10-15 分鐘
- **個人筆記** — Daily / Journal / Inbox / Atlas（知識卡片）

三日工作坊跑這套、結束後你帶走它、你電腦上有一個會幫你做事的 Claude 助理。

---

## 第一次打開要做的 6 件事

### 1. 確認你的環境裝好了

依照公開安裝頁（yu-wenhao.com/zh-TW/studio-a/install）的步驟，你電腦上應該已經有：

| 項目 | 確認方式 |
|---|---|
| VS Code | 能打開、能看 `.md` 檔 |
| Obsidian | 能打開、知道「vault」是什麼 |
| Claude Code | 終端機輸入 `claude` 能跳出 Claude 對話 |
| git / python3 / brew | 終端機跑 `git --version` / `python3 --version` 都有輸出 |
| Mail.app | 已設好 Nusoft 帳號、能正常收發 STUDIO A 公司信 |
| Apple Calendar | 已設好 STUDIO A 公司行事曆、能看到自己工作行程 |

> **任何一項沒有？** 回去公開安裝頁照步驟跑、或 LINE Kat / Peggy。**不要自己亂試**。

### 2. 在 Obsidian 打開這個 vault

1. 開 Obsidian → 點左下角「Open another vault」
2. 選 「Open folder as vault」
3. 找到你電腦上 `FLUX-standard-studio-a/` 資料夾、選它
4. 看到左側邊欄出現 `Inbox / Atlas / Calendar / Cockpit / Efforts / Guides / Templates / Home.md` = 成功

### 3. 在 vault 資料夾打開 Claude Code

1. 開終端機（Terminal.app）
2. `cd` 到你的 vault 資料夾（例：`cd ~/Documents/FLUX-standard-studio-a`）
3. 輸入 `claude` 開始 Claude Code session
4. Claude 會自動讀 `CLAUDE.md` 知道這是你的個人 vault

### 4. 跟 Claude 一起裝 email + calendar skill（10-20 分鐘）

> 這兩個 skill 是讓 Claude 能讀你公司信、看你公司行事曆的「橋」。沒裝、Claude 就只是一般聊天的 AI。

跟 Claude 說一句話：

> 「**裝 Claude skill**」

Claude 會自動讀 `Inbox/setup-claude-skills.md`、依序跑：

- **Part A**：email skill — 問你 IMAP 帳密（從鑰匙圈拿）+ Apple Sender、自動驗證連線、測試草稿到 Apple Mail 草稿匣
- **Part B**：calendar skill — 問你工作行事曆名稱、測試讀取行程
- **Part C**：驗證 + 自動清掉 Inbox 內的 setup script

> **過程中 macOS 會跳系統彈窗**（「Terminal 想要控制 Mail」/「Terminal 想要控制 Calendar」）— 請按「**好**」/「**允許**」、Claude 才能繼續。

> **裝到一半卡住？** Claude 會跟你說「請找講師」就停下來、不要自己 debug 公司 mail server 設定。LINE Kat / Peggy（他們會幫忙聯繫講師），4 小時內會有回覆。

### 5. 填「你是誰」3 欄（2 分鐘）

打開 `CLAUDE.md`、找到開頭的「## 你是誰」section、填這 3 欄：

- **稱呼**：你想被怎麼叫
- **STUDIO A 職位**：部門 + 職位（例如「事業發展部 主任」）
- **直屬主管**（可選）

或直接跟 Claude 說「**幫我填**」、它會一個一個問。

填完後 Claude 對你的所有回應都會更貼近你。

> 不放會變的內容（每週工作 / 每月產出 / 痛點）— Claude 從每天對話自然 infer、或本來就在 `Cockpit/Weekly-Commitment.md`、避免兩處 drift。

### 6. 試一個簡單的事

挑一個你今天就能用得上的：

| 試試看 | 怎麼說 |
|---|---|
| 看看今天信箱有什麼 | 「讀一下我最近的未讀信件，幫我做摘要表」 |
| 看看今天有什麼會議 | 「我今天有什麼會議？明天呢？」 |
| 寫一篇日記 | 「寫日記」 |
| 規劃今天 | 「開工」或「規劃今天」 |
| 第一次 lock 本週 3-5 件主要任務 | 「調整本週」 |

---

## 三日工作坊會教什麼

| 日期 | 主軸 |
|---|---|
| **6/2 (二) 13:30-17:30** | 環境建置 + email + calendar skill 串通 |
| **6/5 (五) 13:30-17:30** | 讀檔 + 比對 + Excel 數據工作流（商品決策主軸）|
| **6/9 (二) 13:30-17:30** | 風格指南 + 投影片 + 自救能力 + 結業 |

三日結束時，你帶走的：
- 一個會跑你工作流的 Claude 助理
- 一份個人 AI Workspace（這個 vault）
- 一套自救能力（卡住怎麼除錯、skill 怎麼自己改）

---

## 卡住的時候

1. **裝環境卡住** → LINE Kat / Peggy
2. **用 AI 卡住** → 先翻 `Guides/` 對應教學、再問你手邊的 Claude
3. **真的搞不定** → 課程結束後仍可問 Kat / Peggy，或寫信到 mail@yu-wenhao.com

---

## 接下來

繼續讀 → [[01-Quick-Start]]（10 分鐘了解整套系統）
