---
order: 10
---

日常使用中最常遇到的問題。找不到答案？直接問 AI「我卡住了」。

---

## 好幾天沒用了，怎麼重新開始？

1. 不用補之前的 Daily Note，直接從今天開始
2. 告訴 AI「規劃今天」，它會自動讀你最近的紀錄
3. 如果跨了週末、上週的「週末收尾」沒做 → 告訴 AI「補上週的週末收尾」
4. 中斷不等於失敗，重新開始就好

---

## 忘了做週末收尾怎麼辦？

補做就好。告訴 AI「補上週的週末收尾」、它會回去看上週的 Weekly-Commitment、結算本週 + Lock 下週。

如果你週一「開工」時 Claude 跑 step 0（自動 weekly review）、發現上週沒收尾 → Claude 會提醒「先補上週收尾、本週清單才是準的」，跟著走就好。

---

## 本週做不完怎麼辦？

正常。週五週末收尾時對沒做完的事「做 / 拆 / 延 / 砍」四選一處理就好。

**連續 2 週都「做」沒做到的事**、第 3 週 AI 會問你「真的還要做嗎？」— 通常表示要拆小、或承認不適合做、改去 BACKLOG。

---

## AI 回應不對怎麼辦？

- **回答跟 Vault 無關** → 確認 AI 有讀到 `CLAUDE.md`（Claude Code 開啟時會自動讀取）
- **找不到檔案** → 確認你是在 Vault 根目錄下執行 AI
- **格式跑掉** → 告訴 AI「用模板格式重寫」
- **完全不對** → 直接告訴它哪裡不對，AI 會修正

---

## email skill 連不上 Nusoft 怎麼辦？

不要自己亂試。LINE Kat / Peggy。

可能的原因（給你心理準備）：
- Nusoft 帳密改了（IT 不定期 rotate）
- macOS 升級後 Mail.app 帳號要重設
- 公司網路防火牆改了

---

## calendar skill 跳「需要授權」彈窗

第一次跑會跳。按「**允許**」就好。

如果按過「拒絕」、回不來：
1. 開 macOS 「系統設定 → 隱私權與安全性 → 自動化」
2. 找 Terminal 或 Claude Code、勾選「Calendar」
3. 回到 Claude 重新跑

---

## Inbox 越來越多怎麼辦？

堆到 5-10 則就該清理。告訴 AI「處理 Inbox」，它會逐一幫你分類：歸檔為知識卡片、轉為任務、繼續放著、或刪除。

詳見 [[06-Knowledge-Capture]]。

---

## 我想刪掉一個專案

告訴 AI「我想完成 / 暫停 / 砍掉專案 X」。AI 會幫你搬資料夾：
- **完成** → 搬到 `Efforts/Projects/Done/`（README 加完成日期）
- **暫停** → 搬到 `Efforts/Projects/Idle/`
- **休眠** → 搬到 `Efforts/Projects/Sleeping/`

詳見 CLAUDE.md 的「Effort 管理」section。

---

## 怎麼清除範例內容？

Vault 裡標有「這是範例內容」的檔案都是預設的示範。設定好你自己的內容後，告訴 AI「幫我清除所有範例標記」，它會一次移除所有範例標記。

你也可以直接刪除整個範例檔案（例如範例的 Daily Note、範例的 Effort READMEs），或保留它們當參考。

---

## 課程結束後我還能問問題嗎？

可以。LINE 給 Kat / Peggy、或寫信 mail@yu-wenhao.com。
