# 把競品比價板接進你的 vault

> 這是 **STUDIO A D 組 8/27 工作坊**的啟始包。裡面是一塊已經寫好、可以直接部署的競品比價板。

## 一句話交給 Claude

打開對話入口，貼這一行：

```
把我 Downloads 裡那包 competitor-board-addon.zip 解壓縮，把裡面的 Cockpit/Competitor-Board 整個資料夾移到我 vault 的 Efforts/Projects/Active/ 底下、改名成 Demo_Competitor_Monitor，然後把 zip 和解壓剩下的空殼刪掉。
```

歸位之後，部署也是一句話：

```
讀 Efforts/Projects/Active/Demo_Competitor_Monitor/DEPLOY.md，照它說的把板部署起來。
```

它會帶你走完：登入 Cloudflare → 部署 → 開第一次抓取。

## 這塊板在做什麼

每週去 **STUDIO A、momo** 抓一次你追蹤的產品，排成一排小卡，一張卡一個產品：

```
┌ KDDI 日本 eSIM · 5 日吃到飽   同價 ┐
│ STUDIO A                    $459  │
│ momo                        $459  │
└ 本週 5 筆 · 點開看明細             ┘
```

每一筆都點得進去，看到數字覺得怪就點進去對。
第三個來源 **PChome 是課堂練習** —— 你會自己把它加上去，加完有些卡的結論會翻盤。

## 放在哪

zip 裡的資料夾叫 `Cockpit/Competitor-Board`，搬進 vault 時**改名成 `Demo_Competitor_Monitor`**，放這裡：

```
你的 vault/
└── Efforts/
    └── Projects/
        └── Active/
            └── Demo_Competitor_Monitor/   ← 整個資料夾放這裡
                ├── DEPLOY.md              部署 + 使用說明（Claude 讀這份）
                ├── wrangler.toml
                ├── src/worker.js
                └── public/
```

為什麼放 `Efforts/Projects/Active/`：這是今天工作坊的**示範專案**，放這裡左邊側邊欄就看得到，不用去 Finder 找。

## 要花錢嗎

不用。Cloudflare 免費方案怎麼用都用不完 —— 一週抓一次，一個月大概幾百次請求，免費額度是每天十萬次。

## 課後怎麼繼續

板子跑在**你自己的** Cloudflare 帳號上，課程結束它照樣每週一早上自己跑。
想加功能就跟 Claude 說，改完 `npx wrangler deploy` 再部署一次。
