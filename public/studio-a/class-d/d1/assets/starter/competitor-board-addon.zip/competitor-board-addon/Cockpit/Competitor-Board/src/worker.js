// 競品比價板 — Durable Object mini-worker（教學版 v4 · 產品視角）
//
// 這支程式做四件事：
//   1. 去 STUDIO A、momo 抓商品（⭐ 第二個搜尋來源 PChome 是課堂練習 —— 加法見 DEPLOY.md）
//   2. 把品名拆成可以比較的欄位（電信商／天數／吃到飽／賣家）
//   3. 存進看板專屬的小資料庫（Durable Object，SQLite）—— 一週存一批
//   4. 按「產品」把三家的價格排在一起，算出我們在市場的位置
//
// ⭐ v3 最重要的改變：從「關鍵字」改成「產品」
//    「日本 eSIM」搜出來 30 筆，3 天的跟 30 天的混在一起 —— 一般人看不懂。
//    「KDDI 日本 eSIM · 5 日吃到飽」在三家各賣多少 —— 這才是人在問的問題。
//
// ⭐ 產品比對是在「讀」的時候做的，不是抓的時候。
//    好處：改產品定義不用重抓；一次爬「日本 eSIM」可以同時餵 3日/5日/7日 三個產品。
//
// ⭐ 為什麼歷史要靠「每週跑一次」累積：
//    網站只給你「現在」的價格。第 1 週只有 1 個點，跑滿 8 週才有那條線。
//
// ⭐ 為什麼用 Durable Object 不用 KV：
//    KV 存得下，但問不出來。DO 是真的資料庫（SQLite），一句 SQL 就撈得出 8 週。
//    而且 DO 不用先建 namespace、不用貼 id — deploy 就能用。

// ── 預設要追蹤的產品 ──
// query   = 拿什麼去 momo / PChome 搜
// must    = 品名必須含這些字，才算是這個產品
// days    = 幾天（eSIM 用；用來比對規格 + 算每天單價）
// sa_page = 我們自己的頁（STUDIO A），沒有就留空
const DEFAULT_PRODUCTS = [
  { id: "kddi-3d", name: "KDDI 日本 eSIM · 3 日吃到飽", query: "KDDI eSIM",
    must: ["KDDI"], days: 3, unlimited: true, sa_page: "/categories/studioa-japan-esim" },
  { id: "kddi-5d", name: "KDDI 日本 eSIM · 5 日吃到飽", query: "KDDI eSIM",
    must: ["KDDI"], days: 5, unlimited: true, sa_page: "/categories/studioa-japan-esim" },
  { id: "kddi-7d", name: "KDDI 日本 eSIM · 7 日吃到飽", query: "KDDI eSIM",
    must: ["KDDI"], days: 7, unlimited: true, sa_page: "/categories/studioa-japan-esim" },
  { id: "skt-3d", name: "SKT 韓國 eSIM · 3 日吃到飽", query: "SKT eSIM",
    must: ["SKT"], days: 3, unlimited: true, sa_page: "/categories/studioa-korea-esim" },
  { id: "skt-5d", name: "SKT 韓國 eSIM · 5 日吃到飽", query: "SKT eSIM",
    must: ["SKT"], days: 5, unlimited: true, sa_page: "/categories/studioa-korea-esim" },
];
// ⚠️ 這份清單只在板子「第一次啟動」時寫進雲端資料庫。
//    之後改這裡再部署是無效的 —— 要加/換追蹤品項，跟 Claude 說或用頁面的「追蹤設定」，
//    走 /api/products 寫進資料庫（見 DEPLOY.md「加你要追的產品」段）。

// ── 排除字（雜訊過濾）──
// ⚠️ 一律用兩個字以上：單字太廣會誤殺
//    （用「包」會把「包含沖繩」「必須簽收包裹」那些真的 eSIM 也刷掉）
const DEFAULT_EXCLUDES = [
  "保護殼", "手機殼", "保護套", "皮套", "保護貼", "防刮", "防摔", "磁吸",
  "鋼化膜", "玻璃貼", "螢幕貼", "鏡頭貼", "鍵盤膜",
  "收納包", "背包", "內膽包", "支架", "立架", "掛繩", "腕掛",
  "充電線", "傳輸線", "充電器", "轉接器", "擴充座", "投影", "清潔",
];
// ⚠️ 這份清單一定不會一次到位 —— 每個品類漏的東西不一樣。
//    覺得哪裡不準，跟 Claude 說「幫我把 XXX 也排掉」，或直接在頁面上加。

const LIMIT_PER_PLATFORM = 30;
const SCHEMA_VERSION = 4;

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
const HDRS = { "user-agent": UA, "accept-language": "zh-TW,zh;q=0.9" };

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
    },
  });

const twStamp = () =>
  new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 19) + "+08:00";
const twDate = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);

function isoParts(d) {
  const t = new Date(d);
  const day = (t.getUTCDay() + 6) % 7;
  t.setUTCDate(t.getUTCDate() - day + 3);
  const ft = new Date(Date.UTC(t.getUTCFullYear(), 0, 4));
  const fd = (ft.getUTCDay() + 6) % 7;
  ft.setUTCDate(ft.getUTCDate() - fd + 3);
  return { y: t.getUTCFullYear(), w: 1 + Math.round((t - ft) / 604800000) };
}
const curWeek = () => {
  const p = isoParts(new Date(twDate() + "T00:00:00Z"));
  return p.y + "-W" + String(p.w).padStart(2, "0");
};

// ══════════════════════════════════════════════════════════════
//  把品名拆成欄位
//
//  賣家在【】裡、天數寫「N天／N日」、流量寫「NGB」或「吃到飽」、
//  電信商就是那幾個名字 —— 這些照字面抓得到。
//  抓不到的（「原生卡」是什麼意思、「多電信」算哪一家）就留空，不硬猜。
// ══════════════════════════════════════════════════════════════

const CARRIERS = [
  ["KDDI", /\bKDDI\b/i], ["docomo", /docomo/i],
  ["SoftBank", /soft\s?bank|軟銀/i], ["樂天", /樂天|rakuten/i],
  ["SKT", /\bSKT\b|SK電訊|SK\s?Telecom/i], ["KT", /\bKT\b(?!\w)/],
  ["LG U+", /LG\s?U\+?/i], ["中華電信", /中華電信/],
  ["台灣大哥大", /台灣大哥大|台哥大/], ["遠傳", /遠傳/],
];

function parseName(name) {
  const out = { seller: null, carrier: null, days: null, gb: null, unlimited: 0, no_throttle: 0 };
  const m1 = name.match(/【([^】]{1,16})】/);
  if (m1) out.seller = m1[1].trim();
  const m2 = name.match(/(\d{1,3})\s*[天日]/);   // 「5天」和「5日」都要吃
  if (m2) out.days = parseInt(m2[1], 10);
  const m3 = name.match(/(\d{1,4})\s*GB/i);
  if (m3) out.gb = parseInt(m3[1], 10);
  if (/吃到飽|無限流量|不限流量|無限上網/.test(name)) out.unlimited = 1;
  if (/不降速/.test(name)) out.no_throttle = 1;
  for (const [label, re] of CARRIERS) if (re.test(name)) { out.carrier = label; break; }
  return out;
}

// ══════════════════════════════════════════════════════════════
//  三個來源
// ══════════════════════════════════════════════════════════════

// ── momo ──
// robots.txt 明文 `Disallow: /api/*`，所以內部 API 那條路不能走。
// 正門在搜尋頁 —— 頁面原始碼裡本來就有 schema.org 的商品資料。
async function fetchMomo(query) {
  const res = await fetch(
    "https://www.momoshop.com.tw/search/searchShop.jsp?keyword=" + encodeURIComponent(query),
    { headers: HDRS });
  if (!res.ok) throw new Error("momo HTTP " + res.status);
  const html = await res.text();
  const rows = [];
  const re = /"name"\s*:\s*"([^"]{8,110})"([\s\S]{0,900}?)"price"\s*:\s*(\d+)/g;
  let m;
  while ((m = re.exec(html)) !== null && rows.length < LIMIT_PER_PLATFORM) {
    const name = m[1].trim();
    if (name === "Breadcrumb" || name === "momo購物網") continue;
    const blk = m[2];
    const img = (blk.match(/"image"\s*:\s*"([^"]+)"/) || [])[1] || null;
    const u = (blk.match(/"url"\s*:\s*"\s*(https?:\/\/[^"]+)"/) || [])[1] || null;
    rows.push({ platform: "momo", product_name: name, price: parseInt(m[3], 10),
      list_price: null, brand: null, url_id: null, image: img, url: u ? u.trim() : null });
  }
  return rows;
}

// ⭐ 這裡可以有第二個搜尋來源 ——
//    課堂練習：加 PChome。照 fetchMomo 的樣子寫一個 fetchPChome、
//    回傳同樣的欄位，再到下面的「平台登記處」登記一行。
//    PChome 的 API 契約（網址、欄位對應）寫在 DEPLOY.md「加第二個搜尋來源」段。

// ── STUDIO A（我們自己）──
// ⚠️ 價格寫成「NT$ 309」不是「$309」—— 第一次找錯格式，判成「抓不到」，是錯的。
//    品名在「〉」後面（eSIM 分類）；主機分類沒有「〉」，用第二種寫法接。
async function fetchStudioA(path) {
  const res = await fetch("https://www.studioa.com.tw" + path, { headers: HDRS });
  if (!res.ok) throw new Error("STUDIO A HTTP " + res.status);
  const html = await res.text();
  const rows = [];
  const seen = new Set();

  // ⚠️ 順序是「連結 → 品名 → 價格」（實測過），不是品名在前
  for (const m of html.matchAll(/href="(\/products\/[a-z0-9]+)[^"]*"[\s\S]{0,400}?〉([^<"&]{4,70})[\s\S]{0,900}?NT\$\s?([0-9,]{3,9})/g)) {
    const name = m[2].trim();
    if (seen.has(name)) continue;
    seen.add(name);
    rows.push({ platform: "studioa", product_name: name,
      price: parseInt(m[3].replace(/,/g, ""), 10),
      list_price: null, brand: null, url_id: null, image: null,
      url: "https://www.studioa.com.tw" + m[1] });
    if (rows.length >= LIMIT_PER_PLATFORM) break;
  }
  if (rows.length) return rows;

  // 主機分類（iPhone / Mac）：沒有「〉」，抓型號 + 五位數價格
  for (const m of html.matchAll(/([iIM][A-Za-z][^<"&]{4,50}?(?:GB|吋|Pro|Max|Air|mini))[\s\S]{0,700}?NT\$\s?([0-9]{2},[0-9]{3})/g)) {
    const name = m[1].trim();
    const price = parseInt(m[2].replace(/,/g, ""), 10);
    if (seen.has(name + price)) continue;
    seen.add(name + price);
    rows.push({ platform: "studioa", product_name: name, price,
      list_price: null, brand: null, url_id: null, image: null,
      url: "https://www.studioa.com.tw" + path });
    if (rows.length >= LIMIT_PER_PLATFORM) break;
  }
  return rows;
}

// ══════════════════════════════════════════════════════════════
//  ⭐ 平台登記處 —— 板子認得哪些平台，全看這張表
//
//  加一個新的搜尋來源，只要三步：
//    1. 上面寫一個抓取函式（照 fetchMomo 的樣子，回傳同樣欄位）
//    2. 在這裡登記一行：{ key, label, kind: "search", fetch: 你的函式 }
//    3. npx wrangler deploy
//  頁面會自動長出新的一欄 —— 前端是照這張表畫的，不用另外改。
// ══════════════════════════════════════════════════════════════

const PLATFORMS = [
  { key: "studioa", label: "STUDIO A", kind: "own" },                 // 我們自己（抓分類頁）
  { key: "momo",    label: "momo",     kind: "search", fetch: fetchMomo },
  // { key: "pchome", label: "PChome", kind: "search", fetch: fetchPChome },  ← 課堂練習加在這
];

// ══════════════════════════════════════════════════════════════
//  資料庫
// ══════════════════════════════════════════════════════════════

export class CompetitorBoardDO {
  constructor(ctx) {
    this.sql = ctx.storage.sql;
    ctx.blockConcurrencyWhile(async () => {
      // 表結構改版時直接重建 —— 資料每週會重抓，不用做搬遷。
      //
      // ⚠️ 這裡不看「版本號」，直接看欄位在不在。
      //    版本號會說謊：舊表還在、版本號卻已經被寫成新的，之後就永遠修不回來。
      //    問資料庫「你現在有哪些欄位」才是事實。
      const cols = this.sql.exec("SELECT name FROM pragma_table_info('snapshots')")
        .toArray().map((r) => r.name);
      if (cols.length && !cols.includes("url")) this.sql.exec("DROP TABLE IF EXISTS snapshots");

      // ⭐ 這張表就是「欄位契約」——
      //    三家給的東西不一樣多，但存進來一律照這個格式。
      //    金額去掉 $ 和逗號存純數字；沒有的欄位存 NULL，不要填 0。
      this.sql.exec(`
        CREATE TABLE IF NOT EXISTS snapshots(
          id           INTEGER PRIMARY KEY AUTOINCREMENT,
          week         TEXT    NOT NULL,   -- 2026-W35
          source       TEXT    NOT NULL,   -- 抓的時候用的搜尋詞／頁面
          platform     TEXT    NOT NULL,   -- studioa / momo / pchome
          product_name TEXT    NOT NULL,   -- 原始品名，一字不動留著
          price        INTEGER,
          list_price   INTEGER,            -- 原價（只有 PChome 有 → 其他 NULL）
          brand        TEXT,
          url_id       TEXT,
          image        TEXT,               -- 商品圖（STUDIO A 沒有 → NULL）
          url         TEXT,               -- ⭐ 商品頁網址 —— 點得進去才查得證
          seller       TEXT,               -- 【】裡的賣家
          carrier      TEXT,               -- 電信商
          days         INTEGER,
          gb           INTEGER,
          unlimited    INTEGER,
          no_throttle  INTEGER,
          captured_at  TEXT    NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_week ON snapshots(week);
        CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      `);
      this.putKV("schema_version", SCHEMA_VERSION);
      if (!this.getKV("products")) this.putKV("products", DEFAULT_PRODUCTS);
      if (!this.getKV("excludes")) this.putKV("excludes", DEFAULT_EXCLUDES);
    });
  }

  getKV(key) {
    const r = this.sql.exec("SELECT value FROM kv WHERE key=?", key).toArray();
    return r.length ? JSON.parse(r[0].value) : null;
  }
  putKV(key, value) {
    this.sql.exec(
      "INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
      key, JSON.stringify(value));
  }

  // 要抓哪些東西 —— 從產品清單自動導出，同一個搜尋詞只抓一次
  jobs() {
    const products = this.getKV("products") || [];
    const map = new Map();
    for (const p of products) {
      if (p.query) map.set("q:" + p.query, { kind: "search", source: p.query });
      if (p.sa_page) map.set("s:" + p.sa_page, { kind: "studioa", source: p.sa_page });
    }
    return [...map.values()];
  }

  async runOnce() {
    const week = curWeek(), stamp = twStamp();
    const report = { week, at: stamp, jobs: [], total: 0, errors: [] };

    for (const job of this.jobs()) {
      const fns = job.kind === "studioa"
        ? [["studioa", () => fetchStudioA(job.source)]]
        : PLATFORMS.filter((p) => p.kind === "search")
            .map((p) => [p.key, () => p.fetch(job.source)]);

      for (const [pf, fn] of fns) {
        try {
          // 網站偶爾回空頁（被暫時擋、或剛好卡住）—— 再試一次就好
          let rows = await fn();
          if (!rows.length) { await new Promise((r) => setTimeout(r, 1200)); rows = await fn(); }

          // ⭐ 抓回 0 筆就不要動資料庫。
          //    寧可頁面顯示舊資料，也不要留一個空的一週。
          if (!rows.length) {
            report.errors.push({ source: job.source, platform: pf,
              error: "回 0 筆（可能被暫時擋）—— 保留上一次的資料，沒有覆蓋" });
            continue;
          }

          this.sql.exec("DELETE FROM snapshots WHERE week=? AND source=? AND platform=?",
            week, job.source, pf);
          for (const r of rows) {
            const p = parseName(r.product_name);
            this.sql.exec(
              `INSERT INTO snapshots(week,source,platform,product_name,price,list_price,brand,url_id,image,url,
                                     seller,carrier,days,gb,unlimited,no_throttle,captured_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
              week, job.source, pf, r.product_name, r.price, r.list_price, r.brand, r.url_id, r.image, r.url,
              p.seller, p.carrier, p.days, p.gb, p.unlimited, p.no_throttle, stamp);
          }
          report.jobs.push({ source: job.source, platform: pf, n: rows.length });
          report.total += rows.length;
        } catch (e) {
          report.errors.push({ source: job.source, platform: pf, error: String(e.message || e) });
        }
      }
    }
    this.putKV("last_run", report);
    return report;
  }

  // ⭐ 產品比對 —— 在「讀」的時候做，不是抓的時候。
  //    改產品定義不用重抓；一次爬「日本 eSIM」可以同時餵 3日/5日/7日 三個產品。
  matches(product, row, excludes) {
    if (excludes.some((w) => row.product_name.includes(w))) return false;

    // ⭐ 第一關：來源要對得上。
    //    沒有這一關，日本 eSIM 頁抓回來的東西會被韓國 eSIM 的產品配走
    //    （兩邊都有「3日」「5日」，光看天數分不出來）。
    if (row.platform === "studioa") {
      if (!product.sa_page || row.source !== product.sa_page) return false;
    } else {
      if (row.source !== product.query) return false;
    }

    // ⚠️ must 只套用在「搜尋來的」（momo／PChome）。
    //    我們自己的頁本身就是產品分類 —— /categories/studioa-japan-esim
    //    整頁都是 KDDI，但商品名只寫「3日 高速原生5G吃到飽」，沒有「KDDI」三個字。
    //    對它再要求 must 含 KDDI，會把自己家的東西全刷掉。
    //    我們自己的頁要另外篩，用 sa_must（沒設就不篩）。
    if (row.platform === "studioa") {
      for (const w of product.sa_must || []) {
        if (!row.product_name.toLowerCase().includes(String(w).toLowerCase())) return false;
      }
    } else {
      for (const w of product.must || []) {
        if (!row.product_name.toLowerCase().includes(String(w).toLowerCase())) return false;
      }
      if (product.unlimited && !row.unlimited) return false;
    }

    if (product.days != null && row.days !== product.days) return false;
    return true;
  }

  async fetch(request) {
    const url = new URL(request.url), path = url.pathname;

    if (path === "/run") return json(await this.runOnce());

    if (path === "/api/health") {
      return json({
        now: twStamp(), current_week: curWeek(),
        products: this.getKV("products"), excludes: this.getKV("excludes"),
        last_run: this.getKV("last_run"),
        weeks_stored: this.sql
          .exec("SELECT week, COUNT(*) n FROM snapshots GROUP BY week ORDER BY week DESC").toArray(),
      });
    }

    for (const [p, key] of [["/api/products", "products"], ["/api/excludes", "excludes"]]) {
      if (path !== p) continue;
      if (request.method === "GET") return json({ [key]: this.getKV(key) });
      if (request.method === "PUT") {
        const body = await request.json().catch(() => ({}));
        let val = body[key];
        if (!Array.isArray(val)) return json({ error: "格式不對" }, 400);
        val = key === "excludes"
          ? val.map((s) => String(s).trim()).filter((s) => s.length >= 2).slice(0, 80)
          : val.slice(0, 30);
        this.putKV(key, val);
        return json({ [key]: val });
      }
    }

    // ⭐ 給頁面用的：一個產品 = 三家的報價排在一起
    if (path === "/api/board") {
      const nWeeks = Math.min(parseInt(url.searchParams.get("weeks") || "8", 10), 52);
      const products = this.getKV("products") || [];
      const excludes = this.getKV("excludes") || [];
      const wk = this.sql.exec("SELECT DISTINCT week FROM snapshots ORDER BY week DESC LIMIT ?", nWeeks)
        .toArray().map((r) => r.week);
      if (!wk.length) return json({ weeks: [],
        platforms: PLATFORMS.map(({ key, label }) => ({ key, label })),
        products, excludes, board: [], last_run: this.getKV("last_run") });

      const marks = wk.map(() => "?").join(",");
      const rows = this.sql.exec(
        `SELECT * FROM snapshots WHERE week IN (${marks}) ORDER BY price`, ...wk).toArray();
      const latest = wk[0];

      const board = products.map((p) => {
        const mine = rows.filter((r) => this.matches(p, r, excludes));
        const byWeek = {};
        for (const r of mine) (byWeek[r.week] ||= []).push(r);

        // 每一週、每一家 → 取最便宜的那一筆
        const history = wk.slice().reverse().map((w) => {
          const wr = byWeek[w] || [];
          const best = {};
          for (const { key: pf } of PLATFORMS) {
            const c = wr.filter((r) => r.platform === pf && r.price != null);
            if (c.length) best[pf] = c.reduce((a, b) => (a.price <= b.price ? a : b));
          }
          return { week: w, best };
        });

        const now = history[history.length - 1]?.best || {};
        const offers = {};
        for (const { key } of PLATFORMS) offers[key] = now[key] || null;
        // 本週比對到的每一筆 —— 「本週 N 筆」點開就要看得到 N 筆，
        // 不是只有每平台最便宜的那筆（rows 已按價格排序）
        const latestRows = (byWeek[latest] || []).slice(0, 30).map((r) => ({
          platform: r.platform, seller: r.seller, product_name: r.product_name,
          price: r.price, list_price: r.list_price, url: r.url,
        }));
        return {
          ...p,
          offers,
          latest_rows: latestRows,
          matched: (byWeek[latest] || []).length,
          history: history.map((h) => {
            const row = { week: h.week };
            for (const { key } of PLATFORMS) row[key] = h.best[key]?.price ?? null;
            return row;
          }),
        };
      });

      return json({ weeks: wk.slice().reverse(),
        platforms: PLATFORMS.map(({ key, label }) => ({ key, label })),
        products, excludes, board, last_run: this.getKV("last_run") });
    }

    // 原始資料（除錯用 / 想自己算的人用）
    if (path === "/api/snapshots") {
      const nWeeks = Math.min(parseInt(url.searchParams.get("weeks") || "8", 10), 52);
      const wk = this.sql.exec("SELECT DISTINCT week FROM snapshots ORDER BY week DESC LIMIT ?", nWeeks)
        .toArray().map((r) => r.week);
      if (!wk.length) return json({ weeks: [], rows: [] });
      const marks = wk.map(() => "?").join(",");
      const rows = this.sql.exec(
        `SELECT * FROM snapshots WHERE week IN (${marks}) ORDER BY week DESC, source, platform, price`,
        ...wk).toArray();
      return json({ weeks: wk.slice().reverse(), rows, excludes: this.getKV("excludes") });
    }

    return json({ error: "route not supported" }, 404);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/") && url.pathname !== "/run") {
      return env.ASSETS.fetch(request);
    }
    return env.BOARD_DO.get(env.BOARD_DO.idFromName("board")).fetch(request);
  },

  // 每週一自動跑（時間設在 wrangler.toml 的 crons）
  // ⚠️ 這裡要 await，不能用 ctx.waitUntil —— scheduled 沒有要回傳的東西，
  //    用 waitUntil 會在抓完之前就結束。
  async scheduled(event, env, ctx) {
    await env.BOARD_DO.get(env.BOARD_DO.idFromName("board")).fetch("https://internal/run");
  },
};
