import * as React from 'react';

export interface TableColumn {
  key: string;
  label: string;
  align?: 'left' | 'right' | 'center';
  /** Right-align, tabular figures, and enable red anomaly flagging. */
  numeric?: boolean;
}

export interface TableRow {
  [key: string]: React.ReactNode;
  /** Flag this row's numeric cells in warning red. */
  _warn?: boolean;
}

/**
 * Report table props.
 * @startingPoint section="Data" subtitle="Clean report table" viewport="640x260"
 */
export interface TableProps {
  columns: TableColumn[];
  rows: TableRow[];
}

/**
 * Clean report table with hairline horizontal rules.
 * @startingPoint section="Data" subtitle="Clean report table" viewport="640x260"
 */
export function Table(props: TableProps): JSX.Element;
