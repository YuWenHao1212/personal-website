**Stat** — the enlarged key number with a one-line grey caption; STUDIO A's signature "one big figure per page" device.

```jsx
<Stat value="18%" delta="+4pt" label="iPhone 換購成長 YoY" highlight size="xl" />
```

`highlight` colours the value STUDIO A blue (use once per page). `delta` auto-colours red when it starts with `-`. Sizes: `md` / `lg` / `xl`.
