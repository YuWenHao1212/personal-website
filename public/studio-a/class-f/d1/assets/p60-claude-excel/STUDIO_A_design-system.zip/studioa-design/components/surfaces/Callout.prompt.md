**Callout** — a low-key note strip on the grey face with a thin left accent bar; use `warn` (red) only for genuine report anomalies.

```jsx
<Callout tone="info" title="註">數字為未稽核初值。</Callout>
<Callout tone="warn">Q2 門市達標率低於目標。</Callout>
```

`tone`: `info` (blue) / `warn` (red). Optional `title`. No fills or gradients — keep it restrained.
