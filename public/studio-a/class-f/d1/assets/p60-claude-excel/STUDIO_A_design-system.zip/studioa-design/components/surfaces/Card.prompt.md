**Card** — a soft 14px-cornered surface with a hairline border and almost no shadow; the STUDIO A signature container.

```jsx
<Card tone="sunken">
  <h3>本季重點</h3>
  <p>iPhone 換購成長 18%。</p>
</Card>
```

`tone`: `plain` (white) or `sunken` (Apple grey `#F5F5F7`). `bordered` toggles the hairline. Keep content airy — whitespace first.
