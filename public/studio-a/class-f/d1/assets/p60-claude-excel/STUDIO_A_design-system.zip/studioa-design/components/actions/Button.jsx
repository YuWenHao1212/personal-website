import React from 'react';

/**
 * STUDIO A Button — calm, pill-shaped call to action.
 * Primary uses the one-per-page STUDIO A blue; neutral is Apple ink; ghost is quiet.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  as = 'button',
  ...rest
}) {
  const sizes = {
    sm: { padding: '8px 18px', fontSize: 'var(--ds-text-sm)' },
    md: { padding: '12px 26px', fontSize: 'var(--ds-text-base)' },
    lg: { padding: '15px 34px', fontSize: 'var(--ds-text-lg)' },
  };

  const variants = {
    primary: {
      background: 'var(--ds-accent)',
      color: 'var(--ds-on-primary)',
      border: '1px solid transparent',
    },
    neutral: {
      background: 'var(--ds-ink)',
      color: 'var(--ds-on-primary)',
      border: '1px solid transparent',
    },
    outline: {
      background: 'transparent',
      color: 'var(--ds-ink)',
      border: '1px solid var(--ds-line)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--ds-accent)',
      border: '1px solid transparent',
    },
  };

  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 'var(--ds-space-2)',
    fontFamily: 'var(--ds-font-body)',
    fontWeight: 'var(--ds-weight-medium)',
    lineHeight: 1,
    borderRadius: 'var(--ds-radius-pill)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--ds-dur) var(--ds-ease), opacity var(--ds-dur) var(--ds-ease)',
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...variants[variant],
  };

  const Tag = as;
  return (
    <Tag style={style} disabled={as === 'button' ? disabled : undefined} {...rest}>
      {children}
    </Tag>
  );
}
