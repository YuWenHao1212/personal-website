**Badge** — a small pill label for status or category; quiet low-contrast fills.

```jsx
<Badge tone="accent">目標</Badge>
<Badge tone="warn">未達標</Badge>
```

Tones: `neutral` (grey), `accent` (blue tint), `warn` (red tint), `solid` (ink). Keep labels short.
