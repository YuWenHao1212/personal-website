import * as React from 'react';

export interface CalloutProps extends React.HTMLAttributes<HTMLDivElement> {
  /** `info` = STUDIO A blue bar, `warn` = semantic red bar. */
  tone?: 'info' | 'warn';
  title?: string;
  children?: React.ReactNode;
}

/** Quiet accent strip for a single key note. */
export function Callout(props: CalloutProps): JSX.Element;
