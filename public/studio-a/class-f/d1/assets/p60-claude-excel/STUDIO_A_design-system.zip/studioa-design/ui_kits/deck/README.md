# STUDIO A — Report Deck kit

A click-through recreation of a STUDIO A report/presentation deck. This is the primary surface of the design system — the brief is explicitly for reports & 簡報 (decks).

## Files
- `index.html` — interactive deck; ‹ › buttons or ← → keys move between slides. Slide position persists in `localStorage`.
- `Slides.jsx` — the six slide templates, exported to `window`.
- `slide-*.card.html` — one preview card per slide type (Design System tab, group "Slides").

## Slide templates
- **TitleSlide** — cover: wordmark top-left, big title, date kicker, payoff pinned to the baseline.
- **StatSlide** — one oversized figure (STUDIO A blue when `highlight`), grey caption, bottom payoff line.
- **CardGridSlide** — three soft-corner grey cards.
- **TableSlide** — clean report table, hairline rows, anomaly row in warning red.
- **QuoteSlide** — large brand-voice statement.
- **ClosingSlide** — dark ink slide with a blue pill CTA (the only dark slide in the system).

All slides render on a 1280×720 canvas and are styled entirely from the design tokens — reskin by swapping `tokens/`.

## Notes / caveats
- These are template recreations, not a real STUDIO A deck (no source deck was provided). Copy is placeholder Traditional-Chinese sample content.
- No logo file supplied — the wordmark is set in Noto Sans TC 800 as a placeholder.
