import React from 'react';

/**
 * STUDIO A Badge — a small pill label. Neutral by default; semantic tones
 * for report status. Quiet, low-contrast fills.
 */
export function Badge({ children, tone = 'neutral', ...rest }) {
  const tones = {
    neutral: { background: 'var(--ds-surface)', color: 'var(--ds-body)' },
    accent:  { background: 'rgba(45,125,210,0.12)', color: 'var(--ds-accent)' },
    warn:    { background: 'rgba(217,48,37,0.10)', color: 'var(--ds-warn)' },
    solid:   { background: 'var(--ds-ink)', color: 'var(--ds-on-primary)' },
  };
  return (
    <span
      {...rest}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '4px 12px',
        borderRadius: 'var(--ds-radius-pill)',
        fontFamily: 'var(--ds-font-body)',
        fontWeight: 'var(--ds-weight-medium)',
        fontSize: 'var(--ds-text-xs)',
        letterSpacing: 'var(--ds-tracking-caps)',
        lineHeight: 1,
        ...tones[tone],
        ...rest.style,
      }}
    >
      {children}
    </span>
  );
}
