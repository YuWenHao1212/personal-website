import React from 'react';

/**
 * STUDIO A Callout — a quiet accent strip for one key note per page.
 * Left accent bar in blue (info) or red (warn); no fill, no gradient.
 */
export function Callout({ children, tone = 'info', title, ...rest }) {
  const barColor = tone === 'warn' ? 'var(--ds-warn)' : 'var(--ds-accent)';
  return (
    <div
      {...rest}
      style={{
        display: 'flex',
        gap: 'var(--ds-space-4)',
        padding: 'var(--ds-space-4) var(--ds-space-5)',
        background: 'var(--ds-surface)',
        borderRadius: 'var(--ds-radius)',
        fontFamily: 'var(--ds-font-body)',
        ...rest.style,
      }}
    >
      <div style={{ width: 3, borderRadius: 999, background: barColor, flex: '0 0 auto' }} />
      <div>
        {title && (
          <div style={{ fontWeight: 'var(--ds-weight-heading)', color: 'var(--ds-ink)', marginBottom: 2 }}>
            {title}
          </div>
        )}
        <div style={{ color: 'var(--ds-body)', fontSize: 'var(--ds-text-sm)', lineHeight: 'var(--ds-leading-body)' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
