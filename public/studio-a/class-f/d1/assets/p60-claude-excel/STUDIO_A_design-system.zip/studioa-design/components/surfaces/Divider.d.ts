import * as React from 'react';

export interface DividerProps extends React.HTMLAttributes<HTMLDivElement> {
  vertical?: boolean;
}

/** 1px light-grey hairline separator. */
export function Divider(props: DividerProps): JSX.Element;
