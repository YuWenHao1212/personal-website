/* STUDIO A — Slide templates (1280×720 canvas).
   Self-contained: styled via the design tokens. Exported to window for card HTML + the deck index. */

const SLIDE_W = 1280;
const SLIDE_H = 720;

const slide = {
  width: SLIDE_W,
  height: SLIDE_H,
  background: 'var(--ds-bg)',
  fontFamily: 'var(--ds-font-body)',
  color: 'var(--ds-body)',
  position: 'relative',
  overflow: 'hidden',
  boxSizing: 'border-box',
};

const corner = {
  position: 'absolute',
  top: 40,
  right: 56,
  fontFamily: 'var(--ds-font-heading)',
  fontWeight: 800,
  fontSize: 15,
  letterSpacing: '0.04em',
  color: 'var(--ds-ink)',
};

const kicker = {
  fontSize: 15,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--ds-muted)',
  fontWeight: 500,
};

/* ---- Cover ---- */
function TitleSlide({
  wordmark = 'STUDIO A',
  title = '2026 Q2 營運回顧',
  subtitle = 'Apple Premium Reseller · 全通路報告',
  date = '2026.07',
}) {
  return (
    <div style={{ ...slide, padding: '96px 120px', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      <div style={{ position: 'absolute', top: 96, left: 120, fontFamily: 'var(--ds-font-heading)', fontWeight: 800, fontSize: 26, letterSpacing: '0.02em', color: 'var(--ds-ink)' }}>
        {wordmark}
      </div>
      <div style={kicker}>{date}</div>
      <h1 style={{ margin: '14px 0 0', fontFamily: 'var(--ds-font-heading)', fontWeight: 800, fontSize: 76, lineHeight: 1.08, letterSpacing: '-0.02em', color: 'var(--ds-ink)' }}>
        {title}
      </h1>
      <p style={{ margin: '20px 0 0', fontSize: 22, color: 'var(--ds-muted)' }}>{subtitle}</p>
    </div>
  );
}

/* ---- Big stat ---- */
function StatSlide({
  kicker: k = '本季關鍵指標',
  value = '18%',
  unitNote = 'iPhone 換購成長 YoY',
  payoff = '換購動能連續三季正成長。',
  highlight = true,
}) {
  return (
    <div style={{ ...slide, padding: '96px 120px', display: 'flex', flexDirection: 'column' }}>
      <div style={corner}>STUDIO A</div>
      <div style={kicker}>{k}</div>
      <div style={{ marginTop: 'auto', marginBottom: 'auto' }}>
        <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 800, fontSize: 220, lineHeight: 1, letterSpacing: '-0.03em', color: highlight ? 'var(--ds-accent)' : 'var(--ds-ink)' }}>
          {value}
        </div>
        <div style={{ marginTop: 18, fontSize: 24, color: 'var(--ds-muted)' }}>{unitNote}</div>
      </div>
      <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 700, fontSize: 30, color: 'var(--ds-ink)', letterSpacing: '-0.01em' }}>
        {payoff}
      </div>
    </div>
  );
}

/* ---- Card grid ---- */
function CardGridSlide({
  title = '三大成長引擎',
  items = [
    { h: '換購方案', b: '舊機估價 + 分期，帶動 iPhone 升級。' },
    { h: '服務體驗', b: 'AppleCare 與到府設定滲透率提升。' },
    { h: '教育專案', b: '校園與企業採購穩定放量。' },
  ],
}) {
  return (
    <div style={{ ...slide, padding: '96px 120px' }}>
      <div style={corner}>STUDIO A</div>
      <h2 style={{ margin: 0, fontFamily: 'var(--ds-font-heading)', fontWeight: 700, fontSize: 46, letterSpacing: '-0.02em', color: 'var(--ds-ink)' }}>
        {title}
      </h2>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${items.length}, 1fr)`, gap: 28, marginTop: 56 }}>
        {items.map((it, i) => (
          <div key={i} style={{ background: 'var(--ds-surface)', border: '1px solid var(--ds-line)', borderRadius: 14, padding: 32, minHeight: 220 }}>
            <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 700, fontSize: 26, color: 'var(--ds-ink)' }}>{it.h}</div>
            <p style={{ margin: '14px 0 0', fontSize: 19, lineHeight: 1.55, color: 'var(--ds-body)' }}>{it.b}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---- Table / report ---- */
function TableSlide({
  title = '門市營收',
  columns = [
    { key: 'store', label: '門市' },
    { key: 'rev', label: '營收', numeric: true },
    { key: 'yoy', label: 'YoY', numeric: true },
  ],
  rows = [
    { store: '信義 A13', rev: 'NT$42M', yoy: '+12%' },
    { store: '台北 101', rev: 'NT$31M', yoy: '+6%' },
    { store: '高雄夢時代', rev: 'NT$27M', yoy: '+9%' },
    { store: '台中', rev: 'NT$18M', yoy: '-4%', _warn: true },
  ],
}) {
  const cell = { padding: '18px 22px', fontSize: 21, textAlign: 'left' };
  return (
    <div style={{ ...slide, padding: '96px 120px' }}>
      <div style={corner}>STUDIO A</div>
      <h2 style={{ margin: '0 0 40px', fontFamily: 'var(--ds-font-heading)', fontWeight: 700, fontSize: 46, letterSpacing: '-0.02em', color: 'var(--ds-ink)' }}>
        {title}
      </h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--ds-line)' }}>
            {columns.map((c) => (
              <th key={c.key} style={{ ...cell, textAlign: c.numeric ? 'right' : 'left', color: 'var(--ds-muted)', fontWeight: 500, fontSize: 15, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} style={{ borderBottom: '1px solid var(--ds-line)' }}>
              {columns.map((c) => (
                <td key={c.key} style={{ ...cell, textAlign: c.numeric ? 'right' : 'left', fontVariantNumeric: c.numeric ? 'tabular-nums' : 'normal', color: r._warn && c.numeric ? 'var(--ds-warn)' : 'var(--ds-body)', fontWeight: c.numeric ? 500 : 400 }}>{r[c.key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---- Big quote ---- */
function QuoteSlide({
  quote = '把每一次購機，做成一次 Apple 直營店等級的體驗。',
  attribution = 'STUDIO A · 品牌主張',
}) {
  return (
    <div style={{ ...slide, padding: '120px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <div style={corner}>STUDIO A</div>
      <blockquote style={{ margin: 0, fontFamily: 'var(--ds-font-heading)', fontWeight: 700, fontSize: 52, lineHeight: 1.3, letterSpacing: '-0.02em', color: 'var(--ds-ink)' }}>
        {quote}
      </blockquote>
      <div style={{ marginTop: 40, fontSize: 20, color: 'var(--ds-muted)' }}>{attribution}</div>
    </div>
  );
}

/* ---- Closing ---- */
function ClosingSlide({ line = '謝謝聆聽', sub = 'STUDIO A · 2026', cta = '查看完整報告' }) {
  return (
    <div style={{ ...slide, background: 'var(--ds-ink)', padding: '120px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <div style={{ position: 'absolute', top: 40, right: 56, fontFamily: 'var(--ds-font-heading)', fontWeight: 800, fontSize: 15, letterSpacing: '0.04em', color: 'var(--ds-on-primary)' }}>STUDIO A</div>
      <h1 style={{ margin: 0, fontFamily: 'var(--ds-font-heading)', fontWeight: 800, fontSize: 88, letterSpacing: '-0.02em', color: 'var(--ds-on-primary)' }}>{line}</h1>
      <div style={{ marginTop: 18, fontSize: 22, color: 'rgba(255,255,255,0.6)' }}>{sub}</div>
      <div style={{ marginTop: 44 }}>
        <span style={{ display: 'inline-flex', padding: '14px 30px', borderRadius: 999, background: 'var(--ds-accent)', color: '#fff', fontWeight: 500, fontSize: 18 }}>{cta}</span>
      </div>
    </div>
  );
}

Object.assign(window, { TitleSlide, StatSlide, CardGridSlide, TableSlide, QuoteSlide, ClosingSlide, SLIDE_W, SLIDE_H });
