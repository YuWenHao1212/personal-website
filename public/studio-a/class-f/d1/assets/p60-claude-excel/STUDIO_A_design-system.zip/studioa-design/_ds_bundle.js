/* @ds-bundle: {"format":3,"namespace":"STUDIOADesignSystem_9765db","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"Stat","sourcePath":"components/data/Stat.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Callout","sourcePath":"components/surfaces/Callout.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"Divider","sourcePath":"components/surfaces/Divider.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"2ecdd4a5e8a1","components/data/Badge.jsx":"46f1ed827c27","components/data/Stat.jsx":"f91c4446ab9d","components/data/Table.jsx":"f855b04cd88d","components/surfaces/Callout.jsx":"58bbba8b0710","components/surfaces/Card.jsx":"833d2b0d5a05","components/surfaces/Divider.jsx":"c1568d527804","ui_kits/deck/Slides.jsx":"65ae4926cef5"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.STUDIOADesignSystem_9765db = window.STUDIOADesignSystem_9765db || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STUDIO A Button — calm, pill-shaped call to action.
 * Primary uses the one-per-page STUDIO A blue; neutral is Apple ink; ghost is quiet.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  as = 'button',
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 18px',
      fontSize: 'var(--ds-text-sm)'
    },
    md: {
      padding: '12px 26px',
      fontSize: 'var(--ds-text-base)'
    },
    lg: {
      padding: '15px 34px',
      fontSize: 'var(--ds-text-lg)'
    }
  };
  const variants = {
    primary: {
      background: 'var(--ds-accent)',
      color: 'var(--ds-on-primary)',
      border: '1px solid transparent'
    },
    neutral: {
      background: 'var(--ds-ink)',
      color: 'var(--ds-on-primary)',
      border: '1px solid transparent'
    },
    outline: {
      background: 'transparent',
      color: 'var(--ds-ink)',
      border: '1px solid var(--ds-line)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--ds-accent)',
      border: '1px solid transparent'
    }
  };
  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 'var(--ds-space-2)',
    fontFamily: 'var(--ds-font-body)',
    fontWeight: 'var(--ds-weight-medium)',
    lineHeight: 1,
    borderRadius: 'var(--ds-radius-pill)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--ds-dur) var(--ds-ease), opacity var(--ds-dur) var(--ds-ease)',
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...variants[variant]
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: style,
    disabled: as === 'button' ? disabled : undefined
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STUDIO A Badge — a small pill label. Neutral by default; semantic tones
 * for report status. Quiet, low-contrast fills.
 */
function Badge({
  children,
  tone = 'neutral',
  ...rest
}) {
  const tones = {
    neutral: {
      background: 'var(--ds-surface)',
      color: 'var(--ds-body)'
    },
    accent: {
      background: 'rgba(45,125,210,0.12)',
      color: 'var(--ds-accent)'
    },
    warn: {
      background: 'rgba(217,48,37,0.10)',
      color: 'var(--ds-warn)'
    },
    solid: {
      background: 'var(--ds-ink)',
      color: 'var(--ds-on-primary)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '4px 12px',
      borderRadius: 'var(--ds-radius-pill)',
      fontFamily: 'var(--ds-font-body)',
      fontWeight: 'var(--ds-weight-medium)',
      fontSize: 'var(--ds-text-xs)',
      letterSpacing: 'var(--ds-tracking-caps)',
      lineHeight: 1,
      ...tones[tone],
      ...rest.style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/Stat.jsx
try { (() => {
/**
 * STUDIO A Stat — the giant number with a one-line grey caption.
 * `highlight` renders the value in STUDIO A blue (use once per page).
 */
function Stat({
  value,
  label,
  delta,
  highlight = false,
  size = 'lg'
}) {
  const valueSizes = {
    md: '64px',
    lg: '96px',
    xl: 'var(--ds-size-stat)'
  };
  const deltaColor = delta && delta.trim().startsWith('-') ? 'var(--ds-warn)' : 'var(--ds-accent)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--ds-space-3)',
      color: highlight ? 'var(--ds-accent)' : 'var(--ds-ink)',
      fontWeight: 'var(--ds-weight-display)',
      fontSize: valueSizes[size],
      lineHeight: 'var(--ds-leading-tight)',
      letterSpacing: 'var(--ds-tracking-tight)'
    }
  }, value, delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.24em',
      fontWeight: 'var(--ds-weight-medium)',
      color: deltaColor
    }
  }, delta)), label && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--ds-space-2)',
      color: 'var(--ds-muted)',
      fontFamily: 'var(--ds-font-body)',
      fontWeight: 'var(--ds-weight-body)',
      fontSize: 'var(--ds-text-base)'
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Stat.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
/**
 * STUDIO A Table — clean white report table with light-grey horizontal rules.
 * Pass `columns` (array of {key, label, align, numeric}) and `rows` (array of objects).
 * A row may set `_warn: true` to flag an anomaly (value cells in red).
 */
function Table({
  columns = [],
  rows = []
}) {
  const cellBase = {
    padding: '14px 18px',
    fontFamily: 'var(--ds-font-body)',
    fontSize: 'var(--ds-text-sm)',
    textAlign: 'left'
  };
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      background: 'var(--ds-bg)',
      color: 'var(--ds-body)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderBottom: '1px solid var(--ds-line)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      ...cellBase,
      textAlign: c.align || (c.numeric ? 'right' : 'left'),
      color: 'var(--ds-muted)',
      fontWeight: 'var(--ds-weight-medium)',
      fontSize: 'var(--ds-text-xs)',
      letterSpacing: 'var(--ds-tracking-caps)',
      textTransform: 'uppercase'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderBottom: '1px solid var(--ds-line)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      ...cellBase,
      textAlign: c.align || (c.numeric ? 'right' : 'left'),
      color: row._warn && c.numeric ? 'var(--ds-warn)' : 'var(--ds-body)',
      fontVariantNumeric: c.numeric ? 'tabular-nums' : 'normal',
      fontWeight: c.numeric ? 'var(--ds-weight-medium)' : 'var(--ds-weight-body)'
    }
  }, row[c.key]))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STUDIO A Callout — a quiet accent strip for one key note per page.
 * Left accent bar in blue (info) or red (warn); no fill, no gradient.
 */
function Callout({
  children,
  tone = 'info',
  title,
  ...rest
}) {
  const barColor = tone === 'warn' ? 'var(--ds-warn)' : 'var(--ds-accent)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--ds-space-4)',
      padding: 'var(--ds-space-4) var(--ds-space-5)',
      background: 'var(--ds-surface)',
      borderRadius: 'var(--ds-radius)',
      fontFamily: 'var(--ds-font-body)',
      ...rest.style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      borderRadius: 999,
      background: barColor,
      flex: '0 0 auto'
    }
  }), /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--ds-weight-heading)',
      color: 'var(--ds-ink)',
      marginBottom: 2
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--ds-body)',
      fontSize: 'var(--ds-text-sm)',
      lineHeight: 'var(--ds-leading-body)'
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Callout.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STUDIO A Card — soft 14px corners, hairline border, near-zero shadow.
 * `tone="sunken"` uses the Apple grey face; `tone="plain"` is white.
 */
function Card({
  children,
  tone = 'plain',
  bordered = true,
  padding = 'var(--ds-space-6)',
  ...rest
}) {
  const style = {
    background: tone === 'sunken' ? 'var(--ds-surface)' : 'var(--ds-bg)',
    border: bordered ? '1px solid var(--ds-line)' : '1px solid transparent',
    borderRadius: 'var(--ds-radius-card)',
    boxShadow: 'var(--ds-shadow-card)',
    padding,
    color: 'var(--ds-body)',
    fontFamily: 'var(--ds-font-body)',
    ...rest.style
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: style
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STUDIO A Divider — a 1px light-grey hairline. The only separator the brand uses.
 */
function Divider({
  vertical = false,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator"
  }, rest, {
    style: {
      background: 'var(--ds-line)',
      ...(vertical ? {
        width: 'var(--ds-rule)',
        alignSelf: 'stretch',
        minHeight: '1em'
      } : {
        height: 'var(--ds-rule)',
        width: '100%'
      }),
      ...rest.style
    }
  }));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Divider.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deck/Slides.jsx
try { (() => {
/* STUDIO A — Slide templates (1280×720 canvas).
   Self-contained: styled via the design tokens. Exported to window for card HTML + the deck index. */

const SLIDE_W = 1280;
const SLIDE_H = 720;
const slide = {
  width: SLIDE_W,
  height: SLIDE_H,
  background: 'var(--ds-bg)',
  fontFamily: 'var(--ds-font-body)',
  color: 'var(--ds-body)',
  position: 'relative',
  overflow: 'hidden',
  boxSizing: 'border-box'
};
const corner = {
  position: 'absolute',
  top: 40,
  right: 56,
  fontFamily: 'var(--ds-font-heading)',
  fontWeight: 800,
  fontSize: 15,
  letterSpacing: '0.04em',
  color: 'var(--ds-ink)'
};
const kicker = {
  fontSize: 15,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--ds-muted)',
  fontWeight: 500
};

/* ---- Cover ---- */
function TitleSlide({
  wordmark = 'STUDIO A',
  title = '2026 Q2 營運回顧',
  subtitle = 'Apple Premium Reseller · 全通路報告',
  date = '2026.07'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      padding: '96px 120px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 96,
      left: 120,
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 800,
      fontSize: 26,
      letterSpacing: '0.02em',
      color: 'var(--ds-ink)'
    }
  }, wordmark), /*#__PURE__*/React.createElement("div", {
    style: kicker
  }, date), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '14px 0 0',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 800,
      fontSize: 76,
      lineHeight: 1.08,
      letterSpacing: '-0.02em',
      color: 'var(--ds-ink)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '20px 0 0',
      fontSize: 22,
      color: 'var(--ds-muted)'
    }
  }, subtitle));
}

/* ---- Big stat ---- */
function StatSlide({
  kicker: k = '本季關鍵指標',
  value = '18%',
  unitNote = 'iPhone 換購成長 YoY',
  payoff = '換購動能連續三季正成長。',
  highlight = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      padding: '96px 120px',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: corner
  }, "STUDIO A"), /*#__PURE__*/React.createElement("div", {
    style: kicker
  }, k), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      marginBottom: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 800,
      fontSize: 220,
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color: highlight ? 'var(--ds-accent)' : 'var(--ds-ink)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      fontSize: 24,
      color: 'var(--ds-muted)'
    }
  }, unitNote)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 30,
      color: 'var(--ds-ink)',
      letterSpacing: '-0.01em'
    }
  }, payoff));
}

/* ---- Card grid ---- */
function CardGridSlide({
  title = '三大成長引擎',
  items = [{
    h: '換購方案',
    b: '舊機估價 + 分期，帶動 iPhone 升級。'
  }, {
    h: '服務體驗',
    b: 'AppleCare 與到府設定滲透率提升。'
  }, {
    h: '教育專案',
    b: '校園與企業採購穩定放量。'
  }]
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      padding: '96px 120px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: corner
  }, "STUDIO A"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '-0.02em',
      color: 'var(--ds-ink)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${items.length}, 1fr)`,
      gap: 28,
      marginTop: 56
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--ds-surface)',
      border: '1px solid var(--ds-line)',
      borderRadius: 14,
      padding: 32,
      minHeight: 220
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 26,
      color: 'var(--ds-ink)'
    }
  }, it.h), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '14px 0 0',
      fontSize: 19,
      lineHeight: 1.55,
      color: 'var(--ds-body)'
    }
  }, it.b)))));
}

/* ---- Table / report ---- */
function TableSlide({
  title = '門市營收',
  columns = [{
    key: 'store',
    label: '門市'
  }, {
    key: 'rev',
    label: '營收',
    numeric: true
  }, {
    key: 'yoy',
    label: 'YoY',
    numeric: true
  }],
  rows = [{
    store: '信義 A13',
    rev: 'NT$42M',
    yoy: '+12%'
  }, {
    store: '台北 101',
    rev: 'NT$31M',
    yoy: '+6%'
  }, {
    store: '高雄夢時代',
    rev: 'NT$27M',
    yoy: '+9%'
  }, {
    store: '台中',
    rev: 'NT$18M',
    yoy: '-4%',
    _warn: true
  }]
}) {
  const cell = {
    padding: '18px 22px',
    fontSize: 21,
    textAlign: 'left'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      padding: '96px 120px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: corner
  }, "STUDIO A"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 40px',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '-0.02em',
      color: 'var(--ds-ink)'
    }
  }, title), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderBottom: '1px solid var(--ds-line)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      ...cell,
      textAlign: c.numeric ? 'right' : 'left',
      color: 'var(--ds-muted)',
      fontWeight: 500,
      fontSize: 15,
      letterSpacing: '0.06em',
      textTransform: 'uppercase'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderBottom: '1px solid var(--ds-line)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      ...cell,
      textAlign: c.numeric ? 'right' : 'left',
      fontVariantNumeric: c.numeric ? 'tabular-nums' : 'normal',
      color: r._warn && c.numeric ? 'var(--ds-warn)' : 'var(--ds-body)',
      fontWeight: c.numeric ? 500 : 400
    }
  }, r[c.key])))))));
}

/* ---- Big quote ---- */
function QuoteSlide({
  quote = '把每一次購機，做成一次 Apple 直營店等級的體驗。',
  attribution = 'STUDIO A · 品牌主張'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      padding: '120px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: corner
  }, "STUDIO A"), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 52,
      lineHeight: 1.3,
      letterSpacing: '-0.02em',
      color: 'var(--ds-ink)'
    }
  }, quote), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40,
      fontSize: 20,
      color: 'var(--ds-muted)'
    }
  }, attribution));
}

/* ---- Closing ---- */
function ClosingSlide({
  line = '謝謝聆聽',
  sub = 'STUDIO A · 2026',
  cta = '查看完整報告'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...slide,
      background: 'var(--ds-ink)',
      padding: '120px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 40,
      right: 56,
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 800,
      fontSize: 15,
      letterSpacing: '0.04em',
      color: 'var(--ds-on-primary)'
    }
  }, "STUDIO A"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 800,
      fontSize: 88,
      letterSpacing: '-0.02em',
      color: 'var(--ds-on-primary)'
    }
  }, line), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      fontSize: 22,
      color: 'rgba(255,255,255,0.6)'
    }
  }, sub), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 44
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      padding: '14px 30px',
      borderRadius: 999,
      background: 'var(--ds-accent)',
      color: '#fff',
      fontWeight: 500,
      fontSize: 18
    }
  }, cta)));
}
Object.assign(window, {
  TitleSlide,
  StatSlide,
  CardGridSlide,
  TableSlide,
  QuoteSlide,
  ClosingSlide,
  SLIDE_W,
  SLIDE_H
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deck/Slides.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Divider = __ds_scope.Divider;

})();
