---
name: studioa-design
description: Use this skill to generate well-branded interfaces and assets for STUDIO A (Apple Premium Reseller), either for production or throwaway prototypes/mocks/reports/decks. Contains essential design guidelines, colors, type, fonts, tokens, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick orientation:
- `styles.css` — link this one file to inherit all tokens (`tokens/*.css`) and the Noto Sans TC webfont.
- Identity: white, black, big whitespace, one touch of STUDIO A blue (`--ds-accent #2D7DD2`, max once per page). Apple-store minimalism — no gradients, heavy shadows, serif, or sharp corners; cards use 14px soft rounding.
- `components/` — Button, Card, Callout, Divider, Stat, Badge, Table (React; each has a `.prompt.md`).
- `ui_kits/deck/` — report-deck templates and an interactive click-through deck.
- Note the caveats in README.md: brand blue awaits calibration, no logo file (wordmark in type), SF Pro substituted by the system stack.
