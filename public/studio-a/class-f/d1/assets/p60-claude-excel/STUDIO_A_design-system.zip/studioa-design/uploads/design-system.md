# STUDIO A — Design System v1（報告 / 簡報用）

> 品牌：STUDIO A · Apple Premium Reseller · 乾淨極簡、大留白、Apple-store 質感。給 Claude 用 —— 產出的報告 / deck 要像 STUDIO A 自己出的。
> ⚠️ v1 草稿：**品牌藍（`--ds-accent`）請用 STUDIO A 官方 brand guide 的正藍校正**（現值 `#2D7DD2` 是依官網 UI 藍推的）。官網橘/紅是促銷色、非識別主色。logo 檔待補（wordmark「STUDIO A」黑字、A 為特殊字型）。

## 怎麼用
1. **Claude Code（本機、今天的 HTML 報告）**：把這個資料夾放進 vault，CLAUDE.md 指向它 → Claude 產 HTML 報告 / 一頁式輸出時讀 `tokens.css`，自動套 STUDIO A 風格。
2. **Claude Design（claude.ai、之後的 deck）**：claude.ai → Design systems → Create → 拖進 logo + `tokens.css` 當 spec → 生 deck 自動 on-brand（D2 教）。

## 識別一句話
**白、黑、大留白、一點 STUDIO A 藍。** 乾淨、克制、像 Apple 直營店 —— 不花、不重、不廉價。

## 配色
| 角色 | hex | 用法 |
|---|---|---|
| 底 | `#FFFFFF` | 純白，永遠大面積留白（≥40%）|
| 卡面 | `#F5F5F7` | 淺灰區塊（Apple 系灰）|
| 主 / 標題 | `#1D1D1F` | 近黑（Apple ink），標題、wordmark |
| 內文 | `#424245` | 一般內文 |
| 次要 | `#86868B` | 註解、來源、標籤 |
| 線 | `#D2D2D7` | 細分隔線 |
| 強調 | `#2D7DD2` STUDIO A 藍 | **品牌強調色**，一頁最多一處（CTA / 重點數字 / highlight）⚠️ 待官方校正 |
| 警示 | `#D93025` 紅 | 語意色（報表異常 / 未達標）——非品牌色、只在數據需要時 |
| 反白字 | `#FFFFFF` | 深底上的字 |
| 促銷橘 | `#E8531F` | 官網 sale 用、日常報告不用 |

## 字型
標題 **Noto Sans TC 700–800**（CJK）／ Latin 用 `-apple-system`, `"SF Pro"`, `"Helvetica Neue"`；內文 400。**不用 serif、不用圓體。** 乾淨無襯線、對齊 Apple 質感。

## 版面原則
- 一頁一重點，**留白優先**（比一般更鬆）。
- 關鍵數字放大（`--ds-size-stat` 120–150px）、旁邊一行灰註解。
- 標題釘左上；收尾 / payoff 句錨底。
- 分隔用 1px 淺灰線（`#D2D2D7`）；**卡片可帶柔圓角（12–14px）**——這是 STUDIO A 跟 sonice/匯流最大差異：**Apple 系柔圓、不是銳利方角**。
- 陰影極淡或不用；不用漸層、不用裝飾線。

## 元件樣式
- **封面**：黑 wordmark `STUDIO A` + 標題；白底；大留白；角落細 logo。
- **大數字**：`#1D1D1F` 巨大數字 + 一行灰註解；要 highlight 的關鍵值用 STUDIO A 藍。
- **卡片**：白 / 淺灰底、`#D2D2D7` 細框、**柔圓角 14px**；不重不花。
- **表格 / 報表**：乾淨白底、淺灰橫線分隔；異常值 / 未達標用**警示紅**標（`--ds-warn`、語意色，非品牌色）。
- **CTA / 重點**：STUDIO A 藍（填色或框線），圓角按鈕。

## Do / Don't
- ✅ 白、黑、大留白、柔圓角、一點 STUDIO A 藍、乾淨無襯線、Apple 質感。
- ❌ 多色、漸層、重陰影、粉色、裝飾線、serif、銳利硬邊、擁擠版面。

---
**v1 · 2026-07-02 · 待校正**：品牌藍正色（`#2D7DD2` 是估的）、logo 檔、字型是否有指定授權字。
