import React from 'react';

/**
 * STUDIO A Card — soft 14px corners, hairline border, near-zero shadow.
 * `tone="sunken"` uses the Apple grey face; `tone="plain"` is white.
 */
export function Card({
  children,
  tone = 'plain',
  bordered = true,
  padding = 'var(--ds-space-6)',
  ...rest
}) {
  const style = {
    background: tone === 'sunken' ? 'var(--ds-surface)' : 'var(--ds-bg)',
    border: bordered ? '1px solid var(--ds-line)' : '1px solid transparent',
    borderRadius: 'var(--ds-radius-card)',
    boxShadow: 'var(--ds-shadow-card)',
    padding,
    color: 'var(--ds-body)',
    fontFamily: 'var(--ds-font-body)',
    ...rest.style,
  };
  return (
    <div {...rest} style={style}>
      {children}
    </div>
  );
}
