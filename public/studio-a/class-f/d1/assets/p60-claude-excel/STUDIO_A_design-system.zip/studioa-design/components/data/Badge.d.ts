import * as React from 'react';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: 'neutral' | 'accent' | 'warn' | 'solid';
  children?: React.ReactNode;
}

/** Small pill label for status / categories. */
export function Badge(props: BadgeProps): JSX.Element;
