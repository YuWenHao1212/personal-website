import * as React from 'react';

/**
 * Stat props.
 * @startingPoint section="Data" subtitle="Oversized key figure" viewport="360x220"
 */
export interface StatProps {
  /** The big number, e.g. "18%" or "NT$2.4B". */
  value: React.ReactNode;
  /** One-line grey caption under the number. */
  label?: string;
  /** Small delta chip, e.g. "+18%" (blue) or "-4%" (red). */
  delta?: string;
  /** Render the value in STUDIO A blue — at most once per page. */
  highlight?: boolean;
  size?: 'md' | 'lg' | 'xl';
}

/**
 * Oversized key figure with a grey caption.
 * @startingPoint section="Data" subtitle="Oversized key figure" viewport="360x220"
 */
export function Stat(props: StatProps): JSX.Element;
