import React from 'react';

/**
 * STUDIO A Divider — a 1px light-grey hairline. The only separator the brand uses.
 */
export function Divider({ vertical = false, ...rest }) {
  return (
    <div
      role="separator"
      {...rest}
      style={{
        background: 'var(--ds-line)',
        ...(vertical
          ? { width: 'var(--ds-rule)', alignSelf: 'stretch', minHeight: '1em' }
          : { height: 'var(--ds-rule)', width: '100%' }),
        ...rest.style,
      }}
    />
  );
}
