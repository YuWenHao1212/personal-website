import * as React from 'react';

/**
 * Card props.
 * @startingPoint section="Surfaces" subtitle="Soft-corner content card" viewport="360x200"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** `plain` = white, `sunken` = Apple grey face. */
  tone?: 'plain' | 'sunken';
  bordered?: boolean;
  padding?: string;
  children?: React.ReactNode;
}

/**
 * Soft-cornered surface with a hairline border.
 * @startingPoint section="Surfaces" subtitle="Soft-corner content card" viewport="360x200"
 */
export function Card(props: CardProps): JSX.Element;
