# STUDIO A — Design System

> **White, black, big whitespace, one touch of STUDIO A blue.** Clean, restrained, Apple-store quality — never busy, heavy, or cheap. Built for reports and presentation decks that look like STUDIO A produced them.

STUDIO A is an Apple Premium Reseller. This system encodes that identity — the Apple-store aesthetic of pure white space, near-black ink, soft-rounded cards, and a single disciplined brand blue — as tokens, components, and a report-deck kit.

## Sources
- `uploads/design-system.md` — brand brief (v1 draft, Traditional Chinese).
- `uploads/tokens.css` — the original token spec (this system extends it, keeping the `--ds-*` names so token files stay swappable with the sibling "sonice" system).
- **No codebase, Figma, or logo file was provided.** Components are authored from the brief, not recreated from source code. See caveats below.

## Index
- `styles.css` — global entry; `@import`s the token + font files. Consumers link this one file.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `shape.css`, `fonts.css`.
- `components/` — reusable React primitives:
  - `actions/` — **Button**
  - `surfaces/` — **Card**, **Callout**, **Divider**
  - `data/` — **Stat**, **Badge**, **Table**
- `ui_kits/deck/` — interactive report-deck kit + six slide templates.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `SKILL.md` — Agent-Skill wrapper for use in Claude Code.

## Components
**Button** · **Card** · **Callout** · **Divider** · **Stat** · **Badge** · **Table**. Each has a `.jsx`, a `.d.ts` props contract, and a `.prompt.md` usage note in its directory.

### Intentional additions
No source defined a component inventory, so a compact standard set was authored, sized to a report/deck brand: **Stat** (the "one big number" device), **Table** (clean report table with red anomaly flagging), **Callout** (single key note), and **Divider** (the 1px hairline the brief calls the only separator). These directly serve the brief's named elements (cover, big number, card, table, CTA).

---

## Content fundamentals
- **Voice:** calm, precise, confident understatement. The identity line is a single declarative sentence, not a slogan with punctuation drama: 「白、黑、大留白，一點 STUDIO A 藍。」
- **Language:** primary copy is Traditional Chinese (Taiwan); Latin terms (iPhone, AppleCare, YoY, CTA) stay in English inline. Product and Apple terms are never translated.
- **Casing:** English uses sentence case, not Title Case. Small labels/captions may be uppercased with wide tracking (`--ds-tracking-caps`).
- **Person:** institutional third-person / imperative ("查看報告", "把每一次購機做成一次體驗"), not chatty "you/we".
- **Numbers:** the hero of most pages. State the figure large and bare, then one grey line of context beneath. Deltas are terse (`+18%`, `-4pt`).
- **Emoji:** none in brand output. (The brief uses ✅/✕/⚠️ only as internal editorial marks in the guide, never in deliverables.)
- **Vibe:** an Apple keynote slide, in Mandarin — one idea per page, lots of air, nothing decorative.

## Visual foundations
- **Colour:** white (`#FFFFFF`) base, always ≥40% whitespace. Apple grey `#F5F5F7` for card faces. Near-black ink `#1D1D1F` for headings, `#424245` body, `#86868B` captions. **STUDIO A blue `#2D7DD2`** is the only brand colour and appears at most once per page (a CTA, a key stat, or one highlight). Warn red `#D93025` is semantic-only (report anomalies / below-target). Promo orange `#E8531F` is web-sale only and never in reports. ⚠️ The blue is an estimate pending official calibration.
- **Type:** Noto Sans TC throughout — 800 for display, 700 headings, 400 body. Latin falls back to the `-apple-system` / SF Pro stack. **No serif, no rounded display faces.** Headings carry −0.02em tracking; body runs at 1.55 line-height.
- **Spacing & layout:** whitespace-first, looser than typical. One point per page. Title pinned top-left; the payoff / closing line anchored to the baseline. Big stats at 120–220px. Generous ~120px slide margins.
- **Backgrounds:** flat white (or flat ink `#1D1D1F` for a single closing slide). **No gradients, no images behind text, no textures, no patterns.** Imagery, when present, would be clean product photography on white — never warm/grainy/duotone.
- **Borders & dividers:** a single 1px `#D2D2D7` hairline. Never heavy or black rules. No colored-left-border accent cards.
- **Corners:** Apple-style soft rounding — 10px general, **14px cards** (the signature that separates STUDIO A from sharp-square peers), pill (999px) for buttons/tags.
- **Elevation:** shadows near-zero. Cards use a barely-there `0 1px 2px rgba(0,0,0,.04)`; a soft lift exists but is used sparingly. No drop-shadow drama.
- **Transparency / blur:** minimal. Reserved for utility chrome (e.g. the deck nav bar's `backdrop-filter`), never on brand content.
- **Motion:** calm and quiet. `cubic-bezier(0.4,0,0.2,1)` easing, 120–200ms. Fades and gentle position shifts only — **no bounce, no spring, no infinite loops.**
- **Hover / press:** hover darkens the fill slightly (blue → `#1F5FA8`) or lowers opacity; disabled drops to ~0.4 opacity. No scale-pop or glow.
- **Cards, summarized:** white or grey face, 1px hairline border, 14px radius, whisper shadow. Restrained and airy — never heavy, never busy.

## Iconography
- **No icon set was provided or found in the sources**, and the Apple-minimal brief calls for very few icons. This system ships **no bundled icon font or SVG set** and does not invent one.
- **Emoji are not used** in brand output. Unicode glyphs are used only as lightweight UI affordances (e.g. `‹` `›` nav chevrons in the deck) — not as content icons.
- **If icons become necessary**, use a thin-stroke, rounded, monochrome set consistent with Apple's SF Symbols feel — the closest CDN substitute is **Lucide** (rounded 1.5–2px stroke). Render in ink or muted grey, never multicolor. This would be a substitution to flag and confirm with the brand.

## Caveats
- **STUDIO A blue `#2D7DD2` is an estimate**, derived from the site UI — needs official brand-guide calibration.
- **No logo file** — the wordmark is set in Noto Sans TC 800 as a placeholder everywhere a mark would go. The brief notes the real "A" uses a custom typeface. Do not reconstruct it.
- **SF Pro** is named in the brief but no licensed binary was provided; it resolves via the local `-apple-system` stack. **Noto Sans TC** is the shipped webfont (Google Fonts). If you have licensed font files, add them and I'll wire `@font-face`.
- Deck/component copy is **placeholder sample content**, not real STUDIO A figures.
