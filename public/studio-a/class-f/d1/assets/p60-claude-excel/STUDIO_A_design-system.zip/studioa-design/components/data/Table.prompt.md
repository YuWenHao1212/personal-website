**Table** — a clean white report table separated by 1px light-grey horizontal rules; no vertical lines, no zebra fills.

```jsx
<Table
  columns={[
    { key: 'store', label: '門市' },
    { key: 'rev', label: '營收', numeric: true },
    { key: 'yoy', label: 'YoY', numeric: true },
  ]}
  rows={[
    { store: '信義 A13', rev: 'NT$42M', yoy: '+12%' },
    { store: '台中', rev: 'NT$18M', yoy: '-4%', _warn: true },
  ]}
/>
```

`numeric` columns right-align with tabular figures. Set `_warn: true` on a row to flag its numeric cells in warning red.
