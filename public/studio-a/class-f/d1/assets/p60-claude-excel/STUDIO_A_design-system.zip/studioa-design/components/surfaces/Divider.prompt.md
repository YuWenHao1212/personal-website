**Divider** — the one separator STUDIO A uses: a 1px `#D2D2D7` hairline, horizontal by default.

```jsx
<Divider />
<Divider vertical />
```

Never use heavy or black rules; the hairline carries all separation.
