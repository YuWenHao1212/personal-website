import * as React from 'react';

/**
 * Pill CTA props.
 * @startingPoint section="Actions" subtitle="Pill call-to-action button" viewport="360x120"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. `primary` = STUDIO A blue (max one per page). */
  variant?: 'primary' | 'neutral' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  /** Render as a different element, e.g. 'a'. */
  as?: 'button' | 'a';
  children?: React.ReactNode;
}

/**
 * Pill CTA in the STUDIO A style.
 * @startingPoint section="Actions" subtitle="Pill call-to-action button" viewport="360x120"
 */
export function Button(props: ButtonProps): JSX.Element;
