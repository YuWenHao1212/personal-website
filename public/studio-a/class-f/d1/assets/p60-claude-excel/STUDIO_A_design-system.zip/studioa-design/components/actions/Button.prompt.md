**Button** — a calm, pill-shaped call to action; use `primary` (STUDIO A blue) at most once per page, `neutral`/`outline` for secondary actions, `ghost` for quiet inline links.

```jsx
<Button variant="primary" size="md">查看報告</Button>
<Button variant="outline">取消</Button>
```

Variants: `primary` (blue fill), `neutral` (ink fill), `outline` (hairline border), `ghost` (blue text). Sizes: `sm` / `md` / `lg`. Supports `as="a"` for links and `disabled`.
