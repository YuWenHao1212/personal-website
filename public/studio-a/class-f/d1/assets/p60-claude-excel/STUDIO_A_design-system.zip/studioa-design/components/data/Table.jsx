import React from 'react';

/**
 * STUDIO A Table — clean white report table with light-grey horizontal rules.
 * Pass `columns` (array of {key, label, align, numeric}) and `rows` (array of objects).
 * A row may set `_warn: true` to flag an anomaly (value cells in red).
 */
export function Table({ columns = [], rows = [] }) {
  const cellBase = {
    padding: '14px 18px',
    fontFamily: 'var(--ds-font-body)',
    fontSize: 'var(--ds-text-sm)',
    textAlign: 'left',
  };
  return (
    <table
      style={{
        width: '100%',
        borderCollapse: 'collapse',
        background: 'var(--ds-bg)',
        color: 'var(--ds-body)',
      }}
    >
      <thead>
        <tr style={{ borderBottom: '1px solid var(--ds-line)' }}>
          {columns.map((c) => (
            <th
              key={c.key}
              style={{
                ...cellBase,
                textAlign: c.align || (c.numeric ? 'right' : 'left'),
                color: 'var(--ds-muted)',
                fontWeight: 'var(--ds-weight-medium)',
                fontSize: 'var(--ds-text-xs)',
                letterSpacing: 'var(--ds-tracking-caps)',
                textTransform: 'uppercase',
              }}
            >
              {c.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, i) => (
          <tr key={i} style={{ borderBottom: '1px solid var(--ds-line)' }}>
            {columns.map((c) => (
              <td
                key={c.key}
                style={{
                  ...cellBase,
                  textAlign: c.align || (c.numeric ? 'right' : 'left'),
                  color: row._warn && c.numeric ? 'var(--ds-warn)' : 'var(--ds-body)',
                  fontVariantNumeric: c.numeric ? 'tabular-nums' : 'normal',
                  fontWeight: c.numeric ? 'var(--ds-weight-medium)' : 'var(--ds-weight-body)',
                }}
              >
                {row[c.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
