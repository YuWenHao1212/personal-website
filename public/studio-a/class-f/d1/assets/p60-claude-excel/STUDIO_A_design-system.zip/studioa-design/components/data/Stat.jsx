import React from 'react';

/**
 * STUDIO A Stat — the giant number with a one-line grey caption.
 * `highlight` renders the value in STUDIO A blue (use once per page).
 */
export function Stat({ value, label, delta, highlight = false, size = 'lg' }) {
  const valueSizes = {
    md: '64px',
    lg: '96px',
    xl: 'var(--ds-size-stat)',
  };
  const deltaColor = delta && delta.trim().startsWith('-') ? 'var(--ds-warn)' : 'var(--ds-accent)';
  return (
    <div style={{ fontFamily: 'var(--ds-font-heading)' }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'baseline',
          gap: 'var(--ds-space-3)',
          color: highlight ? 'var(--ds-accent)' : 'var(--ds-ink)',
          fontWeight: 'var(--ds-weight-display)',
          fontSize: valueSizes[size],
          lineHeight: 'var(--ds-leading-tight)',
          letterSpacing: 'var(--ds-tracking-tight)',
        }}
      >
        {value}
        {delta && (
          <span style={{ fontSize: '0.24em', fontWeight: 'var(--ds-weight-medium)', color: deltaColor }}>
            {delta}
          </span>
        )}
      </div>
      {label && (
        <div
          style={{
            marginTop: 'var(--ds-space-2)',
            color: 'var(--ds-muted)',
            fontFamily: 'var(--ds-font-body)',
            fontWeight: 'var(--ds-weight-body)',
            fontSize: 'var(--ds-text-base)',
          }}
        >
          {label}
        </div>
      )}
    </div>
  );
}
