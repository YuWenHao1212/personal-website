// FLUX Tracking Board API — KV mini-worker（單人教學版）
//
// 儲存：一把 KV key `board:v2`，內容 { meta:{next_id,updated,rev}, issues:[], archive:[] }
// 每次寫入 = 讀整包 → 改 → 寫回（單人使用夠用；無 auth — 網址 = 鑰匙，別公開分享）。
// 樂觀鎖（非破壞式）：寫入 body 可帶 expectedRev；與目前 meta.rev 不符 → 409（未帶 = 照舊接受）。
// ⚠️ KV 無原子 compare-and-swap — expectedRev 大幅縮小互蓋窗口但非 100%，寫入仍應一次一件（見 README）。
// ⚠️ statuses（欄位定義）由下方 STATUSES 常數提供、不存 KV — 改欄名 = 改 code + redeploy 就生效。
//
// Endpoints（形狀照真板，前端可直接沿用）：
//   GET    /api/issues               → { meta, projects:[], statuses, issues }
//   GET    /api/archive              → { issues:[…封存卡] }
//   GET    /api/score[?week=2026-W29]→ { week, pct, done, total, cards, excluded }
//                                      week 省略 = 當前 ISO 週（Asia/Taipei）；掃 issues+archive，
//                                      歸檔不影響歷史週查詢。排除放棄卡、tags 含 bonus、tags 含 seed 的卡。
//   POST   /api/issues               → { fields:{...} } 新卡（配 next_id）
//   PATCH  /api/issues/:id           → { fields:{...} } 通用合併單卡（未知欄位直接收 — schema 保留彈性）
//   POST   /api/issues/:id/comments  → { comment:{text,…} } 加留言
//   POST   /api/issues/:id/archive   → 卡片移到 archive
//   POST   /api/issues/:id/unarchive → archive 移回看板（誤封存 / 還原）
//
// 靜態頁面（GET /）由 Workers Static Assets 出（wrangler.toml [assets]），非 /api/* 不會進到這裡。

const KEY = "board:v2";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-weekly-board": "kv-v2",
    },
  });

// Asia/Taipei 時間（edge 跑 UTC，固定 +8）
const twDate = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
const twStamp = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 19) + "+08:00";

// ---- ISO 週（跨年正確，免季常數）----
function isoParts(d) {
  const t = new Date(d);
  const day = (t.getUTCDay() + 6) % 7; // Mon=0
  t.setUTCDate(t.getUTCDate() - day + 3); // 移到該週四
  const ft = new Date(Date.UTC(t.getUTCFullYear(), 0, 4));
  const fd = (ft.getUTCDay() + 6) % 7;
  ft.setUTCDate(ft.getUTCDate() - fd + 3); // 該年第一個週四
  return { y: t.getUTCFullYear(), w: 1 + Math.round((t - ft) / 604800000) };
}
const isoTagOf = (p) => p.y + "-W" + String(p.w).padStart(2, "0");
const curWeekTag = () => isoTagOf(isoParts(new Date(twDate() + "T00:00:00Z")));

// ---- 欄位定義（SoT = 這裡的 code，不存 KV）----
// 想改欄名：改下面的 name → `npx wrangler deploy` → 重新整理頁面就生效。
// id 是卡片 status 欄位存的值，改 id 要連舊卡資料一起搬，建議只改 name。
const STATUSES = [
  { id: "backlog", name: "Backlog" },
  { id: "todo", name: "Todo" },
  { id: "in-progress", name: "In Progress" },
  { id: "done", name: "Done" },
  { id: "blocked", name: "Blocked" },
];
const emptyBoard = () => ({
  meta: { next_id: 1, updated: twStamp(), rev: 0 },
  issues: [],
  archive: [],
});
async function loadBoard(env) {
  const b = await env.BOARD_KV.get(KEY, { type: "json" });
  if (!b) return emptyBoard();
  b.meta = b.meta || { next_id: 1, rev: 0 };
  if (!Array.isArray(b.issues)) b.issues = [];
  if (!Array.isArray(b.archive)) b.archive = [];
  delete b.statuses; // 舊 blob 若殘留 statuses 一律忽略（欄位定義只認 code）
  return b;
}
async function saveBoard(env, b) {
  b.meta.rev = (b.meta.rev || 0) + 1;
  b.meta.updated = twStamp();
  await env.BOARD_KV.put(KEY, JSON.stringify(b));
  return b.meta.rev;
}
// 樂觀鎖 gate：body 帶 expectedRev 且與目前 rev 不符 → 409 回最新 rev；未帶 → null（照舊放行）
function revGate(b, body) {
  const exp = body ? body.expectedRev : undefined;
  if (exp === undefined || exp === null) return null;
  const cur = (b.meta && b.meta.rev) || 0;
  if (Number(exp) !== cur) {
    return json({ error: "rev conflict", rev: cur, hint: "board changed since your last read — GET /api/issues for the latest meta.rev, then retry with that expectedRev" }, 409);
  }
  return null;
}

// ---- Score（教學版直算）：week 卡 done/total，排除放棄卡、bonus tag、seed tag ----
function scoreForWeek(cards, week) {
  const excluded = [];
  const list = [];
  let done = 0, total = 0;
  for (const i of cards) {
    if (i.week !== week) continue;
    const tags = Array.isArray(i.tags) ? i.tags : i.tags ? [i.tags] : [];
    if (i.resolution) { excluded.push({ id: i.id, why: "dropped" }); continue; }
    if (tags.includes("bonus")) { excluded.push({ id: i.id, why: "bonus 不計分" }); continue; }
    if (tags.includes("seed")) { excluded.push({ id: i.id, why: "seed（未來再說）不計分" }); continue; }
    total++;
    if (i.status === "done") done++;
    list.push({ id: i.id, status: i.status, title: i.title });
  }
  const pct = total === 0 ? null : Math.round((done / total) * 10000) / 100;
  return { week, pct, done, total, cards: list, excluded };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);
    const path = url.pathname;
    const method = request.method;
    const body = method !== "GET" && method !== "HEAD" ? await request.json().catch(() => null) : null;
    const b = await loadBoard(env);

    // GET /api/issues（整包；statuses 來自 code、projects 恆為空陣列 — 分組從 effort 派生）
    if (path === "/api/issues" && method === "GET") {
      return json({ meta: b.meta, projects: [], statuses: STATUSES, issues: b.issues });
    }

    // GET /api/archive
    if (path === "/api/archive" && method === "GET") {
      return json({ issues: b.archive });
    }

    // GET /api/score[?week=2026-W29]（掃 issues+archive；歸檔不影響歷史週查詢）
    if (path === "/api/score" && method === "GET") {
      const week = url.searchParams.get("week") || curWeekTag();
      const ids = new Set(b.issues.map((c) => c.id));
      const arch = b.archive.filter((c) => c.id && !ids.has(c.id)); // 防禦：同 id 以活卡為準
      return json(scoreForWeek(b.issues.concat(arch), week));
    }

    // POST /api/issues（新卡）
    if (path === "/api/issues" && method === "POST") {
      const gate = revGate(b, body);
      if (gate) return gate;
      const n = b.meta.next_id || b.issues.length + 1;
      b.meta.next_id = n + 1;
      const id = "ISS-" + String(n).padStart(3, "0");
      const card = Object.assign(
        {
          id, title: "新 Issue", type: "task", status: STATUSES[0].id,
          priority: "P2", tags: [], body: "", source: "", due: null, week: null, effort: null,
          resolution: null, comments: [], created: twDate(), updated: twDate(),
        },
        (body && body.fields) || {}
      );
      card.id = id; // id 不可被 fields 覆蓋
      b.issues.push(card);
      const rev = await saveBoard(env, b);
      return json({ rev, issue: card }, 201);
    }

    // POST /api/issues/:id/unarchive（archive → 看板；還原）
    const um = path.match(/^\/api\/issues\/([^/]+)\/unarchive$/);
    if (um && method === "POST") {
      const gate = revGate(b, body);
      if (gate) return gate;
      const id = decodeURIComponent(um[1]);
      if (b.issues.some((c) => c.id === id)) return json({ error: "already live: " + id }, 409);
      let idx = -1;
      for (let k = b.archive.length - 1; k >= 0; k--) { if (b.archive[k].id === id) { idx = k; break; } }
      if (idx < 0) return json({ error: "not in archive: " + id }, 404);
      const card = b.archive.splice(idx, 1)[0];
      delete card.archived_at;
      card.updated = twDate();
      b.issues.push(card);
      const rev = await saveBoard(env, b);
      return json({ rev, unarchived: id, issue: card });
    }

    // /api/issues/:id（+ /comments | /archive）
    const m = path.match(/^\/api\/issues\/([^/]+)(\/comments|\/archive)?$/);
    if (m) {
      const id = decodeURIComponent(m[1]);
      const sub = m[2];
      const card = b.issues.find((c) => c.id === id);
      if (!card) return json({ error: "not found: " + id }, 404);

      // PATCH 單卡（通用欄位合併；未知欄位直接收）
      if (!sub && method === "PATCH") {
        const gate = revGate(b, body);
        if (gate) return gate;
        const fields = (body && body.fields) || {};
        delete fields.id;
        Object.assign(card, fields);
        card.updated = twDate();
        const rev = await saveBoard(env, b);
        return json({ rev, issue: card });
      }
      // POST 留言（append）
      if (sub === "/comments" && method === "POST") {
        const gate = revGate(b, body);
        if (gate) return gate;
        const c = (body && body.comment) || null;
        if (!c || !c.text) return json({ error: "comment.text required" }, 400);
        card.comments = Array.isArray(card.comments) ? card.comments : [];
        card.comments.push({ author: c.author || "me", ts: c.ts || twStamp(), text: c.text });
        card.updated = twDate();
        const rev = await saveBoard(env, b);
        return json({ rev, issue: card });
      }
      // POST 封存（看板 → archive）
      if (sub === "/archive" && method === "POST") {
        const gate = revGate(b, body);
        if (gate) return gate;
        card.archived_at = twStamp();
        b.issues = b.issues.filter((c) => c.id !== id);
        b.archive.push(card);
        const rev = await saveBoard(env, b);
        return json({ rev, archived: id });
      }
    }

    return json({ error: "method/route not supported" }, 405);
  },
};
