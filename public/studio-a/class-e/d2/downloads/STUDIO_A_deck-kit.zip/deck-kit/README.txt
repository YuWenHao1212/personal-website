STUDIO A · 離線簡報套件
=======================
把這個資料夾裡的東西，跟 Claude Design 抓回來的簡報放在一起，
就能把簡報轉成「雙擊就開、不用連網」的離線版。

  deck-stage.js  翻頁引擎（原生，不需要 React）
  fonts/         Noto Sans TC 四種字重

怎麼用：不用自己動手，把投影片上那段指令貼給 Claude Code 就好。
