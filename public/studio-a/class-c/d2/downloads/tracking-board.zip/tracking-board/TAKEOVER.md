# FLUX Tracking Board — 接管說明（給 Claude 照做）

> 這份是「把任務管理換成以看板為主」的作業單。使用者在課堂上會貼兩句話：第一段「搬資料」、第二段「改流程」。Claude 照本檔逐步做，**每個會動到使用者資料的步驟都先列出來、問過才動**。
> 部署、API、欄位、寫入安全 → 一律查同資料夾 `DEPLOY.md`（單一出處，本檔不重複）。

## 前提

- 看板已部署上線（照 `DEPLOY.md`）。看板網址 Claude 應該知道；不確定就先問使用者，不要猜。
- vault 已 git init（開工／收工流程都會 commit）。沒有的話先 `git init && git add -A && git commit -m "init: FLUX vault"`。
- 唯讀區不動：`Guides/`、`Templates/`。

## 通則（兩段都適用）

1. 跟看板讀寫**一律用 curl**、寫入前先 `GET /api/issues` 拿 `meta.rev`、每筆寫入帶 `expectedRev`、**一次一件**（規則見 `DEPLOY.md`「寫入安全」）。
2. 動使用者的卡或檔案之前，先把要動的清單列出來、問一句、使用者說好才動。
3. 使用者答不出來的（哪個 effort、要不要合併）→ 留空或不合併，之後在板上都改得了。
4. **絕不跑 `npx wrangler delete`** — 那會把 worker 連資料整個刪掉。清練習卡走下面的「清場」。

---

## 第一段：搬資料

### 0. 清場（練習卡封存）

1. `GET /api/issues`，把板上所有卡列成表格（id、title、status、week、tags）給使用者看，問「哪些是練習卡？」（`DEPLOY.md` 塞的四張 title 都以「練習卡：」開頭，可以先幫使用者標出來）。
2. 對每張練習卡、一次一件：
   - 先 `PATCH /api/issues/:id` 把 `week` 清成空字串 `""`（封存卡掛著 week 還會進本週計分，所以先清）
   - 再 `POST /api/issues/:id/archive` 封存
3. 封存完再 `GET /api/issues` 確認板上沒有練習卡。

### 1. 搬 BACKLOG.md

讀 `Cockpit/BACKLOG.md`：

- 「## 待辦」每一項 → 開一張卡：`status` = `backlog`、`title` = 那一行去掉日期後綴的文字、`body` 第一行寫 `原本在 BACKLOG.md（YYYY-MM-DD added）`（日期取自後綴 — 開工的「躺超過 4 週」提醒會看這行）
- 「## 未來再說」每一項 → 也開卡，`status` = `backlog`、`tags` = `["seed"]`（板上顯示 🌱、不進計分）
- 空的、只有「-」的項目跳過

### 2. 搬 Weekly-Commitment.md

讀 `Cockpit/Weekly-Commitment.md`「## 本週 3-5 件主要任務」：

1. 沒打勾的每一項 → 先問使用者「這幾件哪幾件正在做？」
   - 正在做的：`status` = `in-progress`
   - 其他：`status` = `todo`
   - 全部 `week` 填本週 ISO 週（`TZ='Asia/Taipei' date '+%G-W%V'`）
2. 已打勾的不上板（本週分數還是照原本寫在檔案裡）
3. 搬完把那段標記退役：在「## 本週 3-5 件主要任務」標題正下方加一行

   `> 本週任務改在 Tracking Board，此段不再使用 — 本檔只記每週分數與歷史`

   「本週」meta、「本週分數」、「歷史紀錄」三段**保留**，之後每週 WAM 還是寫在這。

### 3. 掛 effort

每張新開的卡，對照 `Efforts/Areas/` 和 `Efforts/Projects/Active/` 的資料夾名：明顯屬於哪個就把 `effort` 填成那個路徑（例 `Efforts/Projects/Active/月活動表`），看板會照它分組。對不上的留空（會歸到「未歸屬」）；拿不準的列出來問使用者一次，答不出來就留空。

### 4. 查重

兩份清單彼此重複、或跟板上已有的卡重複 → 先列出來問使用者要不要合併。合併就留一張卡、`body` 註記兩個來源。

### 5. 對帳、存檔

`GET /api/issues`，把板上的卡列成表格（id、title、status、week、effort、tags）給使用者對。使用者說 OK 之後 commit；**使用者沒說 OK、直接貼了第二段的指令，也視為 OK** — 先 commit 第一段再開始第二段（不要問）：

```bash
git add -A && git commit -m "Tracking Board 接管：任務搬上板"
```

---

## 第二段：改流程

目標：開工、收工、調整本週、WAM 的**任務來源和分數都改從看板拿**；daily note 照寫；`BACKLOG.md` 退役、`Weekly-Commitment.md` 瘦身成分數簿。

**做法：不重寫流程，只插一個「🟦 板子模式」區塊**，流程本文照舊；跟原流程不同的地方全部寫在同資料夾 `BOARD-MODE.md`，執行時一起讀。這樣不管流程本文長什麼樣（每個人的 skill 文字不同），改法都一樣。

先確認**流程住在哪**（兩種都可能，逐一查）：

| 流程 | 先查 | 有 → | 沒有 → |
|---|---|---|---|
| 開工 | `.claude/skills/daily/SKILL.md` | skill 版：區塊插在 SKILL.md | CLAUDE.md 版：區塊插在 `## 開工` 段 |
| 收工 | `.claude/skills/eod/SKILL.md` | 同上 | `## 收工` 段 |
| WAM | `.claude/skills/wam/SKILL.md` | 同上 | `## WAM` 段 |
| 調整本週 | （沒抽成 skill） | — | 一律 CLAUDE.md `## 調整本週` 段 |

skill 版的 CLAUDE.md 那三段通常只剩一句「已經做成 daily skill」— 那句留著不動。

**開始前先 `git status`**：第一段的改動還沒 commit（`Cockpit/Weekly-Commitment.md` 未提交）→ 先 `git add -A && git commit -m "Tracking Board 接管：任務搬上板"`，第二段才有自己的一個 commit、退路才分得開。不用問。

然後讀一次 `CLAUDE.md` 跟存在的 SKILL.md，把 A 組、B 組全部做完，再做 C 組（其他檔案），最後出報告。A 組的「原文」找不到（使用者改過）→ 找語意最接近的地方改，改完在報告裡註明。

### A 組：CLAUDE.md 小改

**A1. 新增「我的 Tracking Board」段** — 插在「## 你是誰」段之後、「## 互動前必做」之前：

```markdown
## 我的 Tracking Board（任務板）

- **看板網址**：（填實際網址）
- **專案位置**：`Efforts/Projects/Active/Tracking Board/`（部署與 API 說明 `DEPLOY.md`、**板子模式流程差異 `BOARD-MODE.md`**、接管作業單 `TAKEOVER.md`、改造菜單 `CUSTOMIZE.md`）
- **接管日**：（填今天 YYYY-MM-DD）— `BACKLOG.md` 與 `Weekly-Commitment.md` 的任務段自此退役

**任務的唯一帳本是看板。** 開工、收工、調整本週、WAM 的任務來源與分數都從看板拿 — 跟原流程不同的地方寫在 `BOARD-MODE.md`，進這些流程前先讀它；`Weekly-Commitment.md` 只記每週分數與歷史；`Efforts/` 目錄仍是專案本體的家，卡片用 `effort` 欄連回去。同一件事不要同時記在檔案和板上。

跟看板讀寫的硬規則（細節見 `DEPLOY.md`）：

- 一律用 curl；寫入前先 `GET /api/issues` 拿 `meta.rev`，每筆寫入帶 `expectedRev`、一次一件
- 砍卡＝把卡的 `resolution` 填 `dropped`，**不是刪卡**（不進計分、留紀錄）
- 開卡、接卡規則見 § 開卡與接卡規則

**看板連不上就退回檔案流程**（任何看板呼叫失敗、或 409 重試 3 次仍失敗）：
(a) 跟使用者說一聲「板子連不上、這步先照檔案流程做」；
(b) 該步驟改用最近的 daily notes 推估進度、並說明是估算（`BACKLOG.md` 與 `Weekly-Commitment.md` 任務段已退役、別拿它們當任務池）；
(c) 在今天 Daily Note「## 筆記」記一行「⚠ 板子未同步：{做了什麼}」；
(d) 下次連上時，先把 ⚠ 記錄補同步到卡，再進流程。
```

**A2. 互動前必做** — 第一段結尾補一句：

原文：`這 3 欄有使用者的稱呼、職位、主管 — 沒有讀就沒有客製。`
改成：`這 3 欄有使用者的稱呼、職位、主管 — 沒有讀就沒有客製。順看「我的 Tracking Board」拿看板網址。`

**A3. 系統結構**（code block 內）：

- `Cockpit/Weekly-Commitment.md      -- 本週 3-5 件主要任務 + 歷史紀錄` → `Cockpit/Weekly-Commitment.md      -- 每週分數與歷史紀錄（本週任務改看 Tracking Board）`
- `Cockpit/BACKLOG.md        -- 未排期的待辦事項（每項加 (YYYY-MM-DD added) 後綴）` → `Cockpit/BACKLOG.md        -- 已退役（任務池改在 Tracking Board）`
- 在 `Efforts/Projects/Active/  -- 進行中專案` 下一行加：`Efforts/Projects/Active/Tracking Board/  -- 任務看板（DEPLOY.md 部署與 API、BOARD-MODE.md 流程差異、TAKEOVER.md 接管、CUSTOMIZE.md 改造）`

**A4. 重要檔案**（表格）：

- `| \`Cockpit/Weekly-Commitment.md\` | 本週 3-5 件主要任務 + 歷史紀錄 |` → `| \`Cockpit/Weekly-Commitment.md\` | 每週分數與歷史紀錄（本週任務改看 Tracking Board） |`
- `| \`Cockpit/BACKLOG.md\` | 未排期的待辦 |` → `| \`Efforts/Projects/Active/Tracking Board/DEPLOY.md\` | 看板部署與 API 說明（網址見「我的 Tracking Board」） |`
- 再加一列：`| \`Efforts/Projects/Active/Tracking Board/BOARD-MODE.md\` | 板子模式的流程差異（開工／收工／調整本週／WAM 進流程前必讀） |`

**A5. 觸發語對應**（表格）— 加一列：

`| 「開一張卡」「幫我開卡」「上板」「記一張卡」 | § 開卡與接卡規則 |`
- 再加一列：`| 貼卡號 \`ISS-xxx\` 或卡標題（「做這張」「處理 ISS-012」「ISS-012 這個怎麼辦」） | § 開卡與接卡規則 · 接卡 |`

**A6. Inbox 批次處理**（表格）：

`| 轉為任務 | 寫入 \`Cockpit/BACKLOG.md\`（含 \`(YYYY-MM-DD added)\` 後綴）或今天的 Daily Note |` → `| 轉為任務 | 開一張看板 Backlog 卡（\`body\` 寫來源 Inbox 檔名）、或寫進今天的 Daily Note |`

**A7. 新增「開卡與接卡規則」段** — 插在「## 路徑規則」之前：

```markdown
## 開卡與接卡規則

### 開卡

> 觸發語：「開一張卡」「幫我開卡」「上板」「記一張卡」；開工／收工／WAM 流程中建卡也照這裡

幫使用者建卡時：

1. 把使用者講過的脈絡整理進 `body`（要做什麼、為什麼、給誰、什麼時候要）；缺關鍵資訊**最多追問一題**、不知道的不編
2. 對得上 `Efforts/Areas/` 或 `Efforts/Projects/Active/` 的路徑就掛 `effort`、對不上留空
3. 預設進 Backlog（`status` = `backlog`、不掛 `week`）；使用者說「這週要做」才掛本週 `week`、`status` 填 `todo`；使用者說「現在在做」才 `in-progress`
4. 只是順手做掉、不想佔本週承諾的 → `tags` 加 `bonus`（做完算加分、不稀釋分數）
5. 做完或卡住時留言（`POST /api/issues/:id/comments`）：做了什麼、產出在哪、卡在哪／等什麼 — 精簡但含必要資訊

標準都一樣：**之後打開這張卡，不用再問使用者、不用翻對話紀錄就能接手。**

### 接卡

> 觸發語：使用者貼卡號 `ISS-xxx` 或卡標題 —— 可能是要你做、也可能只是要討論

1. 先 `GET /api/issues` 讀那張卡的 title、body、留言，用卡上的脈絡接話；已經寫在卡上的資訊不重問
2. **只是討論**（問看法、想怎麼做、要不要做）→ 不動卡
3. **真的做了什麼**（改了檔、產出了東西、查到了結果）→ 留言記下：做了什麼、產出在哪（檔案路徑／網址）、下一步或等什麼；順手改 status：開始做 `in-progress`、做完 `done`、卡住 `blocked`（留言寫等什麼、知道日期就填 `due`）
4. 討論後**要做的事本身變了**（範圍、目標、交付對象）→ body 追加一段、不刪原文；其他一律寫留言。body 是規格、留言是紀錄
5. 寫入照硬規則：curl、expectedRev、一次一件
```

**A8. skill 版才做**（開工／收工／WAM 已抽成 skill 時）：

- 「系統結構」code block 下方那句 `> daily 流程寫在本 CLAUDE.md 內 § 開工 章節，不在 \`.claude/skills/\` — …` → 改成 `> 開工／收工／WAM 已抽成 \`.claude/skills/daily|eod|wam\`；板子模式的差異在 \`Efforts/Projects/Active/Tracking Board/BOARD-MODE.md\`。`
- 「觸發語對應」表裡 `§ 開工`、`§ 收工`、`§ WAM` 三格 → 改成 `daily skill（板子模式：先讀 BOARD-MODE.md）`、`eod skill（同上）`、`wam skill（同上）`

### B 組：插「🟦 板子模式」區塊（四個流程各一個，本文不動）

先把今天日期跑出來（`TZ='Asia/Taipei' date '+%Y-%m-%d'`）填進區塊。

**B1. 開工** — skill 版：`.claude/skills/daily/SKILL.md` frontmatter（第二個 `---`）之後、第一個標題或第一段之前；CLAUDE.md 版：`## 開工` 標題下方。插入：

```markdown
> 🟦 **板子模式（YYYY-MM-DD 接管後生效）**：本流程的任務來源與分數改讀 Tracking Board（網址見 CLAUDE.md「我的 Tracking Board」）。
> **進流程前先讀 `Efforts/Projects/Active/Tracking Board/BOARD-MODE.md`「開工差異」** — 它寫到的步驟照它做、其餘照本檔。
> 看板連不上 → 照本檔原流程做，並在今天 Daily Note「## 筆記」記一行「⚠ 板子未同步」。
```

**B2. 收工** — `.claude/skills/eod/SKILL.md` 或 `## 收工`，同款區塊，「開工差異」改「收工差異」。

**B3. WAM** — `.claude/skills/wam/SKILL.md` 或 `## WAM`，同款區塊，改「WAM 差異」。

**B4. 調整本週** — CLAUDE.md `## 調整本週` 標題下方，同款區塊，改「調整本週差異」。

**B5. 本文加註**（讓之後讀到那一句時不會照舊做）：在上面四個流程的本文裡，每一處提到 `BACKLOG.md`、「進 BACKLOG」、「打勾 Weekly-Commitment」、「讀 Weekly-Commitment 本週段落」的**句尾**加上 `（🟦 板子模式：改看看板，見 BOARD-MODE.md）`。只加註、不刪不改原句。

**B6. skill 的 description**（skill 版才做）：三個 SKILL.md frontmatter 的 `description` 句尾補 `板子模式：進流程前先讀 Tracking Board/BOARD-MODE.md。`（讓 Claude 在觸發時就知道要讀差異檔）。

### C 組：其他檔案

**C1. `Cockpit/BACKLOG.md`** — 第一段已搬完，整檔清空只留一行：

```markdown
> 本檔已退役，任務池改在 Tracking Board：（網址）
```

**C2. 其他還提到 BACKLOG 的地方** — 出廠版 vault 有這幾處，先 `grep -rn BACKLOG` 確認，**直接改**（這些是說明文字、不是資料，不用問），改了什麼列進報告：

| 檔案 | 位置 | 建議改法 |
|---|---|---|
| `Home.md` | Vault 結構 code block 的 `Cockpit/` 那行 | `Cockpit/ -- 個人駕駛艙（Daily / Weekly-Commitment 分數簿；任務池在 Tracking Board）` |
| `.claude/skills/knowledge-keeper/SKILL.md` | 「會議記錄」「Todo 清單」兩列 | `todo 進 BACKLOG` / `進 Cockpit/BACKLOG.md` → `開一張看板卡` |
| `.claude/skills/knowledge-keeper/folder-map.md` | `→ Cockpit/BACKLOG.md（不關這個 skill 的事）` | `→ 開一張看板卡（不關這個 skill 的事）` |
| `.claude/agents/archivist.md` | 「Todo 清單」列 | `建議使用者放 Cockpit/BACKLOG.md` → `建議使用者開一張看板卡` |
| `Efforts/` 各專案 README | 提到 BACKLOG 的句子 | 依上下文改成「看板」 |

`Guides/`、`Templates/` 唯讀，**不動**（Guides 裡的 BACKLOG 說法是出廠教學，留著沒關係）。

### 報告、存檔

改完把動了哪些檔案、各改了什麼，列成表格給使用者看（檔案 / 改了什麼 / 一句話）。使用者說 OK 之後：

```bash
git add -A && git commit -m "Tracking Board 接管：流程改認看板"
```

---

## 退路

- **看板連不上**：每個流程都留了檔案流程的退路（見 CLAUDE.md「我的 Tracking Board」段）。
- **接管改壞了**：`git log` 找到「Tracking Board 第一版上線」那次 commit，`git checkout <那次 commit> -- CLAUDE.md Cockpit/ .claude/skills/` 把檔案跳回接管前；板上的卡不會跟著回去（它們在雲端），要退回檔案流程就把卡的內容抄回 `BACKLOG.md`。
- **想整板從零開始**：`DEPLOY.md`「重置資料」— 先警告使用者：含封存區全清、不可復原。
