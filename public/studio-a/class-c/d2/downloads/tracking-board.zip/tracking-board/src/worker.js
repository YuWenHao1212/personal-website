// FLUX Tracking Board API — Durable Object mini-worker（單人教學版 v3）
//
// 儲存：SQLite-backed Durable Object，一板一實例（idFromName("board")）——
//   cards(id, pos, data)   活卡，pos 保留順序
//   archive(seq, id, data) 封存卡（獨立表 — 封存不再搬整包）
//   kv('shell')            meta（next_id / rev / updated）
// 為什麼是 DO：v2(KV) 每次寫入 = 讀整包→改→寫回，KV 最終一致 → 並發互蓋非零。
// DO = 單一實例序列化所有寫入 + SQLite 強一致 → 互蓋結構性消失、expectedRev 100% 可靠。
// 樂觀鎖（非破壞式）：寫入 body 可帶 expectedRev；與目前 meta.rev 不符 → 409（未帶 = 照舊接受）。
// ⚠️ statuses（欄位定義）由下方 STATUSES 常數提供、不入庫 — 改欄名 = 改 code + redeploy 就生效。
//
// Endpoints：
//   GET    /api/issues               → { meta, projects:[], statuses, issues }
//   GET    /api/archive              → { issues:[…封存卡] }
//   GET    /api/score[?week=2026-W29]→ { week, pct, done, total, cards, excluded }
//                                      week 省略 = 當前 ISO 週（Asia/Taipei）；掃 issues+archive，
//                                      歸檔不影響歷史週查詢。排除放棄卡、tags 含 bonus、tags 含 seed 的卡。
//   POST   /api/issues               → { fields:{...} } 新卡（配 next_id）
//   PATCH  /api/issues/:id           → { fields:{...} } 通用合併單卡（未知欄位直接收 — schema 保留彈性）
//   POST   /api/issues/:id/comments  → { comment:{text,…} } 加留言
//   POST   /api/issues/:id/archive   → 卡片移到 archive
//   POST   /api/issues/:id/unarchive → archive 移回看板（誤封存 / 還原）
//   PUT    /api/issues               → { blob:{meta,issues}, archive?:{issues}, expectedRev }
//                                      整包匯入（換網址搬家 / v2 升級搬資料 / 備份還原）。
//                                      ⚠ expectedRev 必填 — 守住後門，stale client 整包存檔會被正確擋下。
//
// 靜態頁面（GET /）由 Workers Static Assets 出（wrangler.toml [assets]），非 /api/* 不會進到這裡。

const STATUSES = [
  { id: "backlog", name: "Backlog" },
  { id: "todo", name: "Todo" },
  { id: "in-progress", name: "In Progress" },
  { id: "done", name: "Done" },
  { id: "blocked", name: "Blocked" },
];

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-weekly-board": "do-v3",
    },
  });

// Asia/Taipei 時間（edge 跑 UTC，固定 +8）
const twDate = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
const twStamp = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 19) + "+08:00";

// ---- ISO 週（跨年正確，免季常數）----
function isoParts(d) {
  const t = new Date(d);
  const day = (t.getUTCDay() + 6) % 7; // Mon=0
  t.setUTCDate(t.getUTCDate() - day + 3); // 移到該週四
  const ft = new Date(Date.UTC(t.getUTCFullYear(), 0, 4));
  const fd = (ft.getUTCDay() + 6) % 7;
  ft.setUTCDate(ft.getUTCDate() - fd + 3); // 該年第一個週四
  return { y: t.getUTCFullYear(), w: 1 + Math.round((t - ft) / 604800000) };
}
const isoTagOf = (p) => p.y + "-W" + String(p.w).padStart(2, "0");
const curWeekTag = () => isoTagOf(isoParts(new Date(twDate() + "T00:00:00Z")));

// ---- Score（教學版直算）：week 卡 done/total，排除放棄卡、bonus tag、seed tag ----
function scoreForWeek(cards, week) {
  const excluded = [];
  const list = [];
  let done = 0, total = 0;
  for (const i of cards) {
    if (i.week !== week) continue;
    const tags = Array.isArray(i.tags) ? i.tags : i.tags ? [i.tags] : [];
    if (i.resolution) { excluded.push({ id: i.id, why: "dropped" }); continue; }
    if (tags.includes("bonus")) { excluded.push({ id: i.id, why: "bonus 不計分" }); continue; }
    if (tags.includes("seed")) { excluded.push({ id: i.id, why: "seed（未來再說）不計分" }); continue; }
    total++;
    if (i.status === "done") done++;
    list.push({ id: i.id, status: i.status, title: i.title });
  }
  const pct = total === 0 ? null : Math.round((done / total) * 10000) / 100;
  return { week, pct, done, total, cards: list, excluded };
}

export class TrackingBoardDO {
  constructor(ctx) {
    this.sql = ctx.storage.sql;
    ctx.blockConcurrencyWhile(async () => {
      this.sql.exec(`
        CREATE TABLE IF NOT EXISTS cards(id TEXT PRIMARY KEY, pos INTEGER NOT NULL, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS archive(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      `);
      // 空板 = 直接可用（首次 GET 就回空看板，不回 404）
      if (!this.getShell()) this.putShell({ meta: { next_id: 1, updated: twStamp(), rev: 0 } });
    });
  }

  // ---- SQLite helpers（全同步 — 寫入臨界區不 interleave）----
  getShell() {
    const r = this.sql.exec("SELECT value FROM kv WHERE key='shell'").toArray();
    return r.length ? JSON.parse(r[0].value) : null;
  }
  putShell(shell) {
    this.sql.exec(
      "INSERT INTO kv(key,value) VALUES('shell',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
      JSON.stringify(shell)
    );
  }
  listCards() {
    return this.sql.exec("SELECT data FROM cards ORDER BY pos").toArray().map((r) => JSON.parse(r.data));
  }
  listArchive() {
    return this.sql.exec("SELECT data FROM archive ORDER BY seq").toArray().map((r) => JSON.parse(r.data));
  }
  getCard(id) {
    const r = this.sql.exec("SELECT data FROM cards WHERE id=?", id).toArray();
    return r.length ? JSON.parse(r[0].data) : null;
  }
  putCard(card) {
    this.sql.exec("UPDATE cards SET data=? WHERE id=?", JSON.stringify(card), card.id);
  }
  nextPos() {
    return this.sql.exec("SELECT COALESCE(MAX(pos),-1)+1 AS p FROM cards").toArray()[0].p;
  }
  bump(shell) {
    shell.meta.rev = (shell.meta.rev || 0) + 1;
    shell.meta.updated = twStamp();
    this.putShell(shell);
    return shell.meta.rev;
  }
  // 樂觀鎖 gate：body 帶 expectedRev 且與目前 rev 不符 → 409 回最新 rev；未帶 → null（照舊放行）
  // Number() 寬鬆比對 — 學員 curl 手打 JSON，字串 rev 也放行
  revGate(shell, body) {
    const exp = body ? body.expectedRev : undefined;
    if (exp === undefined || exp === null) return null;
    const cur = (shell.meta && shell.meta.rev) || 0;
    if (Number(exp) !== cur) {
      return json({ error: "rev conflict", rev: cur, hint: "board changed since your last read — GET /api/issues for the latest meta.rev, then retry with that expectedRev" }, 409);
    }
    return null;
  }
  // PUT / 搬家匯入共用：issues 拆一卡一列；statuses/projects 一律剝掉（欄位定義只認 code —
  // v2 export 的 GET 回應含 statuses，焊進 shell 會讓之後改 STATUSES 常數靜默失效）
  importBlob(blob) {
    this.sql.exec("DELETE FROM cards");
    (blob.issues || []).forEach((c, i) =>
      this.sql.exec("INSERT INTO cards(id,pos,data) VALUES(?,?,?)", c.id, i, JSON.stringify(c))
    );
    const shell = Object.assign({}, blob);
    delete shell.issues;
    delete shell.statuses;
    delete shell.projects;
    shell.meta = shell.meta || {};
    this.putShell(shell);
  }
  importArchive(arch) {
    this.sql.exec("DELETE FROM archive");
    for (const c of (arch && arch.issues) || [])
      this.sql.exec("INSERT INTO archive(id,data) VALUES(?,?)", c.id || null, JSON.stringify(c));
  }

  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    // body 先 await 完才碰 storage — 之後臨界區全同步，請求間不會在讀改寫中途 interleave
    const body = method !== "GET" && method !== "HEAD" ? await request.json().catch(() => null) : null;
    const shell = this.getShell();

    // GET /api/issues（整包；statuses/projects 一律用 code 常數 — 不吃 shell 殘留）
    if (path === "/api/issues" && method === "GET") {
      return json({ meta: shell.meta, projects: [], statuses: STATUSES, issues: this.listCards() });
    }

    // GET /api/archive
    if (path === "/api/archive" && method === "GET") {
      return json({ issues: this.listArchive() });
    }

    // GET /api/score[?week=2026-W29]（掃 issues+archive；歸檔不影響歷史週查詢）
    if (path === "/api/score" && method === "GET") {
      const week = url.searchParams.get("week") || curWeekTag();
      const live = this.listCards();
      const ids = new Set(live.map((c) => c.id));
      const arch = this.listArchive().filter((c) => c.id && !ids.has(c.id)); // 防禦：同 id 以活卡為準
      return json(scoreForWeek(live.concat(arch), week));
    }

    // PUT /api/issues（整包匯入 — 換網址搬家 / v2 升級 / 備份還原；expectedRev 必填）
    if (path === "/api/issues" && method === "PUT") {
      if (!body || !body.blob) return json({ error: "body.blob required" }, 400);
      if (body.expectedRev === undefined || body.expectedRev === null)
        return json({ error: "expectedRev required（整包覆蓋必帶樂觀鎖 — 先 GET /api/issues 拿 meta.rev）" }, 400);
      const cur = (shell.meta && shell.meta.rev) || 0;
      if (Number(body.expectedRev) !== cur) return json({ error: "rev conflict", rev: cur, hint: "board changed since your last read — GET /api/issues for the latest meta.rev, then retry with that expectedRev" }, 409);
      this.importBlob(body.blob);
      if (body.archive) this.importArchive(body.archive);
      const next = this.getShell();
      next.meta = next.meta || {};
      next.meta.rev = cur + 1;
      next.meta.updated = twStamp();
      this.putShell(next);
      return json({ rev: next.meta.rev });
    }

    // POST /api/issues（新卡）
    if (path === "/api/issues" && method === "POST") {
      const gate = this.revGate(shell, body);
      if (gate) return gate;
      const n = shell.meta.next_id || this.listCards().length + 1;
      shell.meta.next_id = n + 1;
      const id = "ISS-" + String(n).padStart(3, "0");
      const card = Object.assign(
        {
          id, title: "新 Issue", type: "task", status: STATUSES[0].id,
          priority: "P2", tags: [], body: "", source: "", due: null, week: null, effort: null,
          resolution: null, comments: [], created: twDate(), updated: twDate(),
        },
        (body && body.fields) || {}
      );
      card.id = id; // id 不可被 fields 覆蓋
      this.sql.exec("INSERT INTO cards(id,pos,data) VALUES(?,?,?)", card.id, this.nextPos(), JSON.stringify(card));
      const rev = this.bump(shell);
      return json({ rev, issue: card }, 201);
    }

    // POST /api/issues/:id/unarchive（archive → 看板；還原）
    // 專屬路由放在 /:id 主匹配之前 — 主匹配會先 getCard()、對已封存卡回 404
    const um = path.match(/^\/api\/issues\/([^/]+)\/unarchive$/);
    if (um && method === "POST") {
      const gate = this.revGate(shell, body);
      if (gate) return gate;
      const id = decodeURIComponent(um[1]);
      if (this.getCard(id)) return json({ error: "already live: " + id }, 409);
      const r = this.sql.exec("SELECT data FROM archive WHERE id=? ORDER BY seq DESC LIMIT 1", id).toArray();
      if (!r.length) return json({ error: "not in archive: " + id }, 404);
      const card = JSON.parse(r[0].data);
      delete card.archived_at;
      card.updated = twDate();
      this.sql.exec("DELETE FROM archive WHERE id=?", id);
      this.sql.exec("INSERT INTO cards(id,pos,data) VALUES(?,?,?)", id, this.nextPos(), JSON.stringify(card));
      const rev = this.bump(shell);
      return json({ rev, unarchived: id, issue: card });
    }

    // /api/issues/:id（+ /comments | /archive）
    const m = path.match(/^\/api\/issues\/([^/]+)(\/comments|\/archive)?$/);
    if (m) {
      const id = decodeURIComponent(m[1]);
      const sub = m[2];
      const card = this.getCard(id);
      if (!card) return json({ error: "not found: " + id }, 404);

      // PATCH 單卡（通用欄位合併；未知欄位直接收）
      if (!sub && method === "PATCH") {
        const gate = this.revGate(shell, body);
        if (gate) return gate;
        const fields = (body && body.fields) || {};
        delete fields.id;
        Object.assign(card, fields);
        card.updated = twDate();
        this.putCard(card);
        const rev = this.bump(shell);
        return json({ rev, issue: card });
      }
      // POST 留言（append）
      if (sub === "/comments" && method === "POST") {
        const gate = this.revGate(shell, body);
        if (gate) return gate;
        const c = (body && body.comment) || null;
        if (!c || !c.text) return json({ error: "comment.text required" }, 400);
        card.comments = Array.isArray(card.comments) ? card.comments : [];
        card.comments.push({ author: c.author || "me", ts: c.ts || twStamp(), text: c.text });
        card.updated = twDate();
        this.putCard(card);
        const rev = this.bump(shell);
        return json({ rev, issue: card });
      }
      // POST 封存（看板 → archive）
      if (sub === "/archive" && method === "POST") {
        const gate = this.revGate(shell, body);
        if (gate) return gate;
        card.archived_at = twStamp();
        this.sql.exec("DELETE FROM cards WHERE id=?", id);
        this.sql.exec("INSERT INTO archive(id,data) VALUES(?,?)", id, JSON.stringify(card));
        const rev = this.bump(shell);
        return json({ rev, archived: id });
      }
    }

    return json({ error: "method/route not supported" }, 405);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);
    // 全部 /api/* 進同一個具名 DO 實例（單一寫入窗口）
    return env.BOARD_DO.get(env.BOARD_DO.idFromName("board")).fetch(request);
  },
};
