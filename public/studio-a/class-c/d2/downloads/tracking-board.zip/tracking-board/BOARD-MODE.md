# 板子模式 — 流程差異（給 daily / eod / wam skill 與 CLAUDE.md 讀）

> 接管完成後本檔生效（`CLAUDE.md`「我的 Tracking Board」段有看板網址）。
> 本檔只寫「跟原流程**不同**的地方」— 沒寫到的步驟一律照原流程（skill 或 CLAUDE.md 的原文）做。
> 步驟用**意思**指認、不用編號：每個人的 skill 編號不一樣，但句子是一樣的。
> 部署、API、欄位、寫入安全 → 一律查同資料夾 `DEPLOY.md`（單一出處，本檔不重複）。

---

## 總則

1. **卡片 = 任務的唯一帳本。** `BACKLOG.md` 已退役；`Weekly-Commitment.md` 只剩分數簿（本週 meta、本週分數、歷史紀錄）；`Efforts/` 目錄仍是專案本體的家，卡片用 `effort` 欄連回去。同一件事不要同時記在檔案和板上。
2. **硬規則**：跟看板讀寫一律用 curl；寫入前先 `GET /api/issues` 拿 `meta.rev`、每筆寫入帶 `expectedRev`、一次一件；砍卡＝`resolution` 填 `dropped`、不是刪卡；**絕不跑 `npx wrangler delete`**。
3. **看板連不上就退回原流程**（呼叫失敗、或 409 重試 3 次仍失敗）：(a) 跟使用者說「板子連不上、這步先照原流程做」；(b) 該步驟改用最近 daily notes 推估、並說明是估算（別拿 `BACKLOG.md` 或 `Weekly-Commitment.md` 的 checkbox 當任務池，它們已退役）；(c) 在今天 Daily Note「## 筆記」記一行「⚠ 板子未同步：{做了什麼}」；(d) 下次連上先補同步再進流程。
4. 日期：進流程先跑 `TZ='Asia/Taipei' date '+%Y-%m-%d'`，本週 ISO 週 `TZ='Asia/Taipei' date '+%G-W%V'`（Windows 在 Git Bash 跑同一條）。

---

## 開工差異（daily skill；沒有 skill 就是 CLAUDE.md「## 開工」）

| 原流程裡的那一步 | 板子模式改成 |
|---|---|
| **Prereq**（日期 + git 檢查）做完 | 多做一件：`GET /api/issues` 把整板拿一次，後面每步都用這份。連不上 → 總則 3 |
| **自動提醒**「BACKLOG 有項目躺超過 4 週」 | 改看看板「Backlog」欄 `created` 距今 ≥ 28 天的卡（`body` 有「原本在 BACKLOG.md（日期）」「退回 Backlog（日期）」這類日期行 → 以**最新一行**為準；`tags` 含 `seed` 的跳過）。**多加一條**：「Blocked」欄 `due` 已到或已過的卡，逐張問「等的東西到了嗎？要拉回今天嗎？」 |
| **週一確認本週 commitment**（讀 Weekly-Commitment 本週段落） | 本週清單 = 看板上 `week` 是本週的卡（含 status），念給使用者聽，保持 / 微調 / 重新 lock 照原文（細節走「調整本週差異」） |
| **回顧最近的 daily notes** 的「已完成」 | 對照卡號：Daily 說做完、板上還不是 `done` 的**先列出來問一句**「是忘了收工（我補成 done）？還是你後來自己退回的（維持現狀）？」確認才改、不自動蓋 |
| **掃 Efforts/Areas 和 Projects/Active 目錄** ＋ **讀 BACKLOG.md 挑今天的事**（這兩步） | 合併成一步、都從整板拿：「Todo」＋「In Progress」＝今天的候選（`effort` 欄顯示所屬專案、本週 `week` 的優先）；「Backlog」有適合順手做的就提；「Blocked」照自動提醒問。**不再掃目錄、不再讀 BACKLOG.md、不再從 BACKLOG.md 刪項目** |
| email / calendar / 掃 Inbox 那幾步 | 照原文，不變。臨時冒出來的事：使用者**真的要承諾本週做完**才掛本週 `week`（進分母）；只是順手做掉 → 開卡 `tags` 加 `bonus`（做完算加分、不稀釋分數）。開卡照 CLAUDE.md § 開卡與接卡規則 |
| **討論今天做什麼** 的「BACKLOG 有今天可順手做的嗎？」 | 改問「看板 Todo、Backlog 裡有今天可順手做的嗎？」 |
| **建立 Daily Note** 的任務規則 | 「跟 Weekly-Commitment 對齊」→ 改「跟本週 `week` 的卡對齊」。任務表「對應本週重點」欄改填**卡號＋標題**（例 `ISS-042 週報彙整`）、沒對應卡寫「（無對應）」。選進今天的卡同步改狀態（一次一件）：還在 `backlog` / `todo` 的改 `todo` 或 `in-progress`（真的開始做才 `in-progress`）、沒掛 `week` 的補上本週 |
| 標色 🟢🟡🔴⚪（如果 skill 有） | 照原文，不變 |

---

## 收工差異（eod skill；沒有 skill 就是 CLAUDE.md「## 收工」）

| 原流程裡的那一步 | 板子模式改成 |
|---|---|
| **git log 看今天動過什麼** | 補一句：完成紀錄以看板為準 — git log 看不到改卡 |
| **沒做完的事三選一**「移到明天 / 進 BACKLOG / 砍掉」 | 改「移到明天 / 退回板上 / 砍掉」：**移到明天** = Daily Note 加一行照原文、卡不動；**退回板上** = 本週還會做 → 卡改 `todo`，本週不做了 → 卡改 `backlog`、`week` 清空、`body` 補一行「退回 Backlog（YYYY-MM-DD）」；**砍掉** = `resolution` 填 `dropped`（不刪卡、先確認） |
| **同步打勾 Weekly-Commitment** | 整步改成**逐卡同步看板**（一次一件、帶 expectedRev）：做完 → `done`；還在做 → 留 `in-progress`；今天沒動也不打算做 → 問使用者退回 `todo` 或 `backlog`。做完、卡住、或進度有變的卡順手留言（`POST /api/issues/:id/comments`）：做了什麼／進度到哪、產出在哪、卡在哪／等什麼 — 標準是「之後打開這張卡，不用翻對話紀錄就能接手」。**不打勾 Weekly-Commitment.md**（任務段已退役） |
| **review Inbox** 的「進 BACKLOG」 | 改「開一張卡」：開一張看板 Backlog 卡（`body` 寫來源 Inbox 檔名）→ 原 Inbox 檔 delete |
| **收工 commit** | 照原文。卡的改動在看板上、不在 git 裡 |

---

## 調整本週差異（CLAUDE.md「## 調整本週」）

| 原流程裡的那一步 | 板子模式改成 |
|---|---|
| **讀 Weekly-Commitment.md 本週段落** | 改 `GET /api/issues` 篩 `week` = 本週的卡（含 status）當本週清單。Weekly-Commitment.md 只看「上週歷史紀錄補齊了沒」 |
| **保持 / 微調 / 重新 lock** 後「寫入 Weekly-Commitment.md」 | 改在卡上（一次一件）：加＝開新卡或把 Backlog 卡掛本週 `week`、`status` 改 `todo`；砍＝`week` 清空退回 `backlog`（`body` 補一行「退回 Backlog（日期）」）、確定不做才 `resolution` 填 `dropped`；改優先序＝改 `priority` |

---

## WAM 差異（wam skill；沒有 skill 就是 CLAUDE.md「## WAM」）

| 原流程裡的那一步 | 板子模式改成 |
|---|---|
| **Prereq** | 多算下週 ISO 週：Mac `TZ='Asia/Taipei' date -v+7d '+%G-W%V'`；Windows Git Bash `date -d '+7 days' '+%G-W%V'` |
| **Step 1 結算本週**（讀 Weekly-Commitment 勾完成、算分數） | 改 `GET /api/score?week=本週 ISO 週` → `done` / `total` / `pct`；回應裡的卡片清單**留著**（Step 5 抄歷史要用）。`total` = 0 → 跟使用者確認本週沒掛卡、跳過計分。分數寫進 Weekly-Commitment.md「本週分數」照原文 |
| **Step 2 沒完成的事 做 / 拆 / 延 / 砍** | 對象改「本週 `week` 的卡裡 `status` 不是 `done` 的每一張」，動作落在卡上（一次一件）：**做** = `week` 改下週、標題尾加 `⟲N`；**拆** = 開子卡第一段（`week` = 下週）、原卡 `resolution` 填 `dropped`、留言「拆為 {新卡號}」；**延** = `week` 清空、`status` 改 `backlog`、`body` 補一行「退回 Backlog（日期）」；**砍** = `resolution` 填 `dropped`。「連續 2 週都做沒做到」→ 看標題已有 `⟲2` 的卡，第 3 週不准再選「做」 |
| **Step 3 回顧三問** | 照原文 |
| **Step 4 Lock 下週** 的來源清單 | 「BACKLOG 拉進來的事」→ 看板 Backlog 的卡：`week` 填下週、`status` 改 `todo`；其他來源（做/拆的卡已改好、主管新增、新 AI 工作流、全新項目）→ 開新卡（`week` = 下週、`status` = `todo`、對得上就掛 `effort`）。順掃 Backlog `created` ≥ 28 天的卡（`seed` 跳過）逐張問「拉進下週 / 拆小 / 砍掉？」。3-5 張照原文 |
| **Step 5 寫進 Weekly-Commitment** | **先抄後封、順序不可反**：① 歷史紀錄加 `### W{N}（起訖）— XX%`，用 Step 1 那份：完成卡逐行 `- [x] 卡號 標題`、未完成卡 `- [ ] 卡號 標題 → 做⟲N／拆／延／砍`、`tags` 含 `bonus` 的列「Bonus」小段；② 「本週」meta 三行改下週；③ 清空「本週分數」；④ **然後才結算封存**：請使用者按板上「🗂 結算封存」鈕（會把該週 `done` 卡與放棄卡一起封存），或 Claude 逐張 `POST /api/issues/:id/archive`（一次一件）— 第一次問偏好、之後記住。封存不影響歷史週查分 |
| **Step 6 commit + 收尾** | 照原文；結尾那句改「下週的卡已經在板上、本週分數寫進 Weekly-Commitment.md、改動已 commit。下週一說『開工』，我會先讀你的板。」 |

---

## Inbox 批次處理差異（CLAUDE.md）

「轉為任務」→ 開一張看板 Backlog 卡（`body` 寫來源）、或照原文寫進今天的 Daily Note；不寫 `BACKLOG.md`。

## 開卡與接卡規則

見 `CLAUDE.md` § 開卡與接卡規則（接管時加進去的）：建卡怎麼填、使用者貼卡號時只討論不動卡、真的做了才留言＋改 status。
