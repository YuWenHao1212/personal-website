STUDIO A · 離線簡報套件
=======================
把這個資料夾裡的東西，跟 Claude Design 抓回來的簡報放在一起，
就能把簡報轉成「雙擊就開、不用連網」的離線版。

  deck-stage.js  翻頁引擎（原生，不需要 React）
  fonts/         Noto Sans TC 四種字重

  轉離線版.md  給 Claude Code 讀的轉檔做法

怎麼用：不用自己動手，跟 Claude Code 說「讀 轉離線版.md，照著把我的簡報轉成離線版」就好。
