---
name: niceioi-design
description: Use this skill to generate well-branded interfaces and assets for nice ioi (niceioi) — a Korean-style ("韓系") Taiwanese quality womenswear brand — for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. Identity: 藕粉、圓潤、溫暖 (lotus-pink, rounded, warm).
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files (tokens, components, slides, guidelines, assets).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Core brand rules to never break:
- Mauve `#E1BAC7` (藕粉) is for **fills / header bands / accents only — never body text** (too light). Use deep rose `#C98BA0` for accent text, ★ and icons; warm dark-grey `#3A3A3A` for headings/body.
- White-first pages; introduce pink via a **header band** or a **light-pink base card**, never by flooding a page in pink.
- **Roundness is the identity** — cards 18px, pills 999px. No sharp square corners, no gradients, no glassmorphism, no emoji.
- Noto Sans TC; headings 600 (medium, not black), body 400, airy 1.7 leading.
- Tone: warm, gentle, friendly Traditional Chinese; soft and sensory, never hard-sell.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
