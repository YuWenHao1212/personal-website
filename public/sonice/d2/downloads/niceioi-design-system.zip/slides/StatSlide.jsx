/* StatSlide — Wordmark is global. */

/** Big-stat slide — mauve wash, oversized deep-rose number. */
function StatSlide({
  stat = '92%',
  label = '回購率',
  detail = '穿過一次就回來的溫柔，是 nice ioi 最在意的事。',
}) {
  return (
    <div style={{
      width: 1280, height: 720, background: 'var(--ds-surface)',
      fontFamily: 'var(--ds-font-body)', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 72, boxSizing: 'border-box',
    }}>
      <div style={{
        fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 200,
        lineHeight: 1, color: 'var(--ds-primary-deep)', letterSpacing: '-0.02em',
      }}>{stat}</div>
      <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 40, color: 'var(--ds-ink)', marginTop: 16 }}>
        {label}
      </div>
      <div style={{ fontSize: 24, color: 'var(--ds-muted)', marginTop: 22, maxWidth: 680, lineHeight: 1.7 }}>{detail}</div>
      <div style={{ marginTop: 48 }}><Wordmark size={20} color="var(--ds-primary)" /></div>
    </div>
  );
}

Object.assign(window, { StatSlide });
