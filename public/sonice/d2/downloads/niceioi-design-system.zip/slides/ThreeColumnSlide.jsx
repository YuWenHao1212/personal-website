/* ThreeColumnSlide — Slide, Eyebrow are global. */

/** Three-column feature cards — white/tint, large radius, deep-rose icon dot. */
function ThreeColumnSlide({
  eyebrow = '品牌主張',
  title = '為什麼選 nice ioi',
  items = [
    { tag: '面料', head: '柔軟親膚', body: '精選韓系面料，貼身不悶、久穿也舒服。' },
    { tag: '剪裁', head: '俐落溫柔', body: '修飾身形的版型，日常也能穿出比例。' },
    { tag: '價格', head: '友善入手', body: '品質與價格的剛好平衡，溫柔不負擔。' },
  ],
}) {
  return (
    <Slide>
      <Eyebrow>{eyebrow}</Eyebrow>
      <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 48, color: 'var(--ds-ink)', marginBottom: 40 }}>
        {title}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 28 }}>
        {items.map((it, i) => (
          <div key={i} style={{
            background: i === 0 ? 'var(--ds-surface)' : 'var(--ds-bg)',
            border: '1.5px solid var(--ds-line)', borderRadius: 'var(--ds-radius-card)',
            boxShadow: 'var(--ds-shadow-card)', padding: 32, minHeight: 280,
            display: 'flex', flexDirection: 'column',
          }}>
            <span style={{
              alignSelf: 'flex-start', background: 'var(--ds-primary)', color: '#fff',
              fontWeight: 500, fontSize: 16, padding: '5px 16px', borderRadius: 999, marginBottom: 22,
            }}>{it.tag}</span>
            <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 30, color: 'var(--ds-primary-deep)', marginBottom: 14 }}>
              {it.head}
            </div>
            <div style={{ fontSize: 19, lineHeight: 1.7, color: 'var(--ds-body)' }}>{it.body}</div>
          </div>
        ))}
      </div>
    </Slide>
  );
}

Object.assign(window, { ThreeColumnSlide });
