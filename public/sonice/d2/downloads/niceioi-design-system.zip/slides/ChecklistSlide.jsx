/* ChecklistSlide — Slide, Eyebrow are global. */

const ChecklistTick = () => (
  <span style={{
    width: 32, height: 32, flex: '0 0 auto', borderRadius: 10,
    background: 'var(--ds-primary-deep)', display: 'flex', alignItems: 'center', justifyContent: 'center',
  }}>
    <svg width="18" height="18" viewBox="0 0 14 14" fill="none">
      <path d="M2.5 7.5L5.5 10.5L11.5 3.5" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  </span>
);

/** Decision checklist — rounded checkboxes, deep-rose ticks. */
function ChecklistSlide({
  eyebrow = '上市前確認',
  title = '本季決策清單',
  items = [
    '主打色：藕粉系 3 款，已定樣',
    '面料供應商：韓廠確認交期',
    '定價區間：NT$590–1,290',
    '視覺：圓角、色帶、深玫瑰點綴',
    '通路：官網 + 三間實體門市',
  ],
}) {
  return (
    <Slide>
      <Eyebrow>{eyebrow}</Eyebrow>
      <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 48, color: 'var(--ds-ink)', marginBottom: 36 }}>
        {title}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        {items.map((it, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 20,
            background: i === 0 ? 'var(--ds-surface)' : 'var(--ds-bg)',
            border: '1.5px solid var(--ds-line)', borderRadius: 'var(--ds-radius)',
            padding: '18px 26px',
          }}>
            <ChecklistTick />
            <span style={{ fontSize: 23, color: 'var(--ds-body)' }}>{it}</span>
          </div>
        ))}
      </div>
    </Slide>
  );
}

Object.assign(window, { ChecklistSlide });
