/* QuoteSlide — Wordmark is global. */

/** Big-quote slide — mauve band accent, soft heading-weight quote on white. */
function QuoteSlide({
  quote = '柔軟，是一種被好好對待的感覺。',
  attribution = '— nice ioi 品牌主張',
}) {
  return (
    <div style={{
      width: 1280, height: 720, background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)', position: 'relative', overflow: 'hidden',
      display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 110px', boxSizing: 'border-box',
    }}>
      <div style={{ width: 72, height: 8, borderRadius: 999, background: 'var(--ds-primary)', marginBottom: 40 }}></div>
      <div style={{
        fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 64,
        lineHeight: 1.35, color: 'var(--ds-ink)', letterSpacing: '-0.01em', maxWidth: 940,
      }}>{quote}</div>
      <div style={{ fontSize: 24, color: 'var(--ds-primary-deep)', marginTop: 36, fontWeight: 500 }}>{attribution}</div>
      <div style={{ position: 'absolute', right: 72, bottom: 56 }}><Wordmark size={20} color="var(--ds-muted)" /></div>
    </div>
  );
}

Object.assign(window, { QuoteSlide });
