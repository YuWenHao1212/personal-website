/* nice ioi slide kit — shared frame + bits. React is global (UMD). */

/** Shared 1280×720 slide frame — white page, soft padding. */
function Slide({ children, pad = 72, style }) {
  return (
    <div style={{
      width: 1280, height: 720, background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)', color: 'var(--ds-body)',
      position: 'relative', overflow: 'hidden', boxSizing: 'border-box',
      padding: pad, ...style,
    }}>{children}</div>
  );
}

/** Small mauve eyebrow label above a heading. */
function Eyebrow({ children }) {
  return (
    <div style={{
      display: 'inline-block', color: 'var(--ds-primary-deep)',
      fontWeight: 600, fontSize: 18, letterSpacing: '0.14em',
      marginBottom: 18, whiteSpace: 'nowrap',
    }}>{children}</div>
  );
}

/** niceioi wordmark, deep-rose on white. */
function Wordmark({ size = 26, color = 'var(--ds-primary-deep)' }) {
  return (
    <span style={{
      fontFamily: 'var(--ds-font-heading)', fontWeight: 600,
      fontSize: size, color, letterSpacing: '-0.01em',
    }}>niceioi</span>
  );
}

Object.assign(window, { Slide, Eyebrow, Wordmark });
