/* MatrixSlide — Slide, Eyebrow are global. */

const MatrixStar = ({ on }) => (
  <svg width="22" height="22" viewBox="0 0 24 24" style={{ display: 'inline-block' }}>
    <path d="M12 2.5l2.9 5.9 6.5.95-4.7 4.58 1.1 6.47L12 17.4l-5.8 3.07 1.1-6.47L2.6 9.4l6.5-.95L12 2.5z"
      fill={on ? 'var(--ds-primary-deep)' : 'var(--ds-line)'} />
  </svg>
);

/** Rounded comparison matrix — ★ deep-rose, highlight column on light pink. */
function MatrixSlide({
  eyebrow = '比較',
  title = 'nice ioi vs 一般快時尚',
  cols = ['面料品質', '剪裁版型', '入手價格', '退換貼心'],
  rows = [
    { name: 'nice ioi', highlight: true, scores: [5, 5, 4, 5] },
    { name: '一般快時尚', highlight: false, scores: [3, 3, 5, 2] },
  ],
}) {
  return (
    <Slide>
      <Eyebrow>{eyebrow}</Eyebrow>
      <div style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 48, color: 'var(--ds-ink)', marginBottom: 40 }}>
        {title}
      </div>
      <div style={{ border: '1.5px solid var(--ds-line)', borderRadius: 'var(--ds-radius-card)', overflow: 'hidden', boxShadow: 'var(--ds-shadow-card)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: `220px repeat(${cols.length}, 1fr)`, background: 'var(--ds-surface)', borderBottom: '1.5px solid var(--ds-line)' }}>
          <div style={{ padding: '20px 28px' }}></div>
          {cols.map((c, i) => (
            <div key={i} style={{ padding: '20px 16px', fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 19, color: 'var(--ds-ink)', textAlign: 'center' }}>{c}</div>
          ))}
        </div>
        {rows.map((r, ri) => (
          <div key={ri} style={{
            display: 'grid', gridTemplateColumns: `220px repeat(${cols.length}, 1fr)`,
            background: r.highlight ? 'var(--ds-primary-tint)' : 'var(--ds-bg)',
            borderBottom: ri < rows.length - 1 ? '1.5px solid var(--ds-line)' : 'none',
          }}>
            <div style={{ padding: '24px 28px', fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 22, color: r.highlight ? 'var(--ds-primary-deep)' : 'var(--ds-body)', display: 'flex', alignItems: 'center' }}>{r.name}</div>
            {r.scores.map((s, si) => (
              <div key={si} style={{ padding: '24px 8px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 2 }}>
                {Array.from({ length: 5 }).map((_, k) => <MatrixStar key={k} on={k < s} />)}
              </div>
            ))}
          </div>
        ))}
      </div>
    </Slide>
  );
}

Object.assign(window, { MatrixSlide });
