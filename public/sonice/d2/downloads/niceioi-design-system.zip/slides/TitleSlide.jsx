/* TitleSlide — Wordmark is global. */

/** Cover slide — signature mauve band with white wordmark, title below on white. */
function TitleSlide({
  wordmark = 'niceioi',
  title = '2025 春夏新品提案',
  subtitle = '韓系品質女裝 · 藕粉、圓潤、溫暖',
}) {
  return (
    <div style={{
      width: 1280, height: 720, background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)', position: 'relative', overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{
        background: 'var(--ds-primary)', color: 'var(--ds-on-primary)',
        padding: '40px 72px', display: 'flex', alignItems: 'center',
      }}>
        <span style={{ fontFamily: 'var(--ds-font-heading)', fontWeight: 600, fontSize: 40, letterSpacing: '-0.01em' }}>
          {wordmark}
        </span>
      </div>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 72px' }}>
        <div style={{
          fontFamily: 'var(--ds-font-heading)', fontWeight: 600,
          fontSize: 76, lineHeight: 1.12, color: 'var(--ds-ink)', letterSpacing: '-0.01em',
        }}>{title}</div>
        <div style={{ fontSize: 26, color: 'var(--ds-muted)', marginTop: 24, lineHeight: 1.6 }}>{subtitle}</div>
      </div>
      <div style={{ padding: '0 72px 48px', display: 'flex', justifyContent: 'flex-end' }}>
        <Wordmark size={20} color="var(--ds-muted)" />
      </div>
    </div>
  );
}

Object.assign(window, { TitleSlide });
