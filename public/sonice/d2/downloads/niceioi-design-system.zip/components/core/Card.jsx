import React from 'react';

/**
 * nice ioi Card — large rounded corners, soft warm shadow. Optional mauve header
 * band (the brand's signature cover/section treatment).
 */
export function Card({
  children,
  band,
  tint = false,
  hoverable = false,
  style,
  bodyStyle,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: tint ? 'var(--ds-surface)' : 'var(--ds-bg)',
        borderRadius: 'var(--ds-radius-card)',
        border: '1.5px solid var(--ds-line)',
        boxShadow: hover && hoverable ? 'var(--ds-shadow-pop)' : 'var(--ds-shadow-card)',
        overflow: 'hidden',
        transition: 'box-shadow var(--ds-dur) var(--ds-ease), transform var(--ds-dur) var(--ds-ease)',
        transform: hover && hoverable ? 'translateY(-3px)' : 'none',
        ...style,
      }}
      {...rest}
    >
      {band ? (
        <div
          style={{
            background: 'var(--ds-primary)',
            color: 'var(--ds-on-primary)',
            fontFamily: 'var(--ds-font-heading)',
            fontWeight: 'var(--ds-weight-heading)',
            fontSize: 18,
            padding: '14px 22px',
          }}
        >
          {band}
        </div>
      ) : null}
      <div style={{ padding: 24, ...bodyStyle }}>{children}</div>
    </div>
  );
}
