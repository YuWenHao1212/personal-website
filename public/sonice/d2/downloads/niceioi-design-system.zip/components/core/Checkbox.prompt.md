Rounded "decision-list" checkbox — soft-square box, deep-rose fill with white tick when on.

```jsx
<Checkbox label="加入購物車" defaultChecked />
<Checkbox label="訂閱電子報" checked={sub} onChange={setSub} />
```

- Controlled with `checked` + `onChange(next)`, or uncontrolled via `defaultChecked`.
- Corners are softly rounded (8px), never a sharp square — roundness is the identity.
