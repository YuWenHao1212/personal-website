import * as React from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';

/**
 * nice ioi pill button — warm, rounded, soft. Use `primary` (mauve fill) for the
 * single main action on a view; `secondary` for supporting actions; `ghost` for
 * low-emphasis inline actions.
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Button label / content. */
  children?: React.ReactNode;
  /** Visual emphasis. @default "primary" */
  variant?: ButtonVariant;
  /** Control size. @default "md" */
  size?: ButtonSize;
  /** Disable interaction. @default false */
  disabled?: boolean;
}

export declare function Button(props: ButtonProps): React.JSX.Element;
