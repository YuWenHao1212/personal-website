import * as React from 'react';

/**
 * nice ioi star rating — deep-rose ★ over soft-pink empties. Read-only by default;
 * pass `onRate` to make it clickable (with hover preview). Half values render in
 * display mode.
 */
export interface StarRatingProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Current rating (supports halves in display). @default 5 */
  value?: number;
  /** Total stars. @default 5 */
  max?: number;
  /** Star pixel size. @default 22 */
  size?: number;
  /** If provided, stars become clickable; called with 1..max. */
  onRate?: (value: number) => void;
}

export declare function StarRating(props: StarRatingProps): React.JSX.Element;
