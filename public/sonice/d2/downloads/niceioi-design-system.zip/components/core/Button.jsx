import React from 'react';

/**
 * nice ioi Button — rounded (pill), warm, soft.
 * Variants: primary (mauve fill, white text), secondary (pink-tint), ghost (text + soft hover).
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const sizes = {
    sm: { padding: '8px 18px', fontSize: 14 },
    md: { padding: '12px 28px', fontSize: 16 },
    lg: { padding: '16px 40px', fontSize: 18 },
  };

  const variants = {
    primary: {
      background: 'var(--ds-primary)',
      color: 'var(--ds-on-primary)',
      border: '1.5px solid var(--ds-primary)',
    },
    secondary: {
      background: 'var(--ds-surface)',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid var(--ds-line)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid transparent',
    },
  };

  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);

  const hoverFx = {
    primary: { background: 'var(--ds-primary-deep)', borderColor: 'var(--ds-primary-deep)' },
    secondary: { background: 'var(--ds-primary-tint)' },
    ghost: { background: 'var(--ds-surface)' },
  };

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={{
        fontFamily: 'var(--ds-font-body)',
        fontWeight: 'var(--ds-weight-strong)',
        borderRadius: 'var(--ds-radius-pill)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        transition: 'background var(--ds-dur) var(--ds-ease), transform var(--ds-dur) var(--ds-ease)',
        transform: press && !disabled ? 'scale(0.97)' : 'scale(1)',
        whiteSpace: 'nowrap',
        lineHeight: 1,
        ...sizes[size],
        ...variants[variant],
        ...(hover && !disabled ? hoverFx[variant] : null),
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
