import React from 'react';

/**
 * nice ioi StarRating — deep-rose ★ rating. Read-only display by default; pass
 * `onRate` to make it interactive. Supports halves in display via `value`.
 */
export function StarRating({ value = 5, max = 5, size = 22, onRate, style, ...rest }) {
  const [hover, setHover] = React.useState(null);
  const shown = hover !== null ? hover : value;

  return (
    <span style={{ display: 'inline-flex', gap: 4, ...style }} {...rest}>
      {Array.from({ length: max }).map((_, i) => {
        const fill = shown >= i + 1 ? 1 : shown >= i + 0.5 ? 0.5 : 0;
        const id = `half-${i}-${Math.random().toString(36).slice(2, 7)}`;
        return (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            onMouseEnter={onRate ? () => setHover(i + 1) : undefined}
            onMouseLeave={onRate ? () => setHover(null) : undefined}
            onClick={onRate ? () => onRate(i + 1) : undefined}
            style={{ cursor: onRate ? 'pointer' : 'default' }}
          >
            <defs>
              <linearGradient id={id}>
                <stop offset={`${fill * 100}%`} stopColor="var(--ds-primary-deep)" />
                <stop offset={`${fill * 100}%`} stopColor="var(--ds-line)" />
              </linearGradient>
            </defs>
            <path
              d="M12 2.5l2.9 5.9 6.5.95-4.7 4.58 1.1 6.47L12 17.4l-5.8 3.07 1.1-6.47L2.6 9.4l6.5-.95L12 2.5z"
              fill={`url(#${id})`}
            />
          </svg>
        );
      })}
    </span>
  );
}
