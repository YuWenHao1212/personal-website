import React from 'react';

/**
 * nice ioi Checkbox — rounded (soft square) checkbox, deep-rose when checked.
 * Controlled via `checked` + `onChange`, or uncontrolled with `defaultChecked`.
 */
export function Checkbox({
  checked,
  defaultChecked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [inner, setInner] = React.useState(defaultChecked);
  const on = isControlled ? checked : inner;

  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInner(!on);
    onChange && onChange(!on);
  };

  return (
    <label
      onClick={toggle}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 12,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        fontFamily: 'var(--ds-font-body)',
        fontSize: 16,
        color: 'var(--ds-body)',
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          width: 24,
          height: 24,
          flex: '0 0 auto',
          borderRadius: 8,
          border: on ? '1.5px solid var(--ds-primary-deep)' : '1.5px solid var(--ds-line)',
          background: on ? 'var(--ds-primary-deep)' : 'var(--ds-bg)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all var(--ds-dur) var(--ds-ease)',
        }}
      >
        {on ? (
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2.5 7.5L5.5 10.5L11.5 3.5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        ) : null}
      </span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
