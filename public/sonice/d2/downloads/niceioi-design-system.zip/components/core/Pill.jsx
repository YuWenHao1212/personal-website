import React from 'react';

/**
 * nice ioi Pill / Tag — capsule label. tone "solid" = mauve fill + white text,
 * "soft" = light-pink tint + deep-rose text, "line" = outlined.
 */
export function Pill({ children, tone = 'solid', size = 'md', style, ...rest }) {
  const sizes = {
    sm: { padding: '3px 12px', fontSize: 12 },
    md: { padding: '5px 16px', fontSize: 14 },
  };
  const tones = {
    solid: { background: 'var(--ds-primary)', color: 'var(--ds-on-primary)', border: '1.5px solid var(--ds-primary)' },
    soft:  { background: 'var(--ds-surface)', color: 'var(--ds-primary-deep)', border: '1.5px solid var(--ds-line)' },
    line:  { background: 'transparent', color: 'var(--ds-primary-deep)', border: '1.5px solid var(--ds-primary)' },
  };
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontFamily: 'var(--ds-font-body)',
        fontWeight: 'var(--ds-weight-strong)',
        borderRadius: 'var(--ds-radius-pill)',
        lineHeight: 1,
        whiteSpace: 'nowrap',
        ...sizes[size],
        ...tones[tone],
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
