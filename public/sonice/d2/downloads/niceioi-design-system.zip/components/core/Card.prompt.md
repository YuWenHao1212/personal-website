The default rounded container — 18px corners, soft warm shadow. Use a mauve `band` for section/feature cards.

```jsx
<Card band="韓系剪裁" hoverable>
  <p>柔軟親膚的面料，日常也能美得自在。</p>
</Card>

<Card tint>淡粉底卡，帶出溫度但仍乾淨。</Card>
```

- `band`: mauve header strip with white heading text (signature treatment).
- `tint`: light-pink surface vs white.
- `hoverable`: lifts 3px and deepens the warm shadow.
