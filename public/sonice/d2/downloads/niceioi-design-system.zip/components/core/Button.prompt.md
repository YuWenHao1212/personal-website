One main action per view; a soft mauve pill that darkens to deep-rose on hover and shrinks slightly on press.

```jsx
<Button variant="primary" size="md" onClick={save}>立即選購</Button>
<Button variant="secondary">看更多</Button>
<Button variant="ghost" size="sm">取消</Button>
```

- `variant`: `primary` (mauve fill / white text), `secondary` (light-pink tint / deep-rose text), `ghost` (text only, soft surface on hover).
- `size`: `sm` · `md` · `lg`. Always pill-shaped (`--ds-radius-pill`).
- Never use pink as a label color on white — keep text white-on-mauve or deep-rose.
