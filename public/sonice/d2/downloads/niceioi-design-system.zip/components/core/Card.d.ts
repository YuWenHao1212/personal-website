import * as React from 'react';

/**
 * nice ioi card — generous 18px radius, soft warm shadow, optional mauve header
 * band. The default container for grouped content (three-column features, etc).
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** Optional mauve header band content (string or node). */
  band?: React.ReactNode;
  /** Use the light-pink surface instead of white. @default false */
  tint?: boolean;
  /** Lift + deepen shadow on hover. @default false */
  hoverable?: boolean;
  /** Style override for the inner body padding wrapper. */
  bodyStyle?: React.CSSProperties;
}

export declare function Card(props: CardProps): React.JSX.Element;
