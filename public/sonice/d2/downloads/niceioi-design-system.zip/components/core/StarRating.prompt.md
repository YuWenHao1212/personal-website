Deep-rose ★ rating — product reviews, matrix highlights, quality marks.

```jsx
<StarRating value={4.5} />
<StarRating value={rating} onRate={setRating} size={28} />
```

- Read-only by default; pass `onRate` for an interactive picker with hover preview.
- Filled stars use `--ds-primary-deep`; empties use the soft pink line color.
