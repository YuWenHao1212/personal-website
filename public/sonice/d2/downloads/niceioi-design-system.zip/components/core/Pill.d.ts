import * as React from 'react';

export type PillTone = 'solid' | 'soft' | 'line';
export type PillSize = 'sm' | 'md';

/**
 * nice ioi capsule label — categories, status, filters. Mauve is decorative here,
 * so it's allowed as a fill behind white text (never as readable body text).
 */
export interface PillProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** @default "solid" */
  tone?: PillTone;
  /** @default "md" */
  size?: PillSize;
}

export declare function Pill(props: PillProps): React.JSX.Element;
