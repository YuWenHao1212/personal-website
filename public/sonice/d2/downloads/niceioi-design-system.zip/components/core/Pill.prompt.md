Capsule label for categories, tags, and status — the brand's signature "藥丸 pill".

```jsx
<Pill tone="solid">新品</Pill>
<Pill tone="soft">韓系</Pill>
<Pill tone="line" size="sm">預購</Pill>
```

- `tone`: `solid` (mauve / white), `soft` (tint / deep-rose), `line` (outlined).
- Always fully rounded. Keep labels short — 2–4 characters reads best.
