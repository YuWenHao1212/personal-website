import * as React from 'react';

/**
 * nice ioi rounded checkbox — soft-square (8px) box that fills deep-rose with a
 * white tick when checked. Works controlled (`checked`) or uncontrolled.
 */
export interface CheckboxProps extends Omit<React.HTMLAttributes<HTMLLabelElement>, 'onChange'> {
  /** Controlled checked state. */
  checked?: boolean;
  /** Initial state when uncontrolled. @default false */
  defaultChecked?: boolean;
  /** Fired with the next boolean value. */
  onChange?: (checked: boolean) => void;
  /** Inline label text. */
  label?: React.ReactNode;
  /** @default false */
  disabled?: boolean;
}

export declare function Checkbox(props: CheckboxProps): React.JSX.Element;
