# nice ioi — Design System

> **藕粉、圓潤、溫暖。** Lotus-pink, rounded, warm.
> 韓系品質女裝 · 年輕柔甜 friendly. Soft but never saccharine; clean but with warmth — the deliberate opposite of sister-brand **SO NICE**'s cold black-and-white.

nice ioi is a Taiwanese, Korean-style ("韓系") quality womenswear brand. Its voice is young, gentle and friendly; its look is dusty mauve-pink ("藕粉"), generously rounded, and airy. This system exists so design agents can generate **on-brand decks, mocks and product surfaces** that feel unmistakably like nice ioi.

## Sources provided
- `niceioi/design-system.md` — brand spec (Traditional Chinese), deck-oriented.
- `niceioi/tokens.css` — the canonical `--ds-*` token set (preserved here; token names are shared across the brand family, so swapping this file = swapping brand skin).
- `niceioi/logo.png` — `niceioi` wordmark, white on mauve → copied to `assets/logo.png`.

There is **no product codebase** — the source material is a brand + presentation spec. The primary deliverable surface is therefore the **slide kit** (`slides/`), plus reusable web/UI primitives in `components/core/`.

---

## CONTENT FUNDAMENTALS — how nice ioi writes

- **Language:** Traditional Chinese (Taiwan, 繁體中文), often with light English sub-labels (e.g. *Soft, clean, with warmth*).
- **Tone:** warm, gentle, reassuring, friendly — like a thoughtful friend, not a brand shouting. "溫柔" (gentle/tender) is a recurring value word.
- **Person:** speaks *to* and *about* the customer's everyday feelings ("讓日常的每一天，都能美得自在"), rarely first-person corporate "we".
- **Sentence shape:** short, soft, sensory. Leads with feeling (柔軟、舒服、自在、親膚), then the practical reason. Em-pause with "、" and "，"; ends land softly, not with hype.
- **Casing & punctuation:** lowercase wordmark `niceioi`. Numbers/prices in plain Arabic numerals (NT$590–1,290). Uses "·" as a soft separator in taglines.
- **Emoji:** **not used** in product/marketing copy. ✓ / ✕ appear only as Do/Don't markers in internal docs, and ★ (deep-rose) as a quality/rating mark.
- **Avoid:** hard-sell superlatives, cold corporate jargon, exclamation spam, aggressive urgency.
- **Examples:**
  - 主張: 「柔軟，是一種被好好對待的感覺。」
  - 賣點: 「精選韓系面料，貼身不悶、久穿也舒服。」
  - 標題: 「為什麼選 nice ioi」/「本季決策清單」

---

## VISUAL FOUNDATIONS

- **Colour vibe:** warm and soft throughout. Mauve-pink (`#E1BAC7` 藕粉) is the hero — used as **fills, header bands and accents, never as body text** (too light to read). Deep rose (`#C98BA0`) carries text contrast, icons and ★. Headings/body are warm dark-grey (`#3A3A3A`), captions warm-grey (`#9A8A90`). Pages are **white-first**; large areas may take a barely-there pink wash (`#FBF5F7`).
- **Type:** Noto Sans TC only. Headings **600** (medium — "中粗、不過硬", never hard/black), body **400**, strong **500**. Airy body leading (1.7). Display scale is large for decks (84/52/34/26/20px); stat numbers go huge (132–200px) in deep rose.
- **Roundness is the identity.** Radii are generous: cards **18px**, base **12px**, pills **999px**. Sharp/square corners are off-brand.
- **Backgrounds:** flat colour — white, light-pink wash, or a solid mauve band. **No gradients, no photographic full-bleed by default, no textures/patterns.** Mauve is introduced as a **header band** or a **light-pink base card**, never by flooding a whole page in pink.
- **Cards:** white or `--ds-surface` tint, 18px radius, 1.5px `--ds-line` border, soft **warm** shadow (`0 6px 20px rgba(201,139,160,0.12)`). Optional mauve header band with white heading text is the signature treatment.
- **Shadows:** low, soft, always tinted with the rose hue (never neutral grey/black). Three steps: soft → card → pop (hover).
- **Borders & rules:** 1.5px, in soft pink `#F0E1E6`. Hairline, never heavy.
- **Pills / tags:** fully rounded capsules — mauve fill + white text (solid), tint + deep-rose (soft), or outlined (line).
- **Hover:** primary fills darken mauve → deep-rose; ghost/secondary gain a soft pink surface; cards lift ~3px and deepen the warm shadow.
- **Press:** gentle `scale(0.97)` — a soft squish, no harsh state change.
- **Motion:** gentle ease-out (`cubic-bezier(0.22,0.61,0.36,1)`), ~200ms. Fades and small lifts; **no bounces, no flashy animation.** Calm and warm.
- **Transparency / blur:** essentially unused — the brand is clean and opaque, not glassy.
- **Layout rules:** ample whitespace, **one focal point per page/slide** ("一頁一重點"). Highlight rows/columns sit on light-pink tint (`--ds-primary-tint`).

### Do / Don't
- ✅ mauve bands, rounded corners, deep-rose accents, warm soft shadows, white-first, airy, one idea per view.
- ❌ large solid black, hard contrast, cold corporate blue-grey, sharp square corners, pink as readable body text, gradients, glassmorphism, emoji.

---

## ICONOGRAPHY

The source material ships **no icon set**. nice ioi's iconography is intentionally minimal:
- **★ (star)** in deep rose — the brand's primary glyph, for ratings, quality marks and matrix highlights. Implemented as an inline SVG path in `StarRating` and the slide kit (filled `--ds-primary-deep`).
- **✓ tick** inside rounded deep-rose boxes — for checklists / decision lists (`Checkbox`, `ChecklistSlide`).
- **✓ / ✕** as plain Do/Don't markers in docs only.
- **No emoji**, no icon font, no PNG icon set. Unicode `★` may be used inline in light contexts.

**If a future surface needs a broader icon set,** substitute **Lucide** (https://lucide.dev) — thin, rounded-cap strokes match the soft aesthetic — and render icons in `--ds-primary-deep`. This is a *recommended substitution*, not part of the original brand; flag it when used.

---

## Index / manifest

**Root**
- `styles.css` — global entry (consumers link this). `@import` lines only.
- `tokens/` — `fonts.css` (Noto Sans TC), `colors.css`, `typography.css`, `shape.css`.
- `assets/logo.png` — niceioi wordmark.
- `readme.md` — this guide. · `SKILL.md` — Agent-Skill wrapper.

**Components** (`components/core/`) — React primitives, exported under the bundle namespace:
- `Button` · `Pill` · `Card` · `Checkbox` · `StarRating` (+ `.d.ts`, `.prompt.md`, `core.card.html`).

**Slide kit** (`slides/`) — 1280×720 deck components: `TitleSlide`, `ThreeColumnSlide`, `MatrixSlide`, `ChecklistSlide`, `StatSlide`, `QuoteSlide` (shared frame in `Slide.jsx`; gallery in `index.html`).

**Foundation cards** (`guidelines/`) — specimen HTML for the Design System tab: colours, type, shape, spacing, brand motifs, Do/Don't.

> The Design System tab renders every `@dsCard`-tagged HTML; the Starting Points picker offers `Button` and `Card`.
