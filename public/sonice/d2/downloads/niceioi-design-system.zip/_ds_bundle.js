/* @ds-bundle: {"format":3,"namespace":"NiceIoiDesignSystem_8f0e7c","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Pill","sourcePath":"components/core/Pill.jsx"},{"name":"StarRating","sourcePath":"components/core/StarRating.jsx"}],"sourceHashes":{"components/core/Button.jsx":"feaf5cf7dd9d","components/core/Card.jsx":"884774996700","components/core/Checkbox.jsx":"ab342af04098","components/core/Pill.jsx":"2f8612ada30d","components/core/StarRating.jsx":"a1e419e858d8","slides/ChecklistSlide.jsx":"c1f570021b29","slides/MatrixSlide.jsx":"4911122bfe08","slides/QuoteSlide.jsx":"8af27dd2237a","slides/Slide.jsx":"ae64780c45ea","slides/StatSlide.jsx":"c5b54451fb57","slides/ThreeColumnSlide.jsx":"9fb4a1cbe02a","slides/TitleSlide.jsx":"f51a7002fdd1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NiceIoiDesignSystem_8f0e7c = window.NiceIoiDesignSystem_8f0e7c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * nice ioi Button — rounded (pill), warm, soft.
 * Variants: primary (mauve fill, white text), secondary (pink-tint), ghost (text + soft hover).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 18px',
      fontSize: 14
    },
    md: {
      padding: '12px 28px',
      fontSize: 16
    },
    lg: {
      padding: '16px 40px',
      fontSize: 18
    }
  };
  const variants = {
    primary: {
      background: 'var(--ds-primary)',
      color: 'var(--ds-on-primary)',
      border: '1.5px solid var(--ds-primary)'
    },
    secondary: {
      background: 'var(--ds-surface)',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid var(--ds-line)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid transparent'
    }
  };
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const hoverFx = {
    primary: {
      background: 'var(--ds-primary-deep)',
      borderColor: 'var(--ds-primary-deep)'
    },
    secondary: {
      background: 'var(--ds-primary-tint)'
    },
    ghost: {
      background: 'var(--ds-surface)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      fontFamily: 'var(--ds-font-body)',
      fontWeight: 'var(--ds-weight-strong)',
      borderRadius: 'var(--ds-radius-pill)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'background var(--ds-dur) var(--ds-ease), transform var(--ds-dur) var(--ds-ease)',
      transform: press && !disabled ? 'scale(0.97)' : 'scale(1)',
      whiteSpace: 'nowrap',
      lineHeight: 1,
      ...sizes[size],
      ...variants[variant],
      ...(hover && !disabled ? hoverFx[variant] : null),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * nice ioi Card — large rounded corners, soft warm shadow. Optional mauve header
 * band (the brand's signature cover/section treatment).
 */
function Card({
  children,
  band,
  tint = false,
  hoverable = false,
  style,
  bodyStyle,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: tint ? 'var(--ds-surface)' : 'var(--ds-bg)',
      borderRadius: 'var(--ds-radius-card)',
      border: '1.5px solid var(--ds-line)',
      boxShadow: hover && hoverable ? 'var(--ds-shadow-pop)' : 'var(--ds-shadow-card)',
      overflow: 'hidden',
      transition: 'box-shadow var(--ds-dur) var(--ds-ease), transform var(--ds-dur) var(--ds-ease)',
      transform: hover && hoverable ? 'translateY(-3px)' : 'none',
      ...style
    }
  }, rest), band ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--ds-primary)',
      color: 'var(--ds-on-primary)',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 'var(--ds-weight-heading)',
      fontSize: 18,
      padding: '14px 22px'
    }
  }, band) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * nice ioi Checkbox — rounded (soft square) checkbox, deep-rose when checked.
 * Controlled via `checked` + `onChange`, or uncontrolled with `defaultChecked`.
 */
function Checkbox({
  checked,
  defaultChecked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [inner, setInner] = React.useState(defaultChecked);
  const on = isControlled ? checked : inner;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInner(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    onClick: toggle,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      fontFamily: 'var(--ds-font-body)',
      fontSize: 16,
      color: 'var(--ds-body)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      flex: '0 0 auto',
      borderRadius: 8,
      border: on ? '1.5px solid var(--ds-primary-deep)' : '1.5px solid var(--ds-line)',
      background: on ? 'var(--ds-primary-deep)' : 'var(--ds-bg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--ds-dur) var(--ds-ease)'
    }
  }, on ? /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 7.5L5.5 10.5L11.5 3.5",
    stroke: "#fff",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })) : null), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/Pill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * nice ioi Pill / Tag — capsule label. tone "solid" = mauve fill + white text,
 * "soft" = light-pink tint + deep-rose text, "line" = outlined.
 */
function Pill({
  children,
  tone = 'solid',
  size = 'md',
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '3px 12px',
      fontSize: 12
    },
    md: {
      padding: '5px 16px',
      fontSize: 14
    }
  };
  const tones = {
    solid: {
      background: 'var(--ds-primary)',
      color: 'var(--ds-on-primary)',
      border: '1.5px solid var(--ds-primary)'
    },
    soft: {
      background: 'var(--ds-surface)',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid var(--ds-line)'
    },
    line: {
      background: 'transparent',
      color: 'var(--ds-primary-deep)',
      border: '1.5px solid var(--ds-primary)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--ds-font-body)',
      fontWeight: 'var(--ds-weight-strong)',
      borderRadius: 'var(--ds-radius-pill)',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      ...sizes[size],
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Pill.jsx", error: String((e && e.message) || e) }); }

// components/core/StarRating.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * nice ioi StarRating — deep-rose ★ rating. Read-only display by default; pass
 * `onRate` to make it interactive. Supports halves in display via `value`.
 */
function StarRating({
  value = 5,
  max = 5,
  size = 22,
  onRate,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(null);
  const shown = hover !== null ? hover : value;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      gap: 4,
      ...style
    }
  }, rest), Array.from({
    length: max
  }).map((_, i) => {
    const fill = shown >= i + 1 ? 1 : shown >= i + 0.5 ? 0.5 : 0;
    const id = `half-${i}-${Math.random().toString(36).slice(2, 7)}`;
    return /*#__PURE__*/React.createElement("svg", {
      key: i,
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      onMouseEnter: onRate ? () => setHover(i + 1) : undefined,
      onMouseLeave: onRate ? () => setHover(null) : undefined,
      onClick: onRate ? () => onRate(i + 1) : undefined,
      style: {
        cursor: onRate ? 'pointer' : 'default'
      }
    }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
      id: id
    }, /*#__PURE__*/React.createElement("stop", {
      offset: `${fill * 100}%`,
      stopColor: "var(--ds-primary-deep)"
    }), /*#__PURE__*/React.createElement("stop", {
      offset: `${fill * 100}%`,
      stopColor: "var(--ds-line)"
    }))), /*#__PURE__*/React.createElement("path", {
      d: "M12 2.5l2.9 5.9 6.5.95-4.7 4.58 1.1 6.47L12 17.4l-5.8 3.07 1.1-6.47L2.6 9.4l6.5-.95L12 2.5z",
      fill: `url(#${id})`
    }));
  }));
}
Object.assign(__ds_scope, { StarRating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StarRating.jsx", error: String((e && e.message) || e) }); }

// slides/ChecklistSlide.jsx
try { (() => {
/* ChecklistSlide — Slide, Eyebrow are global. */

const ChecklistTick = () => /*#__PURE__*/React.createElement("span", {
  style: {
    width: 32,
    height: 32,
    flex: '0 0 auto',
    borderRadius: 10,
    background: 'var(--ds-primary-deep)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
}, /*#__PURE__*/React.createElement("svg", {
  width: "18",
  height: "18",
  viewBox: "0 0 14 14",
  fill: "none"
}, /*#__PURE__*/React.createElement("path", {
  d: "M2.5 7.5L5.5 10.5L11.5 3.5",
  stroke: "#fff",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
})));

/** Decision checklist — rounded checkboxes, deep-rose ticks. */
function ChecklistSlide({
  eyebrow = '上市前確認',
  title = '本季決策清單',
  items = ['主打色：藕粉系 3 款，已定樣', '面料供應商：韓廠確認交期', '定價區間：NT$590–1,290', '視覺：圓角、色帶、深玫瑰點綴', '通路：官網 + 三間實體門市']
}) {
  return /*#__PURE__*/React.createElement(Slide, null, /*#__PURE__*/React.createElement(Eyebrow, null, eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 48,
      color: 'var(--ds-ink)',
      marginBottom: 36
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      background: i === 0 ? 'var(--ds-surface)' : 'var(--ds-bg)',
      border: '1.5px solid var(--ds-line)',
      borderRadius: 'var(--ds-radius)',
      padding: '18px 26px'
    }
  }, /*#__PURE__*/React.createElement(ChecklistTick, null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 23,
      color: 'var(--ds-body)'
    }
  }, it)))));
}
Object.assign(window, {
  ChecklistSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/ChecklistSlide.jsx", error: String((e && e.message) || e) }); }

// slides/MatrixSlide.jsx
try { (() => {
/* MatrixSlide — Slide, Eyebrow are global. */

const MatrixStar = ({
  on
}) => /*#__PURE__*/React.createElement("svg", {
  width: "22",
  height: "22",
  viewBox: "0 0 24 24",
  style: {
    display: 'inline-block'
  }
}, /*#__PURE__*/React.createElement("path", {
  d: "M12 2.5l2.9 5.9 6.5.95-4.7 4.58 1.1 6.47L12 17.4l-5.8 3.07 1.1-6.47L2.6 9.4l6.5-.95L12 2.5z",
  fill: on ? 'var(--ds-primary-deep)' : 'var(--ds-line)'
}));

/** Rounded comparison matrix — ★ deep-rose, highlight column on light pink. */
function MatrixSlide({
  eyebrow = '比較',
  title = 'nice ioi vs 一般快時尚',
  cols = ['面料品質', '剪裁版型', '入手價格', '退換貼心'],
  rows = [{
    name: 'nice ioi',
    highlight: true,
    scores: [5, 5, 4, 5]
  }, {
    name: '一般快時尚',
    highlight: false,
    scores: [3, 3, 5, 2]
  }]
}) {
  return /*#__PURE__*/React.createElement(Slide, null, /*#__PURE__*/React.createElement(Eyebrow, null, eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 48,
      color: 'var(--ds-ink)',
      marginBottom: 40
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1.5px solid var(--ds-line)',
      borderRadius: 'var(--ds-radius-card)',
      overflow: 'hidden',
      boxShadow: 'var(--ds-shadow-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `220px repeat(${cols.length}, 1fr)`,
      background: 'var(--ds-surface)',
      borderBottom: '1.5px solid var(--ds-line)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 28px'
    }
  }), cols.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '20px 16px',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 19,
      color: 'var(--ds-ink)',
      textAlign: 'center'
    }
  }, c))), rows.map((r, ri) => /*#__PURE__*/React.createElement("div", {
    key: ri,
    style: {
      display: 'grid',
      gridTemplateColumns: `220px repeat(${cols.length}, 1fr)`,
      background: r.highlight ? 'var(--ds-primary-tint)' : 'var(--ds-bg)',
      borderBottom: ri < rows.length - 1 ? '1.5px solid var(--ds-line)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 22,
      color: r.highlight ? 'var(--ds-primary-deep)' : 'var(--ds-body)',
      display: 'flex',
      alignItems: 'center'
    }
  }, r.name), r.scores.map((s, si) => /*#__PURE__*/React.createElement("div", {
    key: si,
    style: {
      padding: '24px 8px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 2
    }
  }, Array.from({
    length: 5
  }).map((_, k) => /*#__PURE__*/React.createElement(MatrixStar, {
    key: k,
    on: k < s
  }))))))));
}
Object.assign(window, {
  MatrixSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/MatrixSlide.jsx", error: String((e && e.message) || e) }); }

// slides/QuoteSlide.jsx
try { (() => {
/* QuoteSlide — Wordmark is global. */

/** Big-quote slide — mauve band accent, soft heading-weight quote on white. */
function QuoteSlide({
  quote = '柔軟，是一種被好好對待的感覺。',
  attribution = '— nice ioi 品牌主張'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1280,
      height: 720,
      background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      padding: '0 110px',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      height: 8,
      borderRadius: 999,
      background: 'var(--ds-primary)',
      marginBottom: 40
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 64,
      lineHeight: 1.35,
      color: 'var(--ds-ink)',
      letterSpacing: '-0.01em',
      maxWidth: 940
    }
  }, quote), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      color: 'var(--ds-primary-deep)',
      marginTop: 36,
      fontWeight: 500
    }
  }, attribution), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 72,
      bottom: 56
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 20,
    color: "var(--ds-muted)"
  })));
}
Object.assign(window, {
  QuoteSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/QuoteSlide.jsx", error: String((e && e.message) || e) }); }

// slides/Slide.jsx
try { (() => {
/* nice ioi slide kit — shared frame + bits. React is global (UMD). */

/** Shared 1280×720 slide frame — white page, soft padding. */
function Slide({
  children,
  pad = 72,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1280,
      height: 720,
      background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)',
      color: 'var(--ds-body)',
      position: 'relative',
      overflow: 'hidden',
      boxSizing: 'border-box',
      padding: pad,
      ...style
    }
  }, children);
}

/** Small mauve eyebrow label above a heading. */
function Eyebrow({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-block',
      color: 'var(--ds-primary-deep)',
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: '0.14em',
      marginBottom: 18,
      whiteSpace: 'nowrap'
    }
  }, children);
}

/** niceioi wordmark, deep-rose on white. */
function Wordmark({
  size = 26,
  color = 'var(--ds-primary-deep)'
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: size,
      color,
      letterSpacing: '-0.01em'
    }
  }, "niceioi");
}
Object.assign(window, {
  Slide,
  Eyebrow,
  Wordmark
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/Slide.jsx", error: String((e && e.message) || e) }); }

// slides/StatSlide.jsx
try { (() => {
/* StatSlide — Wordmark is global. */

/** Big-stat slide — mauve wash, oversized deep-rose number. */
function StatSlide({
  stat = '92%',
  label = '回購率',
  detail = '穿過一次就回來的溫柔，是 nice ioi 最在意的事。'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1280,
      height: 720,
      background: 'var(--ds-surface)',
      fontFamily: 'var(--ds-font-body)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      padding: 72,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 200,
      lineHeight: 1,
      color: 'var(--ds-primary-deep)',
      letterSpacing: '-0.02em'
    }
  }, stat), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 40,
      color: 'var(--ds-ink)',
      marginTop: 16
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      color: 'var(--ds-muted)',
      marginTop: 22,
      maxWidth: 680,
      lineHeight: 1.7
    }
  }, detail), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 20,
    color: "var(--ds-primary)"
  })));
}
Object.assign(window, {
  StatSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/StatSlide.jsx", error: String((e && e.message) || e) }); }

// slides/ThreeColumnSlide.jsx
try { (() => {
/* ThreeColumnSlide — Slide, Eyebrow are global. */

/** Three-column feature cards — white/tint, large radius, deep-rose icon dot. */
function ThreeColumnSlide({
  eyebrow = '品牌主張',
  title = '為什麼選 nice ioi',
  items = [{
    tag: '面料',
    head: '柔軟親膚',
    body: '精選韓系面料，貼身不悶、久穿也舒服。'
  }, {
    tag: '剪裁',
    head: '俐落溫柔',
    body: '修飾身形的版型，日常也能穿出比例。'
  }, {
    tag: '價格',
    head: '友善入手',
    body: '品質與價格的剛好平衡，溫柔不負擔。'
  }]
}) {
  return /*#__PURE__*/React.createElement(Slide, null, /*#__PURE__*/React.createElement(Eyebrow, null, eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 48,
      color: 'var(--ds-ink)',
      marginBottom: 40
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 28
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: i === 0 ? 'var(--ds-surface)' : 'var(--ds-bg)',
      border: '1.5px solid var(--ds-line)',
      borderRadius: 'var(--ds-radius-card)',
      boxShadow: 'var(--ds-shadow-card)',
      padding: 32,
      minHeight: 280,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      alignSelf: 'flex-start',
      background: 'var(--ds-primary)',
      color: '#fff',
      fontWeight: 500,
      fontSize: 16,
      padding: '5px 16px',
      borderRadius: 999,
      marginBottom: 22
    }
  }, it.tag), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 30,
      color: 'var(--ds-primary-deep)',
      marginBottom: 14
    }
  }, it.head), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      lineHeight: 1.7,
      color: 'var(--ds-body)'
    }
  }, it.body)))));
}
Object.assign(window, {
  ThreeColumnSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/ThreeColumnSlide.jsx", error: String((e && e.message) || e) }); }

// slides/TitleSlide.jsx
try { (() => {
/* TitleSlide — Wordmark is global. */

/** Cover slide — signature mauve band with white wordmark, title below on white. */
function TitleSlide({
  wordmark = 'niceioi',
  title = '2025 春夏新品提案',
  subtitle = '韓系品質女裝 · 藕粉、圓潤、溫暖'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1280,
      height: 720,
      background: 'var(--ds-bg)',
      fontFamily: 'var(--ds-font-body)',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--ds-primary)',
      color: 'var(--ds-on-primary)',
      padding: '40px 72px',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 40,
      letterSpacing: '-0.01em'
    }
  }, wordmark)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      padding: '0 72px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 600,
      fontSize: 76,
      lineHeight: 1.12,
      color: 'var(--ds-ink)',
      letterSpacing: '-0.01em'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      color: 'var(--ds-muted)',
      marginTop: 24,
      lineHeight: 1.6
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 72px 48px',
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    size: 20,
    color: "var(--ds-muted)"
  })));
}
Object.assign(window, {
  TitleSlide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/TitleSlide.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.StarRating = __ds_scope.StarRating;

})();
