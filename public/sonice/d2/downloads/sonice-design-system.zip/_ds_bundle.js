/* @ds-bundle: {"format":3,"namespace":"SONICEDesignSystem_edf344","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"ChecklistItem","sourcePath":"components/core/ChecklistItem.jsx"},{"name":"Rule","sourcePath":"components/core/Rule.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Swatch","sourcePath":"components/core/Swatch.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"cbd558fa4d95","components/core/Button.jsx":"75789d5a8b35","components/core/Card.jsx":"8ec4d504c28a","components/core/ChecklistItem.jsx":"cee2684f6bbc","components/core/Rule.jsx":"00a56fb47bc9","components/core/Stat.jsx":"35aa7b29710c","components/core/Swatch.jsx":"160028ab22d3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SONICEDesignSystem_edf344 = window.SONICEDesignSystem_edf344 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Badge / Tag
 * Tiny uppercase label. Square, hairline. Neutral by default; wine for emphasis.
 */
function Badge({
  children,
  variant = 'default',
  // 'default' | 'accent' | 'outline' | 'solid'
  style,
  ...rest
}) {
  const palette = {
    default: {
      background: 'var(--ds-surface)',
      color: 'var(--ds-body)',
      border: '1px solid var(--ds-line)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--ds-ink)',
      border: '1px solid var(--ds-ink)'
    },
    solid: {
      background: 'var(--ds-ink)',
      color: 'var(--ds-white)',
      border: '1px solid var(--ds-ink)'
    },
    accent: {
      background: 'var(--ds-accent)',
      color: 'var(--ds-white)',
      border: '1px solid var(--ds-accent)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--ds-font-heading)',
      fontWeight: 700,
      fontSize: 11,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      padding: '4px 10px',
      borderRadius: 'var(--ds-radius)',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      ...(palette[variant] || palette.default),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Button
 * Sharp, near-square. Black/white with a single wine accent variant.
 * No shadow, no gradient. Hover darkens; press nudges down 1px.
 */
function Button({
  children,
  variant = 'primary',
  // 'primary' | 'secondary' | 'ghost' | 'accent'
  size = 'md',
  // 'sm' | 'md' | 'lg'
  disabled = false,
  type = 'button',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const sizes = {
    sm: {
      fontSize: 13,
      padding: '8px 16px',
      letterSpacing: '0.06em'
    },
    md: {
      fontSize: 15,
      padding: '12px 24px',
      letterSpacing: '0.06em'
    },
    lg: {
      fontSize: 17,
      padding: '16px 34px',
      letterSpacing: '0.05em'
    }
  };
  const palette = {
    primary: {
      base: {
        background: 'var(--ds-ink)',
        color: 'var(--ds-white)',
        border: '1px solid var(--ds-ink)'
      },
      hover: {
        background: 'var(--ds-black)',
        borderColor: 'var(--ds-black)'
      }
    },
    secondary: {
      base: {
        background: 'var(--ds-white)',
        color: 'var(--ds-ink)',
        border: '1px solid var(--ds-ink)'
      },
      hover: {
        background: 'var(--ds-ink)',
        color: 'var(--ds-white)'
      }
    },
    ghost: {
      base: {
        background: 'transparent',
        color: 'var(--ds-ink)',
        border: '1px solid transparent'
      },
      hover: {
        background: 'var(--ds-surface)'
      }
    },
    accent: {
      base: {
        background: 'var(--ds-accent)',
        color: 'var(--ds-white)',
        border: '1px solid var(--ds-accent)'
      },
      hover: {
        background: 'var(--ds-accent-deep)',
        borderColor: 'var(--ds-accent-deep)'
      }
    }
  };
  const p = palette[variant] || palette.primary;
  const composed = {
    fontFamily: 'var(--ds-font-heading)',
    fontWeight: 700,
    textTransform: 'uppercase',
    borderRadius: 'var(--ds-radius)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background 120ms ease, color 120ms ease, transform 80ms ease',
    transform: active && !disabled ? 'translateY(1px)' : 'none',
    lineHeight: 1,
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...p.base,
    ...(hover && !disabled ? p.hover : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: composed
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Card
 * White face, grey hairline border, sharp corners. No shadow.
 * Optional 2px black top rule for emphasis (topRule).
 */
function Card({
  children,
  topRule = false,
  accentRule = false,
  // wine rule instead of black
  style,
  ...rest
}) {
  const ruleColor = accentRule ? 'var(--ds-accent)' : 'var(--ds-black)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--ds-surface-card)',
      border: '1px solid var(--ds-line)',
      borderTop: topRule || accentRule ? `var(--ds-rule) solid ${ruleColor}` : '1px solid var(--ds-line)',
      borderRadius: 'var(--ds-radius-card)',
      padding: 'var(--ds-pad-card)',
      color: 'var(--ds-body)',
      fontFamily: 'var(--ds-font-body)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/ChecklistItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — ChecklistItem
 * Square box □ + black label (the deck "決策清單"). Sharp, no rounding.
 * Checked shows a filled near-black box with a white tick.
 */
function ChecklistItem({
  children,
  checked = false,
  accent = false,
  // wine fill when checked
  style,
  ...rest
}) {
  const fill = accent ? 'var(--ds-accent)' : 'var(--ds-ink)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 14,
      fontFamily: 'var(--ds-font-body)',
      fontSize: 18,
      lineHeight: 1.4,
      color: 'var(--ds-body)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 20,
      height: 20,
      marginTop: 2,
      borderRadius: 'var(--ds-radius)',
      border: checked ? `1px solid ${fill}` : '1px solid var(--ds-ink)',
      background: checked ? fill : 'transparent',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--ds-white)',
      fontSize: 13,
      fontWeight: 900
    }
  }, checked ? '✓' : ''), /*#__PURE__*/React.createElement("span", {
    style: {
      color: checked ? 'var(--ds-ink)' : 'var(--ds-body)'
    }
  }, children));
}
Object.assign(__ds_scope, { ChecklistItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ChecklistItem.jsx", error: String((e && e.message) || e) }); }

// components/core/Rule.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Rule
 * A divider line. Black 2px by default (the signature sharp rule),
 * or grey hairline, or wine. Horizontal or vertical.
 */
function Rule({
  weight = 'rule',
  // 'rule' (2px black) | 'hair' (1px grey) | 'accent' (2px wine)
  vertical = false,
  length,
  // e.g. 64 or '100%'
  style,
  ...rest
}) {
  const map = {
    rule: {
      color: 'var(--ds-black)',
      thick: 2
    },
    hair: {
      color: 'var(--ds-line)',
      thick: 1
    },
    accent: {
      color: 'var(--ds-accent)',
      thick: 2
    }
  };
  const w = map[weight] || map.rule;
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      display: 'inline-block',
      background: w.color,
      ...(vertical ? {
        width: w.thick,
        height: length ?? '100%'
      } : {
        height: w.thick,
        width: length ?? '100%'
      }),
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Rule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Rule.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Stat
 * The signature "大數字": one huge near-black numeral + a single grey caption.
 * Optionally render the figure in wine (use at most once per surface).
 */
function Stat({
  value,
  caption,
  prefix,
  suffix,
  accent = false,
  align = 'left',
  // 'left' | 'center'
  size = 96,
  // px of the numeral
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      fontFamily: 'var(--ds-font-heading)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: size,
      lineHeight: 0.95,
      letterSpacing: '-0.02em',
      color: accent ? 'var(--ds-accent)' : 'var(--ds-ink)',
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: align === 'center' ? 'center' : 'flex-start',
      gap: 4
    }
  }, prefix ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.42em',
      fontWeight: 800
    }
  }, prefix) : null, /*#__PURE__*/React.createElement("span", null, value), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.42em',
      fontWeight: 800
    }
  }, suffix) : null), caption ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      fontWeight: 400,
      fontSize: Math.max(14, size * 0.18),
      color: 'var(--ds-muted)',
      letterSpacing: '0.02em'
    }
  }, caption) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Swatch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SO NICE — Swatch
 * A square color block with hex/label beneath. No rounding by default.
 * Used in color-story slides (FW 酒紅 ↔ 茄紫).
 */
function Swatch({
  color,
  name,
  hex,
  size = 96,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      fontFamily: 'var(--ds-font-body)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      background: color,
      borderRadius: 'var(--ds-radius)',
      border: '1px solid var(--ds-line)'
    }
  }), name || hex ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, name ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13,
      color: 'var(--ds-ink)',
      letterSpacing: '0.02em'
    }
  }, name) : null, hex ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--ds-font-latin)',
      fontSize: 12,
      color: 'var(--ds-muted)',
      letterSpacing: '0.04em'
    }
  }, hex) : null) : null);
}
Object.assign(__ds_scope, { Swatch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Swatch.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ChecklistItem = __ds_scope.ChecklistItem;

__ds_ns.Rule = __ds_scope.Rule;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Swatch = __ds_scope.Swatch;

})();
