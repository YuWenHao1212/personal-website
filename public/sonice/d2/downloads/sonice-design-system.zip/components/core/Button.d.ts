import * as React from 'react';

/** SO NICE — Button. Sharp black/white action with a single wine accent variant. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** Visual style. @default 'primary' */
  variant?: 'primary' | 'secondary' | 'ghost' | 'accent';
  /** @default 'md' */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
}

export function Button(props: ButtonProps): JSX.Element;
