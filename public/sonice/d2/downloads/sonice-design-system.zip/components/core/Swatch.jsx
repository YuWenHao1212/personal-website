import React from 'react';

/**
 * SO NICE — Swatch
 * A square color block with hex/label beneath. No rounding by default.
 * Used in color-story slides (FW 酒紅 ↔ 茄紫).
 */
export function Swatch({
  color,
  name,
  hex,
  size = 96,
  style,
  ...rest
}) {
  return (
    <div style={{ fontFamily: 'var(--ds-font-body)', ...style }} {...rest}>
      <div
        style={{
          width: size,
          height: size,
          background: color,
          borderRadius: 'var(--ds-radius)',
          border: '1px solid var(--ds-line)',
        }}
      />
      {(name || hex) ? (
        <div style={{ marginTop: 10 }}>
          {name ? (
            <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--ds-ink)', letterSpacing: '0.02em' }}>
              {name}
            </div>
          ) : null}
          {hex ? (
            <div style={{ fontFamily: 'var(--ds-font-latin)', fontSize: 12, color: 'var(--ds-muted)', letterSpacing: '0.04em' }}>
              {hex}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
