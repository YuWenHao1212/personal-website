import React from 'react';

/**
 * SO NICE — Card
 * White face, grey hairline border, sharp corners. No shadow.
 * Optional 2px black top rule for emphasis (topRule).
 */
export function Card({
  children,
  topRule = false,
  accentRule = false,   // wine rule instead of black
  style,
  ...rest
}) {
  const ruleColor = accentRule ? 'var(--ds-accent)' : 'var(--ds-black)';
  return (
    <div
      style={{
        background: 'var(--ds-surface-card)',
        border: '1px solid var(--ds-line)',
        borderTop: (topRule || accentRule) ? `var(--ds-rule) solid ${ruleColor}` : '1px solid var(--ds-line)',
        borderRadius: 'var(--ds-radius-card)',
        padding: 'var(--ds-pad-card)',
        color: 'var(--ds-body)',
        fontFamily: 'var(--ds-font-body)',
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
