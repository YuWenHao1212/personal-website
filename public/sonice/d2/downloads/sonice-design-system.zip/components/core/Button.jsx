import React from 'react';

/**
 * SO NICE — Button
 * Sharp, near-square. Black/white with a single wine accent variant.
 * No shadow, no gradient. Hover darkens; press nudges down 1px.
 */
export function Button({
  children,
  variant = 'primary',   // 'primary' | 'secondary' | 'ghost' | 'accent'
  size = 'md',           // 'sm' | 'md' | 'lg'
  disabled = false,
  type = 'button',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);

  const sizes = {
    sm: { fontSize: 13, padding: '8px 16px', letterSpacing: '0.06em' },
    md: { fontSize: 15, padding: '12px 24px', letterSpacing: '0.06em' },
    lg: { fontSize: 17, padding: '16px 34px', letterSpacing: '0.05em' },
  };

  const palette = {
    primary: {
      base: { background: 'var(--ds-ink)', color: 'var(--ds-white)', border: '1px solid var(--ds-ink)' },
      hover: { background: 'var(--ds-black)', borderColor: 'var(--ds-black)' },
    },
    secondary: {
      base: { background: 'var(--ds-white)', color: 'var(--ds-ink)', border: '1px solid var(--ds-ink)' },
      hover: { background: 'var(--ds-ink)', color: 'var(--ds-white)' },
    },
    ghost: {
      base: { background: 'transparent', color: 'var(--ds-ink)', border: '1px solid transparent' },
      hover: { background: 'var(--ds-surface)' },
    },
    accent: {
      base: { background: 'var(--ds-accent)', color: 'var(--ds-white)', border: '1px solid var(--ds-accent)' },
      hover: { background: 'var(--ds-accent-deep)', borderColor: 'var(--ds-accent-deep)' },
    },
  };

  const p = palette[variant] || palette.primary;

  const composed = {
    fontFamily: 'var(--ds-font-heading)',
    fontWeight: 700,
    textTransform: 'uppercase',
    borderRadius: 'var(--ds-radius)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background 120ms ease, color 120ms ease, transform 80ms ease',
    transform: active && !disabled ? 'translateY(1px)' : 'none',
    lineHeight: 1,
    whiteSpace: 'nowrap',
    ...sizes[size],
    ...p.base,
    ...(hover && !disabled ? p.hover : null),
    ...style,
  };

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={composed}
      {...rest}
    >
      {children}
    </button>
  );
}
