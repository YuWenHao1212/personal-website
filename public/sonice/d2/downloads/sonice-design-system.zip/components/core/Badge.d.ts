import * as React from 'react';

/** SO NICE — Badge / Tag. Tiny uppercase hairline label; wine variant for emphasis. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** @default 'default' */
  variant?: 'default' | 'accent' | 'outline' | 'solid';
}

export function Badge(props: BadgeProps): JSX.Element;
