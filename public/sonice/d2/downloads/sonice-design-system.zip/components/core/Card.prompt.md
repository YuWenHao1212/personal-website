White, hairline-bordered container with sharp corners and no shadow — the base surface for grouped content (the deck "三欄卡" / three-column card).

```jsx
<Card topRule>
  <h3>Tailoring</h3>
  <p>Structured shoulders, clean drape.</p>
</Card>
<Card accentRule>…</Card>
```

Props: `topRule` adds a 2px black rule across the top; `accentRule` makes that rule wine. Never add shadows or full rounding — keep it sharp.
