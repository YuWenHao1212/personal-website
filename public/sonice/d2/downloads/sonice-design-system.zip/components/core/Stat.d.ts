import * as React from 'react';

/** SO NICE — Stat. The signature huge near-black numeral + one grey caption ("大數字"). */
export interface StatProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The figure itself, e.g. "150" or "3.2×". */
  value: React.ReactNode;
  /** One short grey line beneath. */
  caption?: React.ReactNode;
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  /** Render the numeral in wine. Use at most once per surface. @default false */
  accent?: boolean;
  /** @default 'left' */
  align?: 'left' | 'center';
  /** Numeral size in px. @default 96 */
  size?: number;
}

export function Stat(props: StatProps): JSX.Element;
