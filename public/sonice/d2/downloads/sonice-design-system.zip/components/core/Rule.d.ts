import * as React from 'react';

/** SO NICE — Rule. The signature 2px black divider (or grey hairline / wine). Horizontal or vertical. */
export interface RuleProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** @default 'rule' */
  weight?: 'rule' | 'hair' | 'accent';
  /** @default false */
  vertical?: boolean;
  /** CSS length; defaults to 100% of the cross axis. */
  length?: number | string;
}

export function Rule(props: RuleProps): JSX.Element;
