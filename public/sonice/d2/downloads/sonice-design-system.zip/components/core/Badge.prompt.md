Tiny uppercase hairline label for categories, status, or season tags.

```jsx
<Badge>FW2026</Badge>
<Badge variant="accent">NEW</Badge>
<Badge variant="outline">LIMITED</Badge>
<Badge variant="solid">SOLD OUT</Badge>
```

Variants: `default` (grey), `outline` (black hairline), `solid` (near-black fill), `accent` (wine). Always UPPERCASE with wide tracking. Use accent sparingly.
