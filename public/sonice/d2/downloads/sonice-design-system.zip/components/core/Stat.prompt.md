The signature "大數字" — one oversized near-black numeral with a single grey caption beneath. Use to make one key figure the whole point of a surface.

```jsx
<Stat value="150" suffix="px" caption="大數字級別字級" size={140} />
<Stat value="42" suffix="%" caption="回購率" accent />
<Stat value="3.2" suffix="×" caption="客單價成長" align="center" />
```

Props: `value`, `caption`, `prefix`/`suffix` (rendered smaller), `accent` (wine numeral — once per surface), `align`, `size` (px). Keep one Stat dominant per slide.
