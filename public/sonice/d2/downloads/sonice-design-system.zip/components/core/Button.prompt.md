Sharp, near-square action button — black/white with one wine accent variant; use for any primary/secondary action.

```jsx
<Button variant="primary">View Lookbook</Button>
<Button variant="secondary">Sizing</Button>
<Button variant="accent" size="lg">Shop FW2026</Button>
<Button variant="ghost" size="sm">Cancel</Button>
```

Variants: `primary` (near-black fill), `secondary` (white with black border, inverts on hover), `ghost` (text only), `accent` (deep wine — use sparingly, one per surface). Sizes `sm | md | lg`. Always UPPERCASE, weight 700, 4px radius. Hover darkens; press nudges down 1px.
