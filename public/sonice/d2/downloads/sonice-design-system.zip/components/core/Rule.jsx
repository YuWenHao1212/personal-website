import React from 'react';

/**
 * SO NICE — Rule
 * A divider line. Black 2px by default (the signature sharp rule),
 * or grey hairline, or wine. Horizontal or vertical.
 */
export function Rule({
  weight = 'rule',     // 'rule' (2px black) | 'hair' (1px grey) | 'accent' (2px wine)
  vertical = false,
  length,              // e.g. 64 or '100%'
  style,
  ...rest
}) {
  const map = {
    rule:   { color: 'var(--ds-black)', thick: 2 },
    hair:   { color: 'var(--ds-line)', thick: 1 },
    accent: { color: 'var(--ds-accent)', thick: 2 },
  };
  const w = map[weight] || map.rule;
  return (
    <span
      aria-hidden="true"
      style={{
        display: 'inline-block',
        background: w.color,
        ...(vertical
          ? { width: w.thick, height: length ?? '100%' }
          : { height: w.thick, width: length ?? '100%' }),
        ...style,
      }}
      {...rest}
    />
  );
}
