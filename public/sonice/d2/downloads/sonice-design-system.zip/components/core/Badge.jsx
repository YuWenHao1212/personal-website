import React from 'react';

/**
 * SO NICE — Badge / Tag
 * Tiny uppercase label. Square, hairline. Neutral by default; wine for emphasis.
 */
export function Badge({
  children,
  variant = 'default',  // 'default' | 'accent' | 'outline' | 'solid'
  style,
  ...rest
}) {
  const palette = {
    default: { background: 'var(--ds-surface)', color: 'var(--ds-body)', border: '1px solid var(--ds-line)' },
    outline: { background: 'transparent', color: 'var(--ds-ink)', border: '1px solid var(--ds-ink)' },
    solid:   { background: 'var(--ds-ink)', color: 'var(--ds-white)', border: '1px solid var(--ds-ink)' },
    accent:  { background: 'var(--ds-accent)', color: 'var(--ds-white)', border: '1px solid var(--ds-accent)' },
  };

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        fontFamily: 'var(--ds-font-heading)',
        fontWeight: 700,
        fontSize: 11,
        letterSpacing: '0.14em',
        textTransform: 'uppercase',
        padding: '4px 10px',
        borderRadius: 'var(--ds-radius)',
        lineHeight: 1,
        whiteSpace: 'nowrap',
        ...(palette[variant] || palette.default),
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
