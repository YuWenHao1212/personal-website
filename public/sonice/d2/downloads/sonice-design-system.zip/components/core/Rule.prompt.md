The signature sharp divider — 2px black by default, or grey hairline / wine. Used under titles and between blocks.

```jsx
<Rule />                       {/* 2px black */}
<Rule weight="hair" />         {/* 1px grey */}
<Rule weight="accent" length={64} />
<Rule vertical length={48} />
```

Props: `weight` (`rule | hair | accent`), `vertical`, `length`. No shadows or decoration — a rule is just a line.
