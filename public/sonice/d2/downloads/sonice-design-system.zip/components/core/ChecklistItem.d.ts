import * as React from 'react';

/** SO NICE — ChecklistItem. Square box □ + black label (deck "決策清單"); sharp, no rounding. */
export interface ChecklistItemProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** @default false */
  checked?: boolean;
  /** Wine fill when checked instead of near-black. @default false */
  accent?: boolean;
}

export function ChecklistItem(props: ChecklistItemProps): JSX.Element;
