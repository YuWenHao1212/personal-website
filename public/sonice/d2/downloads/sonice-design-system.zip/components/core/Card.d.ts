import * as React from 'react';

/** SO NICE — Card. White face, grey hairline, sharp corners, no shadow. */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** Add a 2px black rule across the top edge. @default false */
  topRule?: boolean;
  /** Use a wine rule instead of black (implies a top rule). @default false */
  accentRule?: boolean;
}

export function Card(props: CardProps): JSX.Element;
