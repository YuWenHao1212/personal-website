Square color block with a hex/label caption — for color stories (e.g. FW 酒紅 ↔ 茄紫).

```jsx
<Swatch color="var(--ds-accent)" name="FW 酒紅" hex="#6E2639" />
<Swatch color="var(--ds-eggplant)" name="茄紫" hex="#3A2235" />
```

Props: `color` (CSS color/var), `name`, `hex`, `size` (px). Keep blocks square — sharp 4px radius only.
