import React from 'react';

/**
 * SO NICE — ChecklistItem
 * Square box □ + black label (the deck "決策清單"). Sharp, no rounding.
 * Checked shows a filled near-black box with a white tick.
 */
export function ChecklistItem({
  children,
  checked = false,
  accent = false,   // wine fill when checked
  style,
  ...rest
}) {
  const fill = accent ? 'var(--ds-accent)' : 'var(--ds-ink)';
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 14,
        fontFamily: 'var(--ds-font-body)',
        fontSize: 18,
        lineHeight: 1.4,
        color: 'var(--ds-body)',
        ...style,
      }}
      {...rest}
    >
      <span
        aria-hidden="true"
        style={{
          flex: '0 0 auto',
          width: 20,
          height: 20,
          marginTop: 2,
          borderRadius: 'var(--ds-radius)',
          border: checked ? `1px solid ${fill}` : '1px solid var(--ds-ink)',
          background: checked ? fill : 'transparent',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--ds-white)',
          fontSize: 13,
          fontWeight: 900,
        }}
      >
        {checked ? '✓' : ''}
      </span>
      <span style={{ color: checked ? 'var(--ds-ink)' : 'var(--ds-body)' }}>{children}</span>
    </div>
  );
}
