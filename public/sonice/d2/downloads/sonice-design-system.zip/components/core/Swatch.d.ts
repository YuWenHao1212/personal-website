import * as React from 'react';

/** SO NICE — Swatch. Square color block with hex/label; used for color-story slides. */
export interface SwatchProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Any CSS color or var(). */
  color: string;
  name?: React.ReactNode;
  hex?: string;
  /** Square size in px. @default 96 */
  size?: number;
}

export function Swatch(props: SwatchProps): JSX.Element;
