import React from 'react';

/**
 * SO NICE — Stat
 * The signature "大數字": one huge near-black numeral + a single grey caption.
 * Optionally render the figure in wine (use at most once per surface).
 */
export function Stat({
  value,
  caption,
  prefix,
  suffix,
  accent = false,
  align = 'left',   // 'left' | 'center'
  size = 96,        // px of the numeral
  style,
  ...rest
}) {
  return (
    <div
      style={{
        textAlign: align,
        fontFamily: 'var(--ds-font-heading)',
        ...style,
      }}
      {...rest}
    >
      <div
        style={{
          fontWeight: 900,
          fontSize: size,
          lineHeight: 0.95,
          letterSpacing: '-0.02em',
          color: accent ? 'var(--ds-accent)' : 'var(--ds-ink)',
          display: 'flex',
          alignItems: 'baseline',
          justifyContent: align === 'center' ? 'center' : 'flex-start',
          gap: 4,
        }}
      >
        {prefix ? <span style={{ fontSize: '0.42em', fontWeight: 800 }}>{prefix}</span> : null}
        <span>{value}</span>
        {suffix ? <span style={{ fontSize: '0.42em', fontWeight: 800 }}>{suffix}</span> : null}
      </div>
      {caption ? (
        <div
          style={{
            marginTop: 12,
            fontWeight: 400,
            fontSize: Math.max(14, size * 0.18),
            color: 'var(--ds-muted)',
            letterSpacing: '0.02em',
          }}
        >
          {caption}
        </div>
      ) : null}
    </div>
  );
}
