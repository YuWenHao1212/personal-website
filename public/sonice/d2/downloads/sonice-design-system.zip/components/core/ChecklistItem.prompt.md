Square checkbox □ + label for decision lists ("決策清單"). Sharp box, near-black tick when checked.

```jsx
<ChecklistItem checked>主推黑白基本款</ChecklistItem>
<ChecklistItem>加入酒紅單品</ChecklistItem>
<ChecklistItem checked accent>FW2026 主色定案</ChecklistItem>
```

Props: `checked`, `accent` (wine fill when checked). Stack several with a consistent gap to form a list.
