# SO NICE — Design System（提案 / 簡報用）

> 品牌：都會時尚女裝 · 成熟精緻 · 黑白極簡。給 Claude Design 用——生出來的 deck 要像 SO NICE 自己出的。

## 如何 sync 進 Claude Design
1. `cd` 到本資料夾 → 開 `claude` → 跑 `/design-sync`。Claude Code 讀 `tokens.css` 建成 design system，org 內所有人可選用。
2. 或：claude.ai/design → Design systems → 上傳 SO NICE logo + 本檔當 spec。

## 識別一句話
**黑、白、留白。** 粗黑大字、銳利線條、唯一一點酒紅。不甜、不花、不圓。

## 配色
| 角色 | hex | 用法 |
|---|---|---|
| 底 | `#FFFFFF` | 純白，永遠大面積留白（≥40%）|
| 主 / 標題 | `#111111` | 近黑，標題、wordmark |
| 內文 | `#3A3A3A` | |
| 次要 | `#8A8A8A` | 註解、來源 |
| 線 | `#E5E5E5` | 細分隔 |
| 強調 | `#6E2639` 深酒紅 | **唯一彩色**，一頁最多一處（呼應 FW2026 主色）|

## 字型
標題 Noto Sans TC **800（粗黑）**；內文 400。Latin 用 Helvetica Neue / Arial。**不用 serif、不用圓體。**

## 版面原則
- 一頁一重點，留白優先。
- 關鍵數字放超大（`--ds-size-stat` 150px 黑體）。
- 標題釘左上、粗黑；payoff 句錨底。
- 線用黑細線（2px）；**不用陰影 / 漸層 / 裝飾**。

## 元件樣式
- **封面**：超大黑 wordmark `SO NICE` + 標題；白底；角落細 logo。
- **大數字**：黑色巨大數字 + 一行灰註解。
- **三欄卡**：白底、細灰框、頂部可選 2px 黑線；不圓不柔。
- **矩陣**：乾淨表格，★ 用酒紅，缺口標酒紅高亮。
- **色票**：方形色塊（FW 酒紅 ↔ 茄紫）。
- **決策清單**：方框 □ + 黑字。

## Do / Don't
- ✅ 白、黑、一點酒紅、大數字、留白、銳利。
- ❌ 多色、漸層、圓角到底、粉色、裝飾線、陰影濫用、serif。
