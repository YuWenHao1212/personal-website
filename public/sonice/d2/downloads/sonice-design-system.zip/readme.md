# SO NICE — Design System

> 都會時尚女裝 · 成熟精緻 · 黑白極簡
> Urban womenswear · mature & refined · black-white minimalism

A presentation-first brand system for **SO NICE**. Decks, mocks, and assets generated from this system should look like SO NICE produced them: **black, white, whitespace — and a single touch of wine red.**

**Identity in one line:** 黑、白、留白. Bold black type, sharp lines, one deep-wine accent. 不甜、不花、不圓 (not sweet, not floral, not round).

---

## Sources

This system was derived from a brand spec supplied as a mounted codebase, copied into `sources/`:
- `sources/sonice-design-system.md` — the original brand/deck spec (Traditional Chinese).
- `sources/sonice-tokens.css` — the original `--ds-*` token definitions (the canonical token names).
- `assets/logo.png` — the SO NICE wordmark (black, transparent PNG, 300×88).

There is **no product application codebase** — SO NICE's system is a brand + **deck/presentation** specification. Accordingly the primary UI kit here is a **sample slide deck** (`slides/`), not an app. Do not invent a product UI; if a web/app surface is needed later, ask for its source.

---

## Content fundamentals

How SO NICE writes copy:

- **Bilingual, Chinese-led.** Headlines are Traditional Chinese, often paired with a short Latin kicker or label (e.g. `FW2026 · Buying Strategy`). Latin is used for wordmark, numerals, units, and section tags.
- **Terse and declarative.** Headlines are short statements, not sentences — `留白優先`, `一季，一個酒紅`, `四件事，今天拍板`. One idea per line.
- **Confident, editorial, unsentimental.** The tone is a buyer/creative-director memo: decisive, mature, a little severe. No hype, no exclamation marks, no emoji.
- **Signature cadence: triplets and negation.** `黑、白、留白` · `不甜、不花、不圓`. Rhythm in threes; define by what it is *not*.
- **Numbers speak.** Key figures are stated bluntly and made huge (`42%`, `3.2×`). Captions beneath are quiet and grey.
- **Casing:** Latin labels are UPPERCASE with wide tracking; Chinese carries the weight through boldness, not caps. Punctuation is full-width in Chinese (`。、`).
- **No emoji, ever.** A wine `★` or `✓`/`□` glyph is the only ornament.

---

## Visual foundations

- **Color.** Greyscale world — pure white ground (`#FFFFFF`, ≥40% of every surface empty), near-black ink (`#111111`), with a graded neutral ramp (surface `#F7F7F7`, line `#E5E5E5`, muted `#8A8A8A`, body `#3A3A3A`, black `#000000`). **Wine red `#6E2639` is the only chromatic color, used at most once per surface** — a star, a highlight, one figure. Eggplant `#3A2235` appears only as the swatch partner, never in layout. No pink, no second hue.
- **Type.** One family does everything: **Noto Sans TC** (CJK), with Helvetica Neue / Arial for Latin. Weight carries hierarchy — 400 body, 700 bold, **800 headings, 900 display/wordmark**. No serif. No rounded faces. Display type is tightly tracked (`-0.02em`); small Latin labels are widely tracked (`0.18em`).
- **Scale.** Deck-tuned: display 92px, H1 56px, body 26px, and a signature **stat at 150px** (all @1920). The big number is a deliberate device — one oversized figure can be the entire slide.
- **Spacing.** 8px base, generous rhythm. Whitespace is the primary design material — `留白優先`. Deck safe margin ~120px on a 1920 frame.
- **Backgrounds.** Flat white (or flat near-black for inverted section dividers). **No images behind type, no gradients, no textures, no patterns.** Photography, if ever used, would sit in its own clean block — never as a wash.
- **Shape / corners.** Sharp, near-square: 0–4px radius default, 8px max on cards. Nothing fully rounded; no pills, no circles (except small dots).
- **Borders & rules.** Two line treatments only: a **2px black rule** (the signature sharp line, also as a card top-edge accent) and a **1px grey hairline** (`#E5E5E5`) for dividers and card borders. A wine rule is allowed once for emphasis.
- **Shadows.** Essentially none. No floating cards, no drop shadows, no glow. Depth comes from the hairline and the rule, not from blur. (`--ds-shadow-card` is at most a single 1px seam.)
- **Transparency / blur.** Avoided in brand surfaces. Slight scrims only in utility chrome (e.g. the sample deck's nav bar), never over content.
- **Animation.** Restrained. No bounce, no decorative motion. If anything moves, a quiet fade or a crisp cut. Buttons: hover **darkens** (ink → black, wine → deep-wine; secondary inverts to fill); press **nudges down 1px** (no scale-bounce). Transitions ~120ms ease.
- **Cards.** White face, 1px grey hairline border, 8px radius, **no shadow**; optional 2px black (or wine) top rule for emphasis. Clean, structural, never soft.
- **Layout rules.** One point per surface. Title pinned top-left and bold; payoff sentence anchored bottom; logo small in a corner. Tables are clean and ruled, with `★` and gap-highlights in wine.

---

## Iconography

SO NICE has **no custom icon set and no icon font** — consistent with its minimalism, iconography is deliberately near-absent.

- **Glyphs, not icons.** The only recurring marks are typographic: a wine `★` (matrix highlight / emphasis), `✓` and `□` (decision lists / checkboxes), `←`/`→` (deck nav), and `—` (list bullets, dashes). These are set in the brand font, not drawn.
- **No emoji.** Never. Emoji read as "甜/花" (sweet/cute) and are off-brand.
- **No decorative line-icons.** Do not introduce Lucide/Heroicons/etc. into brand surfaces. If a UI utility genuinely needs functional icons (e.g. a real app chrome), use a **thin, sharp, monochrome** stroke set (1.5–2px, square caps) in ink — and flag it, since none is specified here.
- **The wordmark is the brand mark.** `assets/logo.png` — bold black "SO NICE" Latin wordmark; knock out to white on dark. Clear space ≥ cap height; never recolor, outline, or condense.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (consumers link this only). `@import` list → fonts + all tokens.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills-compatible front matter for downloadable use.

**Tokens** (`tokens/`) — all `--ds-*` custom properties
- `colors.css` · `typography.css` · `spacing.css` · `shape.css`

**Fonts** (`fonts/`)
- `fonts.css` — Noto Sans TC via Google Fonts (weights 400/500/700/800/900).

**Components** (`components/core/`) — React primitives, exported on `window.SONICEDesignSystem_edf344`
- `Button` · `Badge` · `Card` · `Stat` (大數字) · `Swatch` · `Rule` · `ChecklistItem`
- `core.card.html` — Components-tab specimen.

**Guidelines** (`guidelines/`) — foundation specimen cards (Design System tab): Colors, Type, Spacing, Brand.

**Slides** (`slides/`) — the sample deck (UI kit). `index.html` is an interactive viewer; each slide is a tagged card: cover · section · stat · threecol · matrix · swatches · checklist · quote.

**Templates** (`templates/`) — copy-to-start artifacts for consuming projects.
- `pitch-deck/PitchDeck.dc.html` — "SO NICE Pitch Deck": 5-slide black-white-whitespace deck (cover · big stat · three-column · decision list · payoff) with arrow-key nav and auto-fit scaling.

**Assets** (`assets/`) — `logo.png` (wordmark).

**Sources** (`sources/`) — original brand spec + tokens, for reference.

---

## Do / Don't

- ✅ White ground, big black type, big numbers, one wine accent, generous whitespace, sharp corners, hairline rules.
- ❌ Multiple colors, gradients, fully rounded corners, pink, shadow overuse, decorative lines, serif or rounded fonts, emoji.
