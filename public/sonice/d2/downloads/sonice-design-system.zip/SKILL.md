---
name: sonice-design
description: Use this skill to generate well-branded interfaces and assets for SO NICE (都會時尚女裝 · 黑白極簡 urban womenswear), either for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, the logo, reusable UI components, and a sample deck for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files (tokens in `tokens/`, components in `components/core/`, foundation cards in `guidelines/`, the sample deck in `slides/`, and the logo in `assets/`).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Core rules to honor every time: black + white + generous whitespace (≥40% empty), bold Noto Sans TC headings (800/900), wine red `#6E2639` as the only accent used at most once per surface, sharp corners (≤8px), hairline or 2px-black rules, and no shadows / gradients / emoji / serif. Headlines are terse, Chinese-led with short UPPERCASE Latin kickers.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask a few questions, and act as an expert designer who outputs HTML artifacts — or production code — depending on the need.
